import { Chess } from 'chess.js';
import { getPieceSvg } from '../../src/pieces.js';
import { PositionTracker, scoreLabel } from './position.js';
import { detectBoard, arrowPoints } from './detect.js';
import { explainBestMove, explainMistake, speakArabic, setCoachMuted, isCoachMuted } from './coach.js';

if (!document.getElementById('chess-coach-extension')) start();

function start() {
  const host = document.createElement('div');
  host.id = 'chess-coach-extension';
  host.style.cssText = 'all:initial!important;position:fixed!important;inset:0!important;pointer-events:none!important;z-index:2147483646!important;';
  const shadow = host.attachShadow({ mode: 'open' });

  shadow.innerHTML = `<style>
    :host{font-family:Arial,Tahoma,sans-serif;color:#f4f6f3;font-size:14px;line-height:1.5}
    *{box-sizing:border-box} [hidden]{display:none!important}
    
    #card{position:fixed;right:16px;bottom:18px;width:310px;max-width:calc(100vw - 24px);background:#1e2320;color:#f4f6f3;font:14px/1.5 Arial,Tahoma,sans-serif;border:1px solid #3d4a40;border-radius:16px;box-shadow:0 12px 48px rgba(0,0,0,0.65);pointer-events:auto;direction:rtl;overflow:hidden;z-index:2147483647}
    header{display:flex;align-items:center;justify-content:space-between;padding:10px 14px;border-bottom:1px solid #2f3a32;background:#181d1a;cursor:move;touch-action:none}
    header strong{font-size:15px;direction:ltr;color:#8ae368;display:flex;align-items:center;gap:6px}
    
    button,select,textarea{font:inherit}
    button{background:#2b362e;color:#f4f6f3;border:1px solid #435447;border-radius:7px;padding:6px 10px;cursor:pointer;transition:all .15s}
    button:hover{background:#38483d}
    button:focus-visible,textarea:focus-visible{outline:2px solid #8ae368;outline-offset:2px}
    #pause{font-size:11px;padding:4px 8px}

    .body{padding:12px 14px}
    #status{color:#9eaea2;font-size:11px;margin:0 0 6px;min-height:16px}
    .result{display:flex;align-items:center;justify-content:space-between;gap:8px}
    #leader{font-size:15px;font-weight:bold}
    #score{font-size:27px;font-weight:bold;color:#8ae368;direction:ltr;font-variant-numeric:tabular-nums}
    #best{margin:6px 0 0;color:#d8e8d9;font-size:13px;font-weight:bold}
    #meta{font-size:11px;color:#85988a;margin-top:4px}

    /* COACH PANEL */
    .coach-panel{margin-top:10px;background:rgba(25, 33, 27, 0.95);border:1px solid #3e5243;border-radius:12px;padding:10px 12px;transition:border-color .2s, background-color .2s}
    .coach-panel.warning{border-color:#eab308;background:rgba(45, 36, 15, 0.95)}
    .coach-panel.best{border-color:#8ae368;background:rgba(20, 36, 23, 0.95)}
    
    .coach-header-row{display:flex;align-items:center;justify-content:space-between;margin-bottom:8px}
    .coach-profile{display:flex;align-items:center;gap:8px}
    .coach-avatar-btn{width:36px;height:36px;border-radius:50%;background:#2e3e32;display:flex;align-items:center;justify-content:center;font-size:20px;cursor:pointer;border:1px solid #4b6352;box-shadow:0 2px 8px rgba(0,0,0,0.3);position:relative;transition:transform .15s}
    .coach-avatar-btn:hover{transform:scale(1.08)}
    .coach-panel.warning .coach-avatar-btn{background:#4d380e;border-color:#eab308}
    .coach-badge{display:flex;flex-direction:column}
    .coach-name{font-size:12px;font-weight:bold;color:#c9e8d0}
    .coach-subtitle{font-size:10px;color:#85998b}
    .coach-panel.warning .coach-name{color:#fde047}

    .coach-controls{display:flex;gap:4px}
    .btn-coach-action{width:28px;height:28px;padding:0;display:flex;align-items:center;justify-content:center;font-size:13px;border-radius:6px;background:#28342b;border:1px solid #3e4f42}
    .btn-coach-action:hover{background:#384a3c}

    .coach-bubble{font-size:12px;line-height:1.55;color:#f0f5ee;background:#151c17;padding:9px 11px;border-radius:8px;border-right:3px solid #8ae368;position:relative}
    .coach-panel.warning .coach-bubble{border-right-color:#eab308;color:#fef08a}

    /* MINI BOARD & TOOLS */
    details{margin-top:10px;border-top:1px solid #2f3a32;padding-top:8px}
    summary{cursor:pointer;font-size:11px;color:#a8baa9}
    #mini{width:184px;height:184px;display:grid;grid-template-columns:repeat(8,1fr);direction:ltr;margin:10px auto;border:1px solid #3f4e43;border-radius:4px;overflow:hidden}
    #mini div{display:flex;align-items:center;justify-content:center;background:#e2e5e1}
    #mini div.dark{background:#9aa39d}
    #mini svg{width:92%;height:92%}
    .actions{display:flex;gap:6px;flex-wrap:wrap;margin-top:8px}
    .actions button{font-size:11px;flex:1}
    textarea{width:100%;min-height:54px;padding:6px;margin-top:6px;background:#151a17;border:1px solid #435447;border-radius:6px;color:white;direction:ltr;font-size:11px;resize:vertical}
    label{display:block;font-size:11px;margin-top:8px;color:#a8baa9}
    #error{font-size:11px;color:#f87171;min-height:15px;margin-top:4px}

    /* ARROW OVERLAY */
    #overlay{position:fixed;pointer-events:none;overflow:visible;filter:drop-shadow(0 2px 4px rgba(0,0,0,0.6));z-index:2147483645}
    #overlay line{pointer-events:stroke;cursor:pointer}
    
    footer{font-size:10px;color:#798c7e;margin-top:8px;text-align:center}
    a{color:#8ae368;text-decoration:none}
  </style>

  <svg id="overlay" hidden viewBox="0 0 100 100" aria-label="سهم أفضل نقلة">
    <defs>
      <marker id="coach-tip" markerWidth="3.4" markerHeight="3.4" refX="2.3" refY="1.7" orient="auto" markerUnits="strokeWidth">
        <path d="M0,0 L3.2,1.7 L0,3.4 L.7,1.7 Z" fill="#64cf3c"/>
      </marker>
      <marker id="coach-tip-warn" markerWidth="3.4" markerHeight="3.4" refX="2.3" refY="1.7" orient="auto" markerUnits="strokeWidth">
        <path d="M0,0 L3.2,1.7 L0,3.4 L.7,1.7 Z" fill="#eab308"/>
      </marker>
    </defs>
    <line id="arrow" stroke="#64cf3c" stroke-width="2.5" stroke-linecap="round" opacity=".95" marker-end="url(#coach-tip)"/>
  </svg>

  <section id="card" aria-label="تحليل كوتش الشطرنج العربي Chess Coach v1.2">
    <header>
      <strong>♟️ Chess Coach v1.2</strong>
      <button id="pause" type="button">إيقاف مؤقت</button>
    </header>
    <div class="body">
      <p id="status" role="status">جارٍ البحث عن رقعة الشطرنج…</p>
      <div class="result">
        <span id="leader">بانتظار الرقعة</span>
        <span id="score">—</span>
      </div>
      <p id="best">سيظهر أفضل تحريك بسهم أخضر مع شرح الكوتش.</p>
      <div id="meta"></div>

      <!-- COACH WIDGET -->
      <div id="coach-panel" class="coach-panel" aria-label="شرح كوتش الشطرنج">
        <div class="coach-header-row">
          <div class="coach-profile">
            <div id="coach-avatar" class="coach-avatar-btn" role="button" title="اضغط لسماع الشرح بالصوت">🧑‍🏫</div>
            <div class="coach-badge">
              <span class="coach-name">كوتش الشطرنج العربي</span>
              <span id="coach-badge-tag" class="coach-subtitle">تحليل تكتيكي فوري</span>
            </div>
          </div>
          <div class="coach-controls">
            <button id="coach-voice-btn" type="button" class="btn-coach-action" title="تشغيل/كتم الصوت">🔊</button>
            <button id="coach-replay-btn" type="button" class="btn-coach-action" title="إعادة الشرح بالصوت">↺</button>
          </div>
        </div>
        <div class="coach-bubble">
          <span id="coach-text">مرحباً! أنا كوتش الشطرنج الخاص بك. سأشرح لك بالصوت أسباب كل نقلة، وسأنبهك فوراً إذا قمت بنقلة خاطئة.</span>
        </div>
      </div>

      <details>
        <summary>الرقعة الملتقطة وأدوات الوضعية</summary>
        <div id="mini" aria-label="نسخة الوضعية الحالية"></div>
        <div class="actions">
          <button id="copy">نسخ FEN</button>
          <button id="open">فتح للتحليل اليدوي</button>
        </div>
        <label for="fen">FEN كامل عند تعذّر قراءة الدور أو سجل النقلات</label>
        <textarea id="fen" spellcheck="false" placeholder="rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"></textarea>
        <div class="actions">
          <button id="apply">استخدام FEN المطابق للرقعة</button>
        </div>
        <div id="error" role="alert"></div>
      </details>

      <footer>Stockfish 19 محلي · كوتش ناطق باللغة العربية</footer>
    </div>
  </section>`;

  document.documentElement.appendChild(host);
  const $ = id => shadow.getElementById(id);
  const tracker = new PositionTracker(), cache = new Map();

  let reading = null;
  let position = null;
  let lastKey = '';
  let version = 0;
  let paused = false;
  let enabled = true;
  let depth = 14;
  let result = null;
  let url = location.href;
  let timer;

  // History state for blunder / mistake coaching detection
  let prevPosition = null;
  let prevResult = null;
  let lastCoachedSpeech = '';
  let lastSpokenText = '';

  const text = (id, value) => { if ($(id).textContent !== value) $(id).textContent = value; };

  function setCoachAdvice(explanation, isWarning = false, forceSpeak = false) {
    if (!explanation) return;
    const newSpeech = explanation.voice || explanation.text;
    text('coach-text', explanation.text);
    $('coach-avatar').textContent = explanation.icon || (isWarning ? '⚠️' : '🧑‍🏫');
    text('coach-badge-tag', isWarning ? 'تنبيه على خطأ تكتيكي!' : 'شرح أسباب أفضل نقلة');
    
    const panel = $('coach-panel');
    panel.classList.toggle('warning', isWarning);
    panel.classList.toggle('best', !isWarning && explanation.motif !== 'wait');

    lastCoachedSpeech = newSpeech;

    // CRITICAL: Only speak when the text actually changes or user explicitly requested it!
    // Prevents interval/mutation observers from cancelling speech mid-sentence.
    if (forceSpeak || newSpeech !== lastSpokenText) {
      lastSpokenText = newSpeech;
      speakArabic(newSpeech);
    }
  }

  function clear(title, status) {
    result = null;
    $('overlay').toggleAttribute('hidden', true);
    text('leader', title);
    text('status', status);
    text('score', '—');
    text('best', '');
    text('meta', '');
  }

  function renderArrow() {
    if (!reading || !result?.best || paused || !enabled) {
      $('overlay').toggleAttribute('hidden', true);
      return;
    }
    const r = reading.element.getBoundingClientRect();
    if (!r.width || !r.height) {
      $('overlay').toggleAttribute('hidden', true);
      return;
    }
    const { from, to } = arrowPoints(result.best, reading.flipped);
    const dx = to.x - from.x, dy = to.y - from.y, length = Math.hypot(dx, dy);
    const end = { x: to.x - dx / length * 3, y: to.y - dy / length * 3 };
    const arrow = $('arrow');
    for (const [key, value] of Object.entries({ x1: from.x, y1: from.y, x2: end.x, y2: end.y })) {
      arrow.setAttribute(key, value);
    }
    $('overlay').style.cssText = `left:${r.left}px;top:${r.top}px;width:${r.width}px;height:${r.height}px`;
    $('overlay').toggleAttribute('hidden', false);
  }

  function miniBoard() {
    if (!position) { $('mini').replaceChildren(); return; }
    const board = new Chess(position.fen), frag = document.createDocumentFragment();
    const files = reading.flipped ? 'hgfedcba' : 'abcdefgh';
    for (let row = 0; row < 8; row++) {
      for (let col = 0; col < 8; col++) {
        const square = files[col] + (reading.flipped ? row + 1 : 8 - row), piece = board.get(square);
        const cell = document.createElement('div');
        if ((row + col) % 2) cell.className = 'dark';
        if (piece) cell.innerHTML = getPieceSvg(piece.color, piece.type);
        cell.title = square;
        frag.appendChild(cell);
      }
    }
    $('mini').replaceChildren(frag);
  }

  function show(evaluation) {
    result = evaluation;
    const label = scoreLabel(result);
    text('leader', label.title);
    text('score', label.score);
    text('status', `متصل بـ ${reading.type} · دور ${position.fen.split(' ')[1] === 'w' ? 'الأبيض' : 'الأسود'}`);
    text('best', result.bestSan ? `أفضل نقلة: ${result.bestSan}` : 'انتهت هذه الوضعية');
    text('meta', `${position.source} · العمق ${result.depth}`);
    renderArrow();

    // Check if the previous move by the player was a blunder or mistake
    let lastPlayedMove = null;
    let warned = false;
    if (prevPosition && prevResult && prevPosition.fen !== position.fen) {
      const prevBoard = new Chess(prevPosition.fen);
      const mover = prevBoard.turn();
      
      // Calculate loss for the side that just moved
      const prevCp = prevResult.cpWhite ?? 0;
      const currentCp = evaluation.cpWhite ?? 0;
      const dropCp = mover === 'w' ? (prevCp - currentCp) : (currentCp - prevCp);

      // Identify what move was played
      let playedUci = null;
      for (const m of prevBoard.moves({ verbose: true })) {
        const testBoard = new Chess(prevPosition.fen);
        testBoard.move(m);
        if (testBoard.fen().split(' ')[0] === position.fen.split(' ')[0]) {
          playedUci = m.from + m.to + (m.promotion || '');
          lastPlayedMove = m;
          break;
        }
      }

      // If drop >= 120 cp or blundered away a winning score:
      if (playedUci && dropCp >= 120) {
        const mistakeWarning = explainMistake({
          fenBefore: prevPosition.fen,
          playedUci,
          bestUci: prevResult.best,
          dropCp,
          fenAfter: position.fen
        });
        setCoachAdvice(mistakeWarning, true);
        warned = true;
      }
    }

    if (!warned) {
      // Explain why the recommended move is best
      const explanation = explainBestMove({
        fen: position.fen,
        bestUci: result.best,
        score: result.cpWhite,
        depth: result.depth,
        lastMove: lastPlayedMove
      });
      setCoachAdvice(explanation, false, true);
    }

    // Save history for next turn
    prevPosition = position;
    prevResult = evaluation;
  }

  async function analyze(force = false) {
    if (location.href !== url) {
      url = location.href;
      tracker.reset();
      lastKey = '';
      position = null;
      prevPosition = null;
      prevResult = null;
    }
    if (!enabled || paused) return;

    let detected;
    try { detected = detectBoard(); } catch { return; }
    if (!detected) {
      $('overlay').toggleAttribute('hidden', true);
      if (reading && !reading.element.isConnected) {
        version++;
        reading = position = null;
        lastKey = '';
        clear('بانتظار الرقعة', 'لم أجد رقعة متوافقة في هذه الصفحة.');
        miniBoard();
      }
      return;
    }

    const orientationChanged = reading?.flipped !== detected.flipped;
    reading = detected;

    let resolved;
    try { resolved = tracker.resolve(reading); } catch { return; }
    if (!resolved) {
      version++;
      lastKey = '';
      position = null;
      clear('أحتاج الدور وسجل النقلات', 'تم رصد القطع؛ أدخل FEN كاملًا أو افتح سجل المباراة.');
      miniBoard();
      return;
    }

    position = resolved;
    const key = position.fen + '|' + depth;
    if (!force && key === lastKey) {
      if (orientationChanged) miniBoard();
      if (result) show(result);
      else renderArrow();
      return;
    }

    lastKey = key;
    const current = ++version;
    clear('جارٍ التقييم…', `تم التقاط الوضعية · ${reading.type}`);
    miniBoard();
    text('error', '');
    $('fen').placeholder = position.fen;

    if (cache.has(key)) {
      show(cache.get(key));
      return;
    }

    try {
      const evaluation = await chrome.runtime.sendMessage({
        type: 'CI_ANALYZE',
        fen: position.fen,
        position: position.position,
        requestId: current
      });
      if (current !== version || paused || !enabled) return;
      if (evaluation?.stale) { lastKey = ''; return; }
      if (!evaluation || evaluation.error) throw new Error(evaluation?.error || 'لم يصل رد من المحرك.');
      
      if (evaluation.best) {
        new Chess(position.fen).move({
          from: evaluation.best.slice(0, 2),
          to: evaluation.best.slice(2, 4),
          promotion: evaluation.best[4]
        });
      }

      cache.set(key, evaluation);
      if (cache.size > 100) cache.delete(cache.keys().next().value);
      show(evaluation);
    } catch (e) {
      if (current === version) {
        clear('تعذر التحليل', e.message);
        lastKey = '';
      }
    }
  }

  function schedule() {
    clearTimeout(timer);
    timer = setTimeout(() => analyze(), 220);
  }

  const observer = new MutationObserver(records => {
    if (records.some(r => r.target !== host && !host.contains(r.target))) schedule();
  });
  observer.observe(document.documentElement, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ['class', 'style', 'data-fen', 'data-orientation'],
    characterData: true
  });

  setInterval(() => analyze(), 900);
  addEventListener('resize', renderArrow);
  addEventListener('scroll', renderArrow, true);

  // Coach Audio controls
  $('coach-voice-btn').addEventListener('click', () => {
    const isMuted = isCoachMuted();
    setCoachMuted(!isMuted);
    $('coach-voice-btn').textContent = !isMuted ? '🔇' : '🔊';
    $('coach-voice-btn').title = !isMuted ? 'الصوت مكتوم (اضغط للتشغيل)' : 'الصوت مفعّل (اضغط للكتم)';
  });

  $('coach-replay-btn').addEventListener('click', () => {
    if (lastCoachedSpeech) speakArabic(lastCoachedSpeech);
  });

  $('coach-avatar').addEventListener('click', () => {
    if (lastCoachedSpeech) speakArabic(lastCoachedSpeech);
  });

  // When hovering over the green arrow, the Coach explains why it is the best move
  $('arrow').addEventListener('mouseenter', () => {
    if (result?.best) {
      const explanation = explainBestMove({
        fen: position.fen,
        bestUci: result.best,
        score: result.cpWhite,
        depth: result.depth
      });
      setCoachAdvice(explanation, false);
    }
  });

  $('pause').addEventListener('click', () => {
    paused = !paused;
    version++;
    lastKey = '';
    text('pause', paused ? 'استئناف' : 'إيقاف مؤقت');
    if (paused) clear('التحليل متوقف', 'اضغط استئناف لإعادة قراءة الرقعة.');
    else analyze(true);
  });

  $('apply').addEventListener('click', () => {
    try {
      if (!reading) throw new Error('لم يتم العثور على رقعة.');
      position = tracker.resolve(reading, $('fen').value.trim());
      lastKey = '';
      text('error', '');
      analyze(true);
    } catch (e) {
      text('error', e.message || 'FEN غير صالح.');
    }
  });

  $('copy').addEventListener('click', async () => {
    try {
      if (!position) throw new Error('انتظر التقاط وضعية كاملة.');
      await navigator.clipboard.writeText(position.fen);
      text('error', 'تم نسخ FEN.');
    } catch (e) {
      text('error', e.message);
    }
  });

  $('open').addEventListener('click', () => {
    if (!position) { text('error', 'انتظر التقاط وضعية كاملة.'); return; }
    window.open('https://nour-hamada.github.io/chess-insight/#fen=' + encodeURIComponent(position.fen), '_blank', 'noopener');
  });

  let drag;
  shadow.querySelector('header').addEventListener('pointerdown', e => {
    if (e.target.closest('button')) return;
    const r = $('card').getBoundingClientRect();
    drag = { x: e.clientX - r.left, y: e.clientY - r.top };
    e.currentTarget.setPointerCapture(e.pointerId);
  });

  shadow.querySelector('header').addEventListener('pointermove', e => {
    if (!drag) return;
    const card = $('card');
    card.style.right = card.style.bottom = 'auto';
    card.style.left = Math.max(0, Math.min(innerWidth - card.offsetWidth, e.clientX - drag.x)) + 'px';
    card.style.top = Math.max(0, Math.min(innerHeight - 48, e.clientY - drag.y)) + 'px';
  });

  shadow.querySelector('header').addEventListener('pointerup', () => { drag = null; });

  async function settings() {
    const values = await chrome.storage.local.get({ enabled: true, depth: 14, voiceEnabled: true });
    enabled = values.enabled;
    depth = Number(values.depth);
    setCoachMuted(!values.voiceEnabled);
    $('coach-voice-btn').textContent = values.voiceEnabled ? '🔊' : '🔇';
    version++;
    lastKey = '';
    if (enabled) analyze(true);
    else clear('التحليل متوقف', 'فعّل الإضافة من أيقونتها في شريط كروم.');
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && (changes.enabled || changes.depth || changes.voiceEnabled)) settings();
  });

  chrome.runtime.onMessage.addListener((message, _sender, respond) => {
    if (message?.type === 'CI_STATUS') {
      respond({ found: !!reading, needsPosition: !!reading && !position, fen: position?.fen, paused, enabled });
      return false;
    }
    if (message?.type === 'CI_RESUME') {
      paused = false;
      text('pause', 'إيقاف مؤقت');
      settings();
      respond({ ok: true });
    }
    return false;
  });

  settings();
}
