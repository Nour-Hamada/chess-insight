import { Chess } from 'chess.js';

const file = 'abcdefgh';
export const placementOf = fen => fen.split(' ')[0];
export const START = new Chess().fen();
export function makePlacement(pieces) {
  const ranks = [];
  for (let rank = 8; rank >= 1; rank--) {
    let row = '', empty = 0;
    for (const f of file) {
      const piece = pieces.get(f + rank);
      if (!piece) { empty++; continue; }
      if (empty) { row += empty; empty = 0; }
      row += piece[0] === 'w' ? piece[1].toUpperCase() : piece[1];
    }
    ranks.push(row + (empty || ''));
  }
  return ranks.join('/');
}

export function inferCastlingRights(pieces) {
  if (!pieces || pieces.size === 0) return '-';
  let castling = '';
  if (pieces.get('e1') === 'wk') {
    if (pieces.get('h1') === 'wr') castling += 'K';
    if (pieces.get('a1') === 'wr') castling += 'Q';
  }
  if (pieces.get('e8') === 'bk') {
    if (pieces.get('h8') === 'br') castling += 'k';
    if (pieces.get('a8') === 'br') castling += 'q';
  }
  return castling || '-';
}

export function inferTurn(doc, boardElement, type, flipped, pieces, placement, highlights = [], sans = []) {
  // 1. Check highlights on board (Chess.com & Lichess last move)
  if (highlights && highlights.length >= 2 && pieces && pieces.size > 0) {
    const occupied = highlights.filter(sq => pieces.has(sq));
    const vacated = highlights.filter(sq => !pieces.has(sq));

    let destSquare = null;
    let fromSquare = vacated[0] || null;

    if (occupied.length === 1) {
      destSquare = occupied[0];
    } else if (occupied.length > 1) {
      const kingSq = occupied.find(sq => pieces.get(sq)?.[1] === 'k');
      destSquare = kingSq || occupied[0];
    }

    if (destSquare) {
      const piece = pieces.get(destSquare);
      if (piece) {
        const moverColor = piece[0]; // 'w' or 'b'
        const nextTurn = moverColor === 'w' ? 'b' : 'w';

        let enPassant = '-';
        if (fromSquare && piece[1] === 'p') {
          const fromRank = Number(fromSquare[1]);
          const toRank = Number(destSquare[1]);
          if (moverColor === 'w' && fromRank === 2 && toRank === 4) {
            enPassant = destSquare[0] + '3';
          } else if (moverColor === 'b' && fromRank === 7 && toRank === 5) {
            enPassant = destSquare[0] + '6';
          }
        }
        return { turn: nextTurn, enPassant, confidence: 'high', reason: 'نقلة أخيرة مرصودة' };
      }
    }
  }

  // 2. Active Clock in DOM
  if (doc) {
    const whiteClockActive = doc.querySelector('.clock-white.clock-player-turn, .clock-white.clock-running, .clock-white.has-pulse, .rclock-white.running');
    const blackClockActive = doc.querySelector('.clock-black.clock-player-turn, .clock-black.clock-running, .clock-black.has-pulse, .rclock-black.running');
    if (whiteClockActive && !blackClockActive) return { turn: 'w', enPassant: '-', confidence: 'high', reason: 'ساعة الأبيض تعمل' };
    if (blackClockActive && !whiteClockActive) return { turn: 'b', enPassant: '-', confidence: 'high', reason: 'ساعة الأسود تعمل' };

    const topClockActive = doc.querySelector('.clock-top.clock-player-turn, .clock-top.clock-running, .rclock-top.running');
    const bottomClockActive = doc.querySelector('.clock-bottom.clock-player-turn, .clock-bottom.clock-running, .rclock-bottom.running');
    if (bottomClockActive && !topClockActive) {
      return { turn: flipped ? 'b' : 'w', enPassant: '-', confidence: 'high', reason: 'ساعة اللاعب الحالي' };
    }
    if (topClockActive && !bottomClockActive) {
      return { turn: flipped ? 'w' : 'b', enPassant: '-', confidence: 'high', reason: 'ساعة الخصم' };
    }
  }

  // 3. Move list parity
  if (sans && sans.length > 0) {
    return { turn: sans.length % 2 === 1 ? 'b' : 'w', enPassant: '-', confidence: 'medium', reason: 'سجل النقلات' };
  }

  // 4. King in check
  try {
    const testWhite = new Chess(`${placement} w - - 0 1`);
    const testBlack = new Chess(`${placement} b - - 0 1`);
    if (testWhite.inCheck() && !testBlack.inCheck()) {
      return { turn: 'w', enPassant: '-', confidence: 'conclusive', reason: 'كش لملك الأبيض' };
    }
    if (testBlack.inCheck() && !testWhite.inCheck()) {
      return { turn: 'b', enPassant: '-', confidence: 'conclusive', reason: 'كش لملك الأسود' };
    }
  } catch {}

  // 5. Default
  return { turn: 'w', enPassant: '-', confidence: 'fallback', reason: 'رصد الرقعة' };
}

// Placement alone cannot tell whose turn it is or recover castling rights.
// Preserve a legal history whenever possible; otherwise reconstruct a legal midgame position automatically.
export class PositionTracker {
  constructor() { this.reset(); }
  reset() { this.board = null; this.snapshots = []; this.source = ''; }
  remember(board, source) {
    this.board = board;
    this.source = source;
    const fen = board.fen();
    if (this.snapshots.at(-1) !== fen) this.snapshots.push(fen);
    this.snapshots = this.snapshots.slice(-500);
    return { fen, source, history: board.history(), position: this.command(board) };
  }
  command(board) {
    const moves = board.history({ verbose: true });
    const initial = moves[0]?.before || board.fen();
    return `position fen ${initial}${moves.length ? ' moves ' + moves.map(m => m.from + m.to + (m.promotion || '')).join(' ') : ''}`;
  }
  resolve(reading, override = null) {
    const { placement, fullFen, sans = [], initialFen = START, selectedPly = null, element, type, flipped, pieces, highlights = [], doc } = reading;
    if (override) {
      const board = new Chess(override);
      if (placementOf(board.fen()) !== placement) throw new Error('FEN لا يطابق القطع الظاهرة على الرقعة.');
      return this.remember(board, 'FEN مُدخل');
    }
    if (fullFen) {
      try {
        const board = new Chess(fullFen);
        if (placementOf(board.fen()) === placement) {
          if (this.board?.fen() === board.fen()) return this.remember(this.board, this.source);
          return this.remember(board, 'FEN الرقعة');
        }
      } catch { /* Incomplete DOM update: try the legal history instead. */ }
    }
    if (sans.length) {
      try {
        const board = new Chess(initialFen);
        let match = placementOf(board.fen()) === placement ? new Chess(initialFen) : null;
        for (const san of sans.slice(0, selectedPly ?? sans.length)) {
          board.move(san);
          if (placementOf(board.fen()) === placement) {
            match = new Chess(initialFen);
            for (const move of board.history()) match.move(move);
          }
        }
        if (match && (selectedPly == null || match.history().length === selectedPly)) return this.remember(match, 'سجل النقلات');
      } catch { /* A partial/unsupported move list is not grounds for guessing. */ }
    }
    if (this.board) {
      if (placementOf(this.board.fen()) === placement) return this.remember(this.board, this.source);
      const matches = this.board.moves({ verbose: true }).filter(m => placementOf(m.after) === placement);
      if (matches.length === 1) {
        this.board.move(matches[0]);
        return this.remember(this.board, 'متابعة النقلات');
      }
      const past = this.snapshots.findLast(fen => placementOf(fen) === placement);
      if (past) return this.remember(new Chess(past), 'وضعية سابقة');
    }
    if (placement === placementOf(START)) return this.remember(new Chess(), 'بداية المباراة');

    // Midgame automatic resolution: activates when opening extension during an ongoing game
    if (pieces || element || (highlights && highlights.length) || reading.inferMidgame) {
      try {
        let pieceMap = pieces;
        if (!pieceMap || pieceMap.size === 0) {
          pieceMap = new Map();
          const ranks = placement.split('/');
          for (let r = 0; r < 8; r++) {
            let col = 0;
            for (const ch of ranks[r]) {
              if (/[1-8]/.test(ch)) {
                col += Number(ch);
              } else {
                const color = ch === ch.toUpperCase() ? 'w' : 'b';
                pieceMap.set(file[col] + (8 - r), color + ch.toLowerCase());
                col++;
              }
            }
          }
        }

        const inferred = inferTurn(doc || (typeof document !== 'undefined' ? document : null), element, type, flipped, pieceMap, placement, highlights, sans);
        const castling = inferCastlingRights(pieceMap);
        const ep = inferred.enPassant || '-';
        const moveCount = sans && sans.length > 0 ? Math.floor(sans.length / 2) + 1 : 15;

        for (const candidateFen of [
          `${placement} ${inferred.turn} ${castling} ${ep} 0 ${moveCount}`,
          `${placement} ${inferred.turn} ${castling} - 0 ${moveCount}`,
          `${placement} ${inferred.turn} - - 0 ${moveCount}`,
          `${placement} ${inferred.turn === 'w' ? 'b' : 'w'} ${castling} - 0 ${moveCount}`,
          `${placement} ${inferred.turn === 'w' ? 'b' : 'w'} - - 0 ${moveCount}`
        ]) {
          try {
            const b = new Chess(candidateFen);
            if (placementOf(b.fen()) === placement) {
              return this.remember(b, `رصد مباشر (${inferred.reason})`);
            }
          } catch {}
        }
      } catch (e) {
        // Fallback failed
      }
    }

    return null;
  }
}

export function scoreLabel(result) {
  if (result.terminal === 'mate') return { title: `${result.cpWhite > 0 ? 'الأبيض' : 'الأسود'} فاز بالكش مات`, score: 'مات' };
  if (result.terminal === 'draw') return { title: 'الموقف تعادل', score: '0.0' };
  if (result.mate != null) return { title: `${result.cpWhite > 0 ? 'الأبيض' : 'الأسود'} لديه مات إجباري`, score: `M${Math.abs(result.mate)}` };
  const cp = result.cpWhite;
  return { title: Math.abs(cp) < 35 ? 'الموقف متوازن تقريبًا' : `${cp > 0 ? 'الأبيض' : 'الأسود'} متفوق`, score: `${cp > 0 ? '+' : ''}${(cp / 100).toFixed(1)}` };
}
