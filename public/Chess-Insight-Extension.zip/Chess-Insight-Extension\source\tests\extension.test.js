import test from 'node:test';
import assert from 'node:assert/strict';
import { Chess } from 'chess.js';
import { PositionTracker, placementOf, makePlacement, START, scoreLabel } from '../extension/src/position.js';
import { arrowPoints } from '../extension/src/detect.js';

test('detected placement requires known turn; explicit FEN must match', () => {
  const tracker = new PositionTracker();
  const board = new Chess(); board.move('e4');
  const reading = { placement: placementOf(board.fen()) };
  assert.equal(tracker.resolve(reading), null);
  assert.throws(() => tracker.resolve(reading, START), /لا يطابق/);
  assert.equal(tracker.resolve(reading, board.fen()).fen, board.fen());
});
test('main-line history reconstructs browsed earlier position including castling rights', () => {
  const tracker = new PositionTracker();
  const sans = 'e4 e5 Nf3 Nc6 Bb5 a6 Ba4 Nf6 O-O Be7'.split(' ');
  const board = new Chess(); for (const move of sans.slice(0, 9)) board.move(move);
  const result = tracker.resolve({ placement: placementOf(board.fen()), sans });
  assert.equal(result.fen, board.fen()); assert.equal(result.history.length, 9);
  assert.match(result.position, /moves e2e4 e7e5/);
  assert.equal(result.fen.split(' ')[2], 'kq');
});
test('automatic tracking handles en passant, capture, undo and a new branch', () => {
  const tracker = new PositionTracker(), board = new Chess();
  tracker.resolve({ placement: placementOf(board.fen()) });
  const history = [];
  for (const san of ['e4', 'a6', 'e5', 'd5', 'exd6']) {
    board.move(san); history.push(board.fen());
    assert.equal(tracker.resolve({ placement: placementOf(board.fen()) }).fen, board.fen());
  }
  board.undo(); assert.equal(tracker.resolve({ placement: placementOf(board.fen()) }).fen, history[3]);
  board.move('Nf3'); assert.equal(tracker.resolve({ placement: placementOf(board.fen()) }).fen, board.fen());
});
test('selected ply distinguishes repeated positions with different move counters', () => {
  const tracker = new PositionTracker();
  const sans = ['Nf3', 'Nf6', 'Ng1', 'Ng8', 'Nf3', 'Nf6', 'Ng1', 'Ng8'];
  const board = new Chess(); for (const san of sans.slice(0, 4)) board.move(san);
  const resolved = tracker.resolve({ placement: placementOf(board.fen()), sans, selectedPly: 4 });
  assert.equal(resolved.fen, board.fen());
  assert.equal(resolved.history.length, 4);
});
test('tracking handles promotion and terminal scoring', () => {
  const board = new Chess('8/P7/8/8/8/8/7k/4K3 w - - 0 1'), tracker = new PositionTracker();
  tracker.resolve({ placement: placementOf(board.fen()), fullFen: board.fen() });
  board.move('a8=N'); assert.equal(tracker.resolve({ placement: placementOf(board.fen()) }).fen, board.fen());
  assert.match(scoreLabel({ cpWhite: -10000, terminal: 'mate' }).title, /الأسود/);
  assert.match(scoreLabel({ cpWhite: 9500, mate: 10 }).score, /M10/);
  assert.match(scoreLabel({ cpWhite: -125 }).title, /الأسود/);
});
test('board coordinates and green arrow reverse correctly when flipped', () => {
  const board = new Chess(), pieces = new Map();
  for (const row of board.board()) for (const p of row) if (p) pieces.set(p.square, p.color + p.type);
  assert.equal(makePlacement(pieces), placementOf(START));
  const normal = arrowPoints('e2e4'), flipped = arrowPoints('e2e4', true);
  assert.ok(normal.to.y < normal.from.y); assert.ok(flipped.to.y > flipped.from.y);
  assert.equal(normal.to.x + flipped.to.x, 100);
});

test('midgame activation without move list infers turn from highlights and continues tracking', () => {
  const board = new Chess();
  board.move('e4');
  board.move('e5');
  board.move('Nf3'); // White just played Nf3 from g1 to f3. It is Black's turn.

  const pieces = new Map();
  for (const row of board.board()) {
    for (const p of row) {
      if (p) pieces.set(p.square, p.color + p.type);
    }
  }

  const tracker = new PositionTracker();
  // Simulate opening extension midgame with highlights from the last move (g1, f3)
  const resolved = tracker.resolve({
    placement: placementOf(board.fen()),
    pieces,
    highlights: ['g1', 'f3']
  });

  assert.ok(resolved, 'Should resolve position midgame');
  assert.equal(resolved.fen.split(' ')[1], 'b', 'Should correctly deduce Black to move');
  assert.equal(placementOf(resolved.fen), placementOf(board.fen()));

  // Next move: Black plays Nc6
  board.move('Nc6');
  const nextResolved = tracker.resolve({
    placement: placementOf(board.fen())
  });

  assert.ok(nextResolved, 'Should track next move incrementally');
  assert.equal(nextResolved.fen.split(' ')[1], 'w', 'Should advance to White to move');
});

test('midgame activation correctly detects when King is in check', () => {
  // 1. e4 e5 2. Qh5 Nc6 3. Bc4 Nf6 4. Qxf7#
  // Or check position: 1. e4 d5 2. exd5 Qxd5 3. Nc3 Qe5+ (Black checks White King)
  const checkBoard = new Chess('rnb1kbnr/ppp1pppp/8/8/8/2N5/PPPP1PPP/R1BQKBNR w KQkq - 1 4');
  const checkFen = checkBoard.fen(); // White to move, white in check

  const tracker = new PositionTracker();
  const resolved = tracker.resolve({
    placement: placementOf(checkFen),
    inferMidgame: true
  });

  assert.ok(resolved, 'Should resolve check position');
  assert.equal(resolved.fen.split(' ')[1], 'w', 'King in check forces White turn');
});
