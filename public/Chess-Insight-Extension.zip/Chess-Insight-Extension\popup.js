// extension/src/popup.js
var $ = (id) => document.getElementById(id);
var tab;
var config = await chrome.storage.local.get({ enabled: true, showArrows: true, depth: 14 });
if (document.getElementById("showArrows")) document.getElementById("showArrows").checked = config.showArrows ?? true;
$("enabled").checked = config.enabled;
$("depth").value = String(config.depth);
[tab] = await chrome.tabs.query({ active: true, currentWindow: true });
async function status() {
  try {
    const state = await chrome.tabs.sendMessage(tab.id, { type: "CI_STATUS" });
    $("status").textContent = !state.enabled ? "\u0627\u0644\u062A\u062D\u0644\u064A\u0644 \u0627\u0644\u062A\u0644\u0642\u0627\u0626\u064A \u0645\u062A\u0648\u0642\u0641." : state.paused ? "\u0627\u0644\u062A\u062D\u0644\u064A\u0644 \u0645\u062A\u0648\u0642\u0641 \u0645\u0624\u0642\u062A\u064B\u0627\u061B \u0627\u0636\u063A\u0637 \u062A\u0641\u0639\u064A\u0644 \u0644\u0644\u0627\u0633\u062A\u0626\u0646\u0627\u0641." : state.needsPosition ? "\u0631\u064F\u0635\u062F\u062A \u0627\u0644\u0631\u0642\u0639\u0629\u061B \u0627\u0641\u062A\u062D \u0633\u062C\u0644 \u0627\u0644\u0646\u0642\u0644\u0627\u062A \u0623\u0648 \u0623\u062F\u062E\u0644 FEN \u0643\u0627\u0645\u0644\u064B\u0627 \u0641\u064A \u0644\u0648\u062D\u0629 \u0627\u0644\u0625\u0636\u0627\u0641\u0629." : state.found ? "\u062A\u0645 \u0631\u0635\u062F \u0627\u0644\u0631\u0642\u0639\u0629 \u0648\u0627\u0644\u0648\u0636\u0639\u064A\u0629 \u0641\u064A \u0647\u0630\u0647 \u0627\u0644\u0635\u0641\u062D\u0629." : "\u0627\u0644\u0625\u0636\u0627\u0641\u0629 \u062C\u0627\u0647\u0632\u0629 \u0648\u062A\u0646\u062A\u0638\u0631 \u0638\u0647\u0648\u0631 \u0631\u0642\u0639\u0629.";
  } catch {
    $("status").textContent = "\u0627\u0641\u062A\u062D \u0635\u0641\u062D\u0629 \u0631\u0642\u0639\u0629\u060C \u062B\u0645 \u0641\u0639\u0651\u0644 \u0627\u0644\u0625\u0636\u0627\u0641\u0629 \u0647\u0646\u0627.";
  }
}
$("enabled").addEventListener("change", () => chrome.storage.local.set({ enabled: $("enabled").checked }));
$("depth").addEventListener("change", () => chrome.storage.local.set({ depth: Number($("depth").value) }));
if (document.getElementById("showArrows")) document.getElementById("showArrows").addEventListener("change", () => chrome.storage.local.set({ showArrows: document.getElementById("showArrows").checked }));
$("activate").addEventListener("click", async () => {
  $("activate").disabled = true;
  try {
    const origin = new URL(tab.url).origin;
    if (!/^https?:\/\//.test(origin)) throw new Error("\u0627\u0641\u062A\u062D \u0645\u0648\u0642\u0639 \u0634\u0637\u0631\u0646\u062C \u0639\u0627\u062F\u064A\u064B\u0627 \u0623\u0648\u0644\u064B\u0627.");
    const builtIn = /^https:\/\/(www\.)?chess\.com$/.test(origin) || origin === "https://lichess.org" || origin === "https://nour-hamada.github.io";
    if (!builtIn) {
      const pattern = origin + "/*";
      const granted = await chrome.permissions.request({ origins: [pattern] });
      if (!granted) throw new Error("\u0644\u0645 \u064A\u062A\u0645 \u0645\u0646\u062D \u0625\u0630\u0646 \u0647\u0630\u0627 \u0627\u0644\u0645\u0648\u0642\u0639.");
      const id = "site-" + new URL(origin).host.replace(/[^a-z0-9]/gi, "-");
      const existing = await chrome.scripting.getRegisteredContentScripts({ ids: [id] });
      if (!existing.length) await chrome.scripting.registerContentScripts([{ id, matches: [pattern], js: ["content.js"], runAt: "document_idle", persistAcrossSessions: true }]);
    }
    await chrome.storage.local.set({ enabled: true });
    $("enabled").checked = true;
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] });
    await chrome.tabs.sendMessage(tab.id, { type: "CI_RESUME" });
    await status();
  } catch (e) {
    $("status").textContent = e.message;
  } finally {
    $("activate").disabled = false;
  }
});
status();
