import test from 'node:test';
import assert from 'node:assert/strict';
import { explainBestMove, explainMistake } from '../extension/src/coach.js';

test('explainBestMove explains checkmate accurately in Arabic', () => {
  // Scholar's Mate: 1. e4 e5 2. Bc4 Nc6 3. Qh5 Nf6 4. Qxf7#
  const fen = 'r1bqkb1r/pppp1ppp/2n5/4p2Q/2B1P3/8/PPPP1PPP/RNB1K1NR w KQkq - 0 4';
  const explanation = explainBestMove({ fen, bestUci: 'h5f7' });
  assert.equal(explanation.motif, 'mate');
  assert.match(explanation.text, /كش مات/);
  assert.match(explanation.voice, /كش مات/);
});

test('explainBestMove explains Queen capture accurately in Arabic', () => {
  const fen = 'rnb1kbnr/ppp1pppp/8/3q4/4Q3/8/PPPPPPPP/RNB1KBNR w KQkq - 0 1';
  const explanation = explainBestMove({ fen, bestUci: 'e4d5' });
  assert.equal(explanation.motif, 'queen_capture');
  assert.match(explanation.text, /أسر الوزير/);
});

test('explainBestMove explains castling in Arabic', () => {
  const fen = 'r1bqk2r/pppp1ppp/2n2n2/2b1p3/2B1P3/5N2/PPPP1PPP/RNBQK2R w KQkq - 0 1';
  const explanation = explainBestMove({ fen, bestUci: 'e1g1' });
  assert.equal(explanation.motif, 'castling');
  assert.match(explanation.text, /التبييت/);
});

test('explainMistake warns player when leaving a piece hanging', () => {
  // White moves knight to an attacked square with no protection
  const fenBefore = 'r1bqkbnr/pppp1ppp/2n5/4p3/4P3/5N2/PPPP1PPP/RNBQKB1R w KQkq - 0 1';
  // White plays Ng5, but Black has Qxg5 or Bxg5
  const fenAfter = 'r1bqkbnr/pppp1ppp/2n5/4p1N1/4P3/8/PPPP1PPP/RNBQKB1R b KQkq - 0 1';
  const warning = explainMistake({
    fenBefore,
    playedUci: 'f3g5',
    bestUci: 'f1c4',
    dropCp: 250,
    fenAfter
  });
  assert.match(warning.text, /هل أنت متأكد من هذه النقلة؟/);
  assert.match(warning.text, /نسيت/);
});

test('explainMistake warns when missed major threat or capture', () => {
  const fenBefore = 'rnbqkbnr/ppp1pppp/8/3p4/4Q3/8/PPPPPPPP/RNB1KBNR b KQkq - 0 1';
  // Black can take White Queen on e4 (best move d5e4). Instead Black plays a6!
  const fenAfter = 'rnbqkbnr/1pp1pppp/p7/3p4/4Q3/8/PPPPPPPP/RNB1KBNR w KQkq - 0 2';
  const warning = explainMistake({
    fenBefore,
    playedUci: 'a7a6',
    bestUci: 'd5e4',
    dropCp: 800,
    fenAfter
  });
  assert.match(warning.text, /هل أنت متأكد من هذه النقلة؟/);
  assert.match(warning.text, /نسيت/);
});
