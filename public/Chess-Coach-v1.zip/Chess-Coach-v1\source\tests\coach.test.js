import test from 'node:test';
import assert from 'node:assert/strict';
import { Chess } from 'chess.js';
import {
  explainBestMove,
  explainMistake,
  identifyOpening,
  detectOpponentThreats,
  formatSpeechText,
  squareToSpeech
} from '../extension/src/coach.js';

test('squareToSpeech formats chess coordinates to natural spoken Arabic words', () => {
  assert.equal(squareToSpeech('f7'), 'إف سبعة');
  assert.equal(squareToSpeech('e4'), 'إي أربعة');
  assert.equal(squareToSpeech('c7'), 'سي سبعة');
  assert.equal(squareToSpeech('d5'), 'دي خمسة');
});

test('formatSpeechText removes markdown & emojis and replaces coordinates cleanly', () => {
  const input = '✨ **أحسنت!** نشر الفيل إلى c4 يضغط على f7!';
  const formatted = formatSpeechText(input);
  assert.equal(formatted.includes('**'), false);
  assert.equal(formatted.includes('✨'), false);
  assert.match(formatted, /سي أربعة/);
  assert.match(formatted, /إف سبعة/);
});

test('identifyOpening recognizes Italian Game and Sicilian Defense', () => {
  const italian = new Chess();
  italian.move('e4'); italian.move('e5'); italian.move('Nf3'); italian.move('Nc6'); italian.move('Bc4');
  const italianInfo = identifyOpening(italian);
  assert.ok(italianInfo);
  assert.equal(italianInfo.name, 'الافتتاح الإيطالي');

  const sicilian = new Chess();
  sicilian.move('e4'); sicilian.move('c5'); sicilian.move('Nf3');
  const sicilianInfo = identifyOpening(sicilian);
  assert.ok(sicilianInfo);
  assert.equal(sicilianInfo.name, 'الدفاع الصقلي');
});

test('explainBestMove uses "علينا الآن أن نغطي الكش بـ" when in check and blocking', () => {
  // Black in check from Bb5+
  const fenInCheck = 'rnbqkbnr/ppp2ppp/3p4/1B2p3/4P3/5N2/PPPP1PPP/RNBQK2R b KQkq - 1 3';
  // Black blocks with Bd7
  const explanation = explainBestMove({ fen: fenInCheck, bestUci: 'c8d7' });
  assert.match(explanation.text, /علينا الآن أن نغطي الكش/);
  assert.match(explanation.voice, /علينا الآن أن نغطي الكش/);
});

test('explainBestMove uses "علينا الآن استعادة القطعة" when recapturing', () => {
  // Position where White just played exd5 capturing Black's pawn on d5
  const fen = 'rnbqkbnr/ppp1pppp/8/3P4/8/8/PPPP1PPP/RNBQKBNR b KQkq - 0 2';
  // Black recaptures Qxd5 on d5
  const explanation = explainBestMove({
    fen,
    bestUci: 'd8d5',
    lastMove: { from: 'e4', to: 'd5', captured: 'p' }
  });
  assert.match(explanation.text, /علينا الآن استعادة القطعة/);
  assert.match(explanation.voice, /علينا الآن استعادة القطعة/);
});

test('explainBestMove uses "انتبه! هناك تهديد" when opponent is threatening a piece', () => {
  // White queen on d5 attacked by Black bishop on e6
  const fen = 'rnb1kbnr/ppp2ppp/4b3/3Q4/4p3/3P1N2/PPP2PPP/RNB1KB1R w KQkq - 1 4';
  const explanation = explainBestMove({ fen, bestUci: 'd5a5' });
  assert.match(explanation.text, /انتبه! هناك تهديد/);
  assert.match(explanation.voice, /انتبه! هناك تهديد/);
});

test('explainMistake uses أوتش! and asks هل أنت متأكد من هذه النقلة؟ لأنك نسيت...', () => {
  const fenBefore = 'r1bqkbnr/pppp1ppp/2n5/4p3/4P3/5N2/PPPP1PPP/RNBQKB1R w KQkq - 0 1';
  // White plays blunder Ng5 dropping knight for free
  const fenAfter = 'r1bqkbnr/pppp1ppp/2n5/4p1N1/4P3/8/PPPP1PPP/RNBQKB1R b KQkq - 0 1';
  const warning = explainMistake({
    fenBefore,
    playedUci: 'f3g5',
    bestUci: 'f1c4',
    dropCp: 300,
    fenAfter
  });
  assert.match(warning.text, /أوتش!/);
  assert.match(warning.text, /هل أنت متأكد من هذه النقلة؟/);
  assert.match(warning.text, /نسيت/);
});
