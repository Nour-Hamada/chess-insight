import test from 'node:test';
import assert from 'node:assert/strict';
import { Chess } from 'chess.js';
import {
  explainBestMove,
  explainMistake,
  identifyOpening,
  detectOpponentThreats,
  formatSpeechText,
  squareToSpeech
} from '../extension/src/coach.js';

test('squareToSpeech formats chess coordinates to natural spoken Arabic words', () => {
  assert.equal(squareToSpeech('f7'), 'إف سبعة');
  assert.equal(squareToSpeech('e4'), 'إي أربعة');
  assert.equal(squareToSpeech('c7'), 'سي سبعة');
  assert.equal(squareToSpeech('d5'), 'دي خمسة');
});

test('formatSpeechText removes markdown & emojis and replaces coordinates cleanly', () => {
  const input = '✨ **أحسنت!** نشر الفيل إلى c4 يضغط على f7!';
  const formatted = formatSpeechText(input);
  assert.equal(formatted.includes('**'), false);
  assert.equal(formatted.includes('✨'), false);
  assert.match(formatted, /سي أربعة/);
  assert.match(formatted, /إف سبعة/);
});

test('identifyOpening recognizes Italian Game and Sicilian Defense', () => {
  const italian = new Chess();
  italian.move('e4'); italian.move('e5'); italian.move('Nf3'); italian.move('Nc6'); italian.move('Bc4');
  const italianInfo = identifyOpening(italian);
  assert.ok(italianInfo);
  assert.equal(italianInfo.name, 'الافتتاح الإيطالي');

  const sicilian = new Chess();
  sicilian.move('e4'); sicilian.move('c5'); sicilian.move('Nf3');
  const sicilianInfo = identifyOpening(sicilian);
  assert.ok(sicilianInfo);
  assert.equal(sicilianInfo.name, 'الدفاع الصقلي');
});

test('explainBestMove names the opening and uses احسنت for Italian Game Bc4', () => {
  const fenBeforeBc4 = 'r1bqkbnr/pppp1ppp/2n5/4p3/4P3/5N2/PPPP1PPP/RNBQKB1R w KQkq - 2 3';
  const explanation = explainBestMove({ fen: fenBeforeBc4, bestUci: 'f1c4' });
  assert.match(explanation.text, /الافتتاح الإيطالي/);
  assert.match(explanation.text, /أحسنت/);
  assert.match(explanation.voice, /أحسنت/);
});

test('explainBestMove warns with انتبه when defending against opponent threat', () => {
  // Black bishop on g4 attacks White Queen on d1 (or knight on f3 pinned)
  // White plays h3 to challenge the bishop
  const fen = 'r2qkbnr/ppp2ppp/2n5/3pp3/4P1b1/3P1N2/PPP2PPP/RNBQKB1R w KQkq - 1 4';
  const explanation = explainBestMove({ fen, bestUci: 'h2h3' });
  assert.match(explanation.text, /أحسنت|انتبه/);
});

test('explainMistake uses أوتش! and asks هل أنت متأكد من هذه النقلة؟ لأنك نسيت...', () => {
  const fenBefore = 'r1bqkbnr/pppp1ppp/2n5/4p3/4P3/5N2/PPPP1PPP/RNBQKB1R w KQkq - 0 1';
  // White plays blunder Ng5 dropping knight for free
  const fenAfter = 'r1bqkbnr/pppp1ppp/2n5/4p1N1/4P3/8/PPPP1PPP/RNBQKB1R b KQkq - 0 1';
  const warning = explainMistake({
    fenBefore,
    playedUci: 'f3g5',
    bestUci: 'f1c4',
    dropCp: 300,
    fenAfter
  });
  assert.match(warning.text, /أوتش!/);
  assert.match(warning.text, /هل أنت متأكد من هذه النقلة؟/);
  assert.match(warning.text, /نسيت/);
});
