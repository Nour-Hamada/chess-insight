(() => {
  // ../../../chess-insight/node_modules/chess.js/dist/esm/chess.js
  function rootNode(comment) {
    return comment !== null ? { comment, variations: [] } : { variations: [] };
  }
  function node(move, suffix, nag, comment, variations) {
    const node2 = { move, variations };
    if (suffix) {
      node2.suffix = suffix;
    }
    if (nag) {
      node2.nag = nag;
    }
    if (comment !== null) {
      node2.comment = comment;
    }
    return node2;
  }
  function lineToTree(...nodes) {
    const [root, ...rest] = nodes;
    let parent = root;
    for (const child of rest) {
      if (child !== null) {
        parent.variations = [child, ...child.variations];
        child.variations = [];
        parent = child;
      }
    }
    return root;
  }
  function pgn(headers, game) {
    if (game.marker && game.marker.comment) {
      let node2 = game.root;
      while (true) {
        const next = node2.variations[0];
        if (!next) {
          node2.comment = game.marker.comment;
          break;
        }
        node2 = next;
      }
    }
    return {
      headers,
      root: game.root,
      result: (game.marker && game.marker.result) ?? void 0
    };
  }
  function peg$subclass(child, parent) {
    function C() {
      this.constructor = child;
    }
    C.prototype = parent.prototype;
    child.prototype = new C();
  }
  function peg$SyntaxError(message, expected, found, location2) {
    var self = Error.call(this, message);
    if (Object.setPrototypeOf) {
      Object.setPrototypeOf(self, peg$SyntaxError.prototype);
    }
    self.expected = expected;
    self.found = found;
    self.location = location2;
    self.name = "SyntaxError";
    return self;
  }
  peg$subclass(peg$SyntaxError, Error);
  function peg$padEnd(str, targetLength, padString) {
    padString = padString || " ";
    if (str.length > targetLength) {
      return str;
    }
    targetLength -= str.length;
    padString += padString.repeat(targetLength);
    return str + padString.slice(0, targetLength);
  }
  peg$SyntaxError.prototype.format = function(sources) {
    var str = "Error: " + this.message;
    if (this.location) {
      var src = null;
      var k;
      for (k = 0; k < sources.length; k++) {
        if (sources[k].source === this.location.source) {
          src = sources[k].text.split(/\r\n|\n|\r/g);
          break;
        }
      }
      var s = this.location.start;
      var offset_s = this.location.source && typeof this.location.source.offset === "function" ? this.location.source.offset(s) : s;
      var loc = this.location.source + ":" + offset_s.line + ":" + offset_s.column;
      if (src) {
        var e = this.location.end;
        var filler = peg$padEnd("", offset_s.line.toString().length, " ");
        var line = src[s.line - 1];
        var last = s.line === e.line ? e.column : line.length + 1;
        var hatLen = last - s.column || 1;
        str += "\n --> " + loc + "\n" + filler + " |\n" + offset_s.line + " | " + line + "\n" + filler + " | " + peg$padEnd("", s.column - 1, " ") + peg$padEnd("", hatLen, "^");
      } else {
        str += "\n at " + loc;
      }
    }
    return str;
  };
  peg$SyntaxError.buildMessage = function(expected, found) {
    var DESCRIBE_EXPECTATION_FNS = {
      literal: function(expectation) {
        return '"' + literalEscape(expectation.text) + '"';
      },
      class: function(expectation) {
        var escapedParts = expectation.parts.map(function(part) {
          return Array.isArray(part) ? classEscape(part[0]) + "-" + classEscape(part[1]) : classEscape(part);
        });
        return "[" + (expectation.inverted ? "^" : "") + escapedParts.join("") + "]";
      },
      any: function() {
        return "any character";
      },
      end: function() {
        return "end of input";
      },
      other: function(expectation) {
        return expectation.description;
      }
    };
    function hex(ch) {
      return ch.charCodeAt(0).toString(16).toUpperCase();
    }
    function literalEscape(s) {
      return s.replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\0/g, "\\0").replace(/\t/g, "\\t").replace(/\n/g, "\\n").replace(/\r/g, "\\r").replace(/[\x00-\x0F]/g, function(ch) {
        return "\\x0" + hex(ch);
      }).replace(/[\x10-\x1F\x7F-\x9F]/g, function(ch) {
        return "\\x" + hex(ch);
      });
    }
    function classEscape(s) {
      return s.replace(/\\/g, "\\\\").replace(/\]/g, "\\]").replace(/\^/g, "\\^").replace(/-/g, "\\-").replace(/\0/g, "\\0").replace(/\t/g, "\\t").replace(/\n/g, "\\n").replace(/\r/g, "\\r").replace(/[\x00-\x0F]/g, function(ch) {
        return "\\x0" + hex(ch);
      }).replace(/[\x10-\x1F\x7F-\x9F]/g, function(ch) {
        return "\\x" + hex(ch);
      });
    }
    function describeExpectation(expectation) {
      return DESCRIBE_EXPECTATION_FNS[expectation.type](expectation);
    }
    function describeExpected(expected2) {
      var descriptions = expected2.map(describeExpectation);
      var i, j;
      descriptions.sort();
      if (descriptions.length > 0) {
        for (i = 1, j = 1; i < descriptions.length; i++) {
          if (descriptions[i - 1] !== descriptions[i]) {
            descriptions[j] = descriptions[i];
            j++;
          }
        }
        descriptions.length = j;
      }
      switch (descriptions.length) {
        case 1:
          return descriptions[0];
        case 2:
          return descriptions[0] + " or " + descriptions[1];
        default:
          return descriptions.slice(0, -1).join(", ") + ", or " + descriptions[descriptions.length - 1];
      }
    }
    function describeFound(found2) {
      return found2 ? '"' + literalEscape(found2) + '"' : "end of input";
    }
    return "Expected " + describeExpected(expected) + " but " + describeFound(found) + " found.";
  };
  function peg$parse(input, options) {
    options = options !== void 0 ? options : {};
    var peg$FAILED = {};
    var peg$source = options.grammarSource;
    var peg$startRuleFunctions = { pgn: peg$parsepgn };
    var peg$startRuleFunction = peg$parsepgn;
    var peg$c0 = "[";
    var peg$c1 = '"';
    var peg$c2 = "]";
    var peg$c3 = ".";
    var peg$c4 = "O-O-O";
    var peg$c5 = "O-O";
    var peg$c6 = "0-0-0";
    var peg$c7 = "0-0";
    var peg$c8 = "$";
    var peg$c9 = "{";
    var peg$c10 = "}";
    var peg$c11 = ";";
    var peg$c12 = "(";
    var peg$c13 = ")";
    var peg$c14 = "1-0";
    var peg$c15 = "0-1";
    var peg$c16 = "1/2-1/2";
    var peg$c17 = "*";
    var peg$r0 = /^[a-zA-Z]/;
    var peg$r1 = /^[^"]/;
    var peg$r2 = /^[0-9]/;
    var peg$r3 = /^[.]/;
    var peg$r4 = /^[a-zA-Z1-8\-=]/;
    var peg$r5 = /^[+#]/;
    var peg$r6 = /^[!?]/;
    var peg$r7 = /^[^}]/;
    var peg$r8 = /^[^\r\n]/;
    var peg$r9 = /^[ \t\r\n]/;
    var peg$e0 = peg$otherExpectation("tag pair");
    var peg$e1 = peg$literalExpectation("[", false);
    var peg$e2 = peg$literalExpectation('"', false);
    var peg$e3 = peg$literalExpectation("]", false);
    var peg$e4 = peg$otherExpectation("tag name");
    var peg$e5 = peg$classExpectation([["a", "z"], ["A", "Z"]], false, false);
    var peg$e6 = peg$otherExpectation("tag value");
    var peg$e7 = peg$classExpectation(['"'], true, false);
    var peg$e8 = peg$otherExpectation("move number");
    var peg$e9 = peg$classExpectation([["0", "9"]], false, false);
    var peg$e10 = peg$literalExpectation(".", false);
    var peg$e11 = peg$classExpectation(["."], false, false);
    var peg$e12 = peg$otherExpectation("standard algebraic notation");
    var peg$e13 = peg$literalExpectation("O-O-O", false);
    var peg$e14 = peg$literalExpectation("O-O", false);
    var peg$e15 = peg$literalExpectation("0-0-0", false);
    var peg$e16 = peg$literalExpectation("0-0", false);
    var peg$e17 = peg$classExpectation([["a", "z"], ["A", "Z"], ["1", "8"], "-", "="], false, false);
    var peg$e18 = peg$classExpectation(["+", "#"], false, false);
    var peg$e19 = peg$otherExpectation("suffix annotation");
    var peg$e20 = peg$classExpectation(["!", "?"], false, false);
    var peg$e21 = peg$otherExpectation("NAG");
    var peg$e22 = peg$literalExpectation("$", false);
    var peg$e23 = peg$otherExpectation("brace comment");
    var peg$e24 = peg$literalExpectation("{", false);
    var peg$e25 = peg$classExpectation(["}"], true, false);
    var peg$e26 = peg$literalExpectation("}", false);
    var peg$e27 = peg$otherExpectation("rest of line comment");
    var peg$e28 = peg$literalExpectation(";", false);
    var peg$e29 = peg$classExpectation(["\r", "\n"], true, false);
    var peg$e30 = peg$otherExpectation("variation");
    var peg$e31 = peg$literalExpectation("(", false);
    var peg$e32 = peg$literalExpectation(")", false);
    var peg$e33 = peg$otherExpectation("game termination marker");
    var peg$e34 = peg$literalExpectation("1-0", false);
    var peg$e35 = peg$literalExpectation("0-1", false);
    var peg$e36 = peg$literalExpectation("1/2-1/2", false);
    var peg$e37 = peg$literalExpectation("*", false);
    var peg$e38 = peg$otherExpectation("whitespace");
    var peg$e39 = peg$classExpectation([" ", "	", "\r", "\n"], false, false);
    var peg$f0 = function(headers, game) {
      return pgn(headers, game);
    };
    var peg$f1 = function(tagPairs) {
      return Object.fromEntries(tagPairs);
    };
    var peg$f2 = function(tagName, tagValue) {
      return [tagName, tagValue];
    };
    var peg$f3 = function(root, marker) {
      return { root, marker };
    };
    var peg$f4 = function(comment, moves) {
      return lineToTree(rootNode(comment), ...moves.flat());
    };
    var peg$f5 = function(san, suffix, nag, comment, variations) {
      return node(san, suffix, nag, comment, variations);
    };
    var peg$f6 = function(nag) {
      return nag;
    };
    var peg$f7 = function(comment) {
      return comment.replace(/[\r\n]+/g, " ");
    };
    var peg$f8 = function(comment) {
      return comment.trim();
    };
    var peg$f9 = function(line) {
      return line;
    };
    var peg$f10 = function(result, comment) {
      return { result, comment };
    };
    var peg$currPos = options.peg$currPos | 0;
    var peg$posDetailsCache = [{ line: 1, column: 1 }];
    var peg$maxFailPos = peg$currPos;
    var peg$maxFailExpected = options.peg$maxFailExpected || [];
    var peg$silentFails = options.peg$silentFails | 0;
    var peg$result;
    if (options.startRule) {
      if (!(options.startRule in peg$startRuleFunctions)) {
        throw new Error(`Can't start parsing from rule "` + options.startRule + '".');
      }
      peg$startRuleFunction = peg$startRuleFunctions[options.startRule];
    }
    function peg$literalExpectation(text, ignoreCase) {
      return { type: "literal", text, ignoreCase };
    }
    function peg$classExpectation(parts, inverted, ignoreCase) {
      return { type: "class", parts, inverted, ignoreCase };
    }
    function peg$endExpectation() {
      return { type: "end" };
    }
    function peg$otherExpectation(description) {
      return { type: "other", description };
    }
    function peg$computePosDetails(pos) {
      var details = peg$posDetailsCache[pos];
      var p;
      if (details) {
        return details;
      } else {
        if (pos >= peg$posDetailsCache.length) {
          p = peg$posDetailsCache.length - 1;
        } else {
          p = pos;
          while (!peg$posDetailsCache[--p]) {
          }
        }
        details = peg$posDetailsCache[p];
        details = {
          line: details.line,
          column: details.column
        };
        while (p < pos) {
          if (input.charCodeAt(p) === 10) {
            details.line++;
            details.column = 1;
          } else {
            details.column++;
          }
          p++;
        }
        peg$posDetailsCache[pos] = details;
        return details;
      }
    }
    function peg$computeLocation(startPos, endPos, offset) {
      var startPosDetails = peg$computePosDetails(startPos);
      var endPosDetails = peg$computePosDetails(endPos);
      var res = {
        source: peg$source,
        start: {
          offset: startPos,
          line: startPosDetails.line,
          column: startPosDetails.column
        },
        end: {
          offset: endPos,
          line: endPosDetails.line,
          column: endPosDetails.column
        }
      };
      return res;
    }
    function peg$fail(expected) {
      if (peg$currPos < peg$maxFailPos) {
        return;
      }
      if (peg$currPos > peg$maxFailPos) {
        peg$maxFailPos = peg$currPos;
        peg$maxFailExpected = [];
      }
      peg$maxFailExpected.push(expected);
    }
    function peg$buildStructuredError(expected, found, location2) {
      return new peg$SyntaxError(
        peg$SyntaxError.buildMessage(expected, found),
        expected,
        found,
        location2
      );
    }
    function peg$parsepgn() {
      var s0, s1, s2;
      s0 = peg$currPos;
      s1 = peg$parsetagPairSection();
      s2 = peg$parsemoveTextSection();
      s0 = peg$f0(s1, s2);
      return s0;
    }
    function peg$parsetagPairSection() {
      var s0, s1, s2;
      s0 = peg$currPos;
      s1 = [];
      s2 = peg$parsetagPair();
      while (s2 !== peg$FAILED) {
        s1.push(s2);
        s2 = peg$parsetagPair();
      }
      s2 = peg$parse_();
      s0 = peg$f1(s1);
      return s0;
    }
    function peg$parsetagPair() {
      var s0, s2, s4, s6, s7, s8, s10;
      peg$silentFails++;
      s0 = peg$currPos;
      peg$parse_();
      if (input.charCodeAt(peg$currPos) === 91) {
        s2 = peg$c0;
        peg$currPos++;
      } else {
        s2 = peg$FAILED;
        if (peg$silentFails === 0) {
          peg$fail(peg$e1);
        }
      }
      if (s2 !== peg$FAILED) {
        peg$parse_();
        s4 = peg$parsetagName();
        if (s4 !== peg$FAILED) {
          peg$parse_();
          if (input.charCodeAt(peg$currPos) === 34) {
            s6 = peg$c1;
            peg$currPos++;
          } else {
            s6 = peg$FAILED;
            if (peg$silentFails === 0) {
              peg$fail(peg$e2);
            }
          }
          if (s6 !== peg$FAILED) {
            s7 = peg$parsetagValue();
            if (input.charCodeAt(peg$currPos) === 34) {
              s8 = peg$c1;
              peg$currPos++;
            } else {
              s8 = peg$FAILED;
              if (peg$silentFails === 0) {
                peg$fail(peg$e2);
              }
            }
            if (s8 !== peg$FAILED) {
              peg$parse_();
              if (input.charCodeAt(peg$currPos) === 93) {
                s10 = peg$c2;
                peg$currPos++;
              } else {
                s10 = peg$FAILED;
                if (peg$silentFails === 0) {
                  peg$fail(peg$e3);
                }
              }
              if (s10 !== peg$FAILED) {
                s0 = peg$f2(s4, s7);
              } else {
                peg$currPos = s0;
                s0 = peg$FAILED;
              }
            } else {
              peg$currPos = s0;
              s0 = peg$FAILED;
            }
          } else {
            peg$currPos = s0;
            s0 = peg$FAILED;
          }
        } else {
          peg$currPos = s0;
          s0 = peg$FAILED;
        }
      } else {
        peg$currPos = s0;
        s0 = peg$FAILED;
      }
      peg$silentFails--;
      if (s0 === peg$FAILED) {
        if (peg$silentFails === 0) {
          peg$fail(peg$e0);
        }
      }
      return s0;
    }
    function peg$parsetagName() {
      var s0, s1, s2;
      peg$silentFails++;
      s0 = peg$currPos;
      s1 = [];
      s2 = input.charAt(peg$currPos);
      if (peg$r0.test(s2)) {
        peg$currPos++;
      } else {
        s2 = peg$FAILED;
        if (peg$silentFails === 0) {
          peg$fail(peg$e5);
        }
      }
      if (s2 !== peg$FAILED) {
        while (s2 !== peg$FAILED) {
          s1.push(s2);
          s2 = input.charAt(peg$currPos);
          if (peg$r0.test(s2)) {
            peg$currPos++;
          } else {
            s2 = peg$FAILED;
            if (peg$silentFails === 0) {
              peg$fail(peg$e5);
            }
          }
        }
      } else {
        s1 = peg$FAILED;
      }
      if (s1 !== peg$FAILED) {
        s0 = input.substring(s0, peg$currPos);
      } else {
        s0 = s1;
      }
      peg$silentFails--;
      if (s0 === peg$FAILED) {
        s1 = peg$FAILED;
        if (peg$silentFails === 0) {
          peg$fail(peg$e4);
        }
      }
      return s0;
    }
    function peg$parsetagValue() {
      var s0, s1, s2;
      peg$silentFails++;
      s0 = peg$currPos;
      s1 = [];
      s2 = input.charAt(peg$currPos);
      if (peg$r1.test(s2)) {
        peg$currPos++;
      } else {
        s2 = peg$FAILED;
        if (peg$silentFails === 0) {
          peg$fail(peg$e7);
        }
      }
      while (s2 !== peg$FAILED) {
        s1.push(s2);
        s2 = input.charAt(peg$currPos);
        if (peg$r1.test(s2)) {
          peg$currPos++;
        } else {
          s2 = peg$FAILED;
          if (peg$silentFails === 0) {
            peg$fail(peg$e7);
          }
        }
      }
      s0 = input.substring(s0, peg$currPos);
      peg$silentFails--;
      s1 = peg$FAILED;
      if (peg$silentFails === 0) {
        peg$fail(peg$e6);
      }
      return s0;
    }
    function peg$parsemoveTextSection() {
      var s0, s1, s3;
      s0 = peg$currPos;
      s1 = peg$parseline();
      peg$parse_();
      s3 = peg$parsegameTerminationMarker();
      if (s3 === peg$FAILED) {
        s3 = null;
      }
      peg$parse_();
      s0 = peg$f3(s1, s3);
      return s0;
    }
    function peg$parseline() {
      var s0, s1, s2, s3;
      s0 = peg$currPos;
      s1 = peg$parsecomment();
      if (s1 === peg$FAILED) {
        s1 = null;
      }
      s2 = [];
      s3 = peg$parsemove();
      while (s3 !== peg$FAILED) {
        s2.push(s3);
        s3 = peg$parsemove();
      }
      s0 = peg$f4(s1, s2);
      return s0;
    }
    function peg$parsemove() {
      var s0, s4, s5, s6, s7, s8, s9, s10;
      s0 = peg$currPos;
      peg$parse_();
      peg$parsemoveNumber();
      peg$parse_();
      s4 = peg$parsesan();
      if (s4 !== peg$FAILED) {
        s5 = peg$parsesuffixAnnotation();
        if (s5 === peg$FAILED) {
          s5 = null;
        }
        s6 = [];
        s7 = peg$parsenag();
        while (s7 !== peg$FAILED) {
          s6.push(s7);
          s7 = peg$parsenag();
        }
        s7 = peg$parse_();
        s8 = peg$parsecomment();
        if (s8 === peg$FAILED) {
          s8 = null;
        }
        s9 = [];
        s10 = peg$parsevariation();
        while (s10 !== peg$FAILED) {
          s9.push(s10);
          s10 = peg$parsevariation();
        }
        s0 = peg$f5(s4, s5, s6, s8, s9);
      } else {
        peg$currPos = s0;
        s0 = peg$FAILED;
      }
      return s0;
    }
    function peg$parsemoveNumber() {
      var s0, s1, s2, s3, s4, s5;
      peg$silentFails++;
      s0 = peg$currPos;
      s1 = [];
      s2 = input.charAt(peg$currPos);
      if (peg$r2.test(s2)) {
        peg$currPos++;
      } else {
        s2 = peg$FAILED;
        if (peg$silentFails === 0) {
          peg$fail(peg$e9);
        }
      }
      while (s2 !== peg$FAILED) {
        s1.push(s2);
        s2 = input.charAt(peg$currPos);
        if (peg$r2.test(s2)) {
          peg$currPos++;
        } else {
          s2 = peg$FAILED;
          if (peg$silentFails === 0) {
            peg$fail(peg$e9);
          }
        }
      }
      if (input.charCodeAt(peg$currPos) === 46) {
        s2 = peg$c3;
        peg$currPos++;
      } else {
        s2 = peg$FAILED;
        if (peg$silentFails === 0) {
          peg$fail(peg$e10);
        }
      }
      if (s2 !== peg$FAILED) {
        s3 = peg$parse_();
        s4 = [];
        s5 = input.charAt(peg$currPos);
        if (peg$r3.test(s5)) {
          peg$currPos++;
        } else {
          s5 = peg$FAILED;
          if (peg$silentFails === 0) {
            peg$fail(peg$e11);
          }
        }
        while (s5 !== peg$FAILED) {
          s4.push(s5);
          s5 = input.charAt(peg$currPos);
          if (peg$r3.test(s5)) {
            peg$currPos++;
          } else {
            s5 = peg$FAILED;
            if (peg$silentFails === 0) {
              peg$fail(peg$e11);
            }
          }
        }
        s1 = [s1, s2, s3, s4];
        s0 = s1;
      } else {
        peg$currPos = s0;
        s0 = peg$FAILED;
      }
      peg$silentFails--;
      if (s0 === peg$FAILED) {
        s1 = peg$FAILED;
        if (peg$silentFails === 0) {
          peg$fail(peg$e8);
        }
      }
      return s0;
    }
    function peg$parsesan() {
      var s0, s1, s2, s3, s4, s5;
      peg$silentFails++;
      s0 = peg$currPos;
      s1 = peg$currPos;
      if (input.substr(peg$currPos, 5) === peg$c4) {
        s2 = peg$c4;
        peg$currPos += 5;
      } else {
        s2 = peg$FAILED;
        if (peg$silentFails === 0) {
          peg$fail(peg$e13);
        }
      }
      if (s2 === peg$FAILED) {
        if (input.substr(peg$currPos, 3) === peg$c5) {
          s2 = peg$c5;
          peg$currPos += 3;
        } else {
          s2 = peg$FAILED;
          if (peg$silentFails === 0) {
            peg$fail(peg$e14);
          }
        }
        if (s2 === peg$FAILED) {
          if (input.substr(peg$currPos, 5) === peg$c6) {
            s2 = peg$c6;
            peg$currPos += 5;
          } else {
            s2 = peg$FAILED;
            if (peg$silentFails === 0) {
              peg$fail(peg$e15);
            }
          }
          if (s2 === peg$FAILED) {
            if (input.substr(peg$currPos, 3) === peg$c7) {
              s2 = peg$c7;
              peg$currPos += 3;
            } else {
              s2 = peg$FAILED;
              if (peg$silentFails === 0) {
                peg$fail(peg$e16);
              }
            }
            if (s2 === peg$FAILED) {
              s2 = peg$currPos;
              s3 = input.charAt(peg$currPos);
              if (peg$r0.test(s3)) {
                peg$currPos++;
              } else {
                s3 = peg$FAILED;
                if (peg$silentFails === 0) {
                  peg$fail(peg$e5);
                }
              }
              if (s3 !== peg$FAILED) {
                s4 = [];
                s5 = input.charAt(peg$currPos);
                if (peg$r4.test(s5)) {
                  peg$currPos++;
                } else {
                  s5 = peg$FAILED;
                  if (peg$silentFails === 0) {
                    peg$fail(peg$e17);
                  }
                }
                if (s5 !== peg$FAILED) {
                  while (s5 !== peg$FAILED) {
                    s4.push(s5);
                    s5 = input.charAt(peg$currPos);
                    if (peg$r4.test(s5)) {
                      peg$currPos++;
                    } else {
                      s5 = peg$FAILED;
                      if (peg$silentFails === 0) {
                        peg$fail(peg$e17);
                      }
                    }
                  }
                } else {
                  s4 = peg$FAILED;
                }
                if (s4 !== peg$FAILED) {
                  s3 = [s3, s4];
                  s2 = s3;
                } else {
                  peg$currPos = s2;
                  s2 = peg$FAILED;
                }
              } else {
                peg$currPos = s2;
                s2 = peg$FAILED;
              }
            }
          }
        }
      }
      if (s2 !== peg$FAILED) {
        s3 = input.charAt(peg$currPos);
        if (peg$r5.test(s3)) {
          peg$currPos++;
        } else {
          s3 = peg$FAILED;
          if (peg$silentFails === 0) {
            peg$fail(peg$e18);
          }
        }
        if (s3 === peg$FAILED) {
          s3 = null;
        }
        s2 = [s2, s3];
        s1 = s2;
      } else {
        peg$currPos = s1;
        s1 = peg$FAILED;
      }
      if (s1 !== peg$FAILED) {
        s0 = input.substring(s0, peg$currPos);
      } else {
        s0 = s1;
      }
      peg$silentFails--;
      if (s0 === peg$FAILED) {
        s1 = peg$FAILED;
        if (peg$silentFails === 0) {
          peg$fail(peg$e12);
        }
      }
      return s0;
    }
    function peg$parsesuffixAnnotation() {
      var s0, s1, s2;
      peg$silentFails++;
      s0 = peg$currPos;
      s1 = [];
      s2 = input.charAt(peg$currPos);
      if (peg$r6.test(s2)) {
        peg$currPos++;
      } else {
        s2 = peg$FAILED;
        if (peg$silentFails === 0) {
          peg$fail(peg$e20);
        }
      }
      while (s2 !== peg$FAILED) {
        s1.push(s2);
        if (s1.length >= 2) {
          s2 = peg$FAILED;
        } else {
          s2 = input.charAt(peg$currPos);
          if (peg$r6.test(s2)) {
            peg$currPos++;
          } else {
            s2 = peg$FAILED;
            if (peg$silentFails === 0) {
              peg$fail(peg$e20);
            }
          }
        }
      }
      if (s1.length < 1) {
        peg$currPos = s0;
        s0 = peg$FAILED;
      } else {
        s0 = s1;
      }
      peg$silentFails--;
      if (s0 === peg$FAILED) {
        s1 = peg$FAILED;
        if (peg$silentFails === 0) {
          peg$fail(peg$e19);
        }
      }
      return s0;
    }
    function peg$parsenag() {
      var s0, s2, s3, s4, s5;
      peg$silentFails++;
      s0 = peg$currPos;
      peg$parse_();
      if (input.charCodeAt(peg$currPos) === 36) {
        s2 = peg$c8;
        peg$currPos++;
      } else {
        s2 = peg$FAILED;
        if (peg$silentFails === 0) {
          peg$fail(peg$e22);
        }
      }
      if (s2 !== peg$FAILED) {
        s3 = peg$currPos;
        s4 = [];
        s5 = input.charAt(peg$currPos);
        if (peg$r2.test(s5)) {
          peg$currPos++;
        } else {
          s5 = peg$FAILED;
          if (peg$silentFails === 0) {
            peg$fail(peg$e9);
          }
        }
        if (s5 !== peg$FAILED) {
          while (s5 !== peg$FAILED) {
            s4.push(s5);
            s5 = input.charAt(peg$currPos);
            if (peg$r2.test(s5)) {
              peg$currPos++;
            } else {
              s5 = peg$FAILED;
              if (peg$silentFails === 0) {
                peg$fail(peg$e9);
              }
            }
          }
        } else {
          s4 = peg$FAILED;
        }
        if (s4 !== peg$FAILED) {
          s3 = input.substring(s3, peg$currPos);
        } else {
          s3 = s4;
        }
        if (s3 !== peg$FAILED) {
          s0 = peg$f6(s3);
        } else {
          peg$currPos = s0;
          s0 = peg$FAILED;
        }
      } else {
        peg$currPos = s0;
        s0 = peg$FAILED;
      }
      peg$silentFails--;
      if (s0 === peg$FAILED) {
        if (peg$silentFails === 0) {
          peg$fail(peg$e21);
        }
      }
      return s0;
    }
    function peg$parsecomment() {
      var s0;
      s0 = peg$parsebraceComment();
      if (s0 === peg$FAILED) {
        s0 = peg$parserestOfLineComment();
      }
      return s0;
    }
    function peg$parsebraceComment() {
      var s0, s1, s2, s3, s4;
      peg$silentFails++;
      s0 = peg$currPos;
      if (input.charCodeAt(peg$currPos) === 123) {
        s1 = peg$c9;
        peg$currPos++;
      } else {
        s1 = peg$FAILED;
        if (peg$silentFails === 0) {
          peg$fail(peg$e24);
        }
      }
      if (s1 !== peg$FAILED) {
        s2 = peg$currPos;
        s3 = [];
        s4 = input.charAt(peg$currPos);
        if (peg$r7.test(s4)) {
          peg$currPos++;
        } else {
          s4 = peg$FAILED;
          if (peg$silentFails === 0) {
            peg$fail(peg$e25);
          }
        }
        while (s4 !== peg$FAILED) {
          s3.push(s4);
          s4 = input.charAt(peg$currPos);
          if (peg$r7.test(s4)) {
            peg$currPos++;
          } else {
            s4 = peg$FAILED;
            if (peg$silentFails === 0) {
              peg$fail(peg$e25);
            }
          }
        }
        s2 = input.substring(s2, peg$currPos);
        if (input.charCodeAt(peg$currPos) === 125) {
          s3 = peg$c10;
          peg$currPos++;
        } else {
          s3 = peg$FAILED;
          if (peg$silentFails === 0) {
            peg$fail(peg$e26);
          }
        }
        if (s3 !== peg$FAILED) {
          s0 = peg$f7(s2);
        } else {
          peg$currPos = s0;
          s0 = peg$FAILED;
        }
      } else {
        peg$currPos = s0;
        s0 = peg$FAILED;
      }
      peg$silentFails--;
      if (s0 === peg$FAILED) {
        s1 = peg$FAILED;
        if (peg$silentFails === 0) {
          peg$fail(peg$e23);
        }
      }
      return s0;
    }
    function peg$parserestOfLineComment() {
      var s0, s1, s2, s3, s4;
      peg$silentFails++;
      s0 = peg$currPos;
      if (input.charCodeAt(peg$currPos) === 59) {
        s1 = peg$c11;
        peg$currPos++;
      } else {
        s1 = peg$FAILED;
        if (peg$silentFails === 0) {
          peg$fail(peg$e28);
        }
      }
      if (s1 !== peg$FAILED) {
        s2 = peg$currPos;
        s3 = [];
        s4 = input.charAt(peg$currPos);
        if (peg$r8.test(s4)) {
          peg$currPos++;
        } else {
          s4 = peg$FAILED;
          if (peg$silentFails === 0) {
            peg$fail(peg$e29);
          }
        }
        while (s4 !== peg$FAILED) {
          s3.push(s4);
          s4 = input.charAt(peg$currPos);
          if (peg$r8.test(s4)) {
            peg$currPos++;
          } else {
            s4 = peg$FAILED;
            if (peg$silentFails === 0) {
              peg$fail(peg$e29);
            }
          }
        }
        s2 = input.substring(s2, peg$currPos);
        s0 = peg$f8(s2);
      } else {
        peg$currPos = s0;
        s0 = peg$FAILED;
      }
      peg$silentFails--;
      if (s0 === peg$FAILED) {
        s1 = peg$FAILED;
        if (peg$silentFails === 0) {
          peg$fail(peg$e27);
        }
      }
      return s0;
    }
    function peg$parsevariation() {
      var s0, s2, s3, s5;
      peg$silentFails++;
      s0 = peg$currPos;
      peg$parse_();
      if (input.charCodeAt(peg$currPos) === 40) {
        s2 = peg$c12;
        peg$currPos++;
      } else {
        s2 = peg$FAILED;
        if (peg$silentFails === 0) {
          peg$fail(peg$e31);
        }
      }
      if (s2 !== peg$FAILED) {
        s3 = peg$parseline();
        if (s3 !== peg$FAILED) {
          peg$parse_();
          if (input.charCodeAt(peg$currPos) === 41) {
            s5 = peg$c13;
            peg$currPos++;
          } else {
            s5 = peg$FAILED;
            if (peg$silentFails === 0) {
              peg$fail(peg$e32);
            }
          }
          if (s5 !== peg$FAILED) {
            s0 = peg$f9(s3);
          } else {
            peg$currPos = s0;
            s0 = peg$FAILED;
          }
        } else {
          peg$currPos = s0;
          s0 = peg$FAILED;
        }
      } else {
        peg$currPos = s0;
        s0 = peg$FAILED;
      }
      peg$silentFails--;
      if (s0 === peg$FAILED) {
        if (peg$silentFails === 0) {
          peg$fail(peg$e30);
        }
      }
      return s0;
    }
    function peg$parsegameTerminationMarker() {
      var s0, s1, s3;
      peg$silentFails++;
      s0 = peg$currPos;
      if (input.substr(peg$currPos, 3) === peg$c14) {
        s1 = peg$c14;
        peg$currPos += 3;
      } else {
        s1 = peg$FAILED;
        if (peg$silentFails === 0) {
          peg$fail(peg$e34);
        }
      }
      if (s1 === peg$FAILED) {
        if (input.substr(peg$currPos, 3) === peg$c15) {
          s1 = peg$c15;
          peg$currPos += 3;
        } else {
          s1 = peg$FAILED;
          if (peg$silentFails === 0) {
            peg$fail(peg$e35);
          }
        }
        if (s1 === peg$FAILED) {
          if (input.substr(peg$currPos, 7) === peg$c16) {
            s1 = peg$c16;
            peg$currPos += 7;
          } else {
            s1 = peg$FAILED;
            if (peg$silentFails === 0) {
              peg$fail(peg$e36);
            }
          }
          if (s1 === peg$FAILED) {
            if (input.charCodeAt(peg$currPos) === 42) {
              s1 = peg$c17;
              peg$currPos++;
            } else {
              s1 = peg$FAILED;
              if (peg$silentFails === 0) {
                peg$fail(peg$e37);
              }
            }
          }
        }
      }
      if (s1 !== peg$FAILED) {
        peg$parse_();
        s3 = peg$parsecomment();
        if (s3 === peg$FAILED) {
          s3 = null;
        }
        s0 = peg$f10(s1, s3);
      } else {
        peg$currPos = s0;
        s0 = peg$FAILED;
      }
      peg$silentFails--;
      if (s0 === peg$FAILED) {
        s1 = peg$FAILED;
        if (peg$silentFails === 0) {
          peg$fail(peg$e33);
        }
      }
      return s0;
    }
    function peg$parse_() {
      var s0, s1;
      peg$silentFails++;
      s0 = [];
      s1 = input.charAt(peg$currPos);
      if (peg$r9.test(s1)) {
        peg$currPos++;
      } else {
        s1 = peg$FAILED;
        if (peg$silentFails === 0) {
          peg$fail(peg$e39);
        }
      }
      while (s1 !== peg$FAILED) {
        s0.push(s1);
        s1 = input.charAt(peg$currPos);
        if (peg$r9.test(s1)) {
          peg$currPos++;
        } else {
          s1 = peg$FAILED;
          if (peg$silentFails === 0) {
            peg$fail(peg$e39);
          }
        }
      }
      peg$silentFails--;
      s1 = peg$FAILED;
      if (peg$silentFails === 0) {
        peg$fail(peg$e38);
      }
      return s0;
    }
    peg$result = peg$startRuleFunction();
    if (options.peg$library) {
      return (
        /** @type {any} */
        {
          peg$result,
          peg$currPos,
          peg$FAILED,
          peg$maxFailExpected,
          peg$maxFailPos
        }
      );
    }
    if (peg$result !== peg$FAILED && peg$currPos === input.length) {
      return peg$result;
    } else {
      if (peg$result !== peg$FAILED && peg$currPos < input.length) {
        peg$fail(peg$endExpectation());
      }
      throw peg$buildStructuredError(
        peg$maxFailExpected,
        peg$maxFailPos < input.length ? input.charAt(peg$maxFailPos) : null,
        peg$maxFailPos < input.length ? peg$computeLocation(peg$maxFailPos, peg$maxFailPos + 1) : peg$computeLocation(peg$maxFailPos, peg$maxFailPos)
      );
    }
  }
  var MASK64 = 0xffffffffffffffffn;
  function rotl(x, k) {
    return (x << k | x >> 64n - k) & 0xffffffffffffffffn;
  }
  function wrappingMul(x, y) {
    return x * y & MASK64;
  }
  function xoroshiro128(state) {
    return function() {
      let s0 = BigInt(state & MASK64);
      let s1 = BigInt(state >> 64n & MASK64);
      const result = wrappingMul(rotl(wrappingMul(s0, 5n), 7n), 9n);
      s1 ^= s0;
      s0 = (rotl(s0, 24n) ^ s1 ^ s1 << 16n) & MASK64;
      s1 = rotl(s1, 37n);
      state = s1 << 64n | s0;
      return result;
    };
  }
  var rand = xoroshiro128(0xa187eb39cdcaed8f31c4b365b102e01en);
  var PIECE_KEYS = Array.from({ length: 2 }, () => Array.from({ length: 6 }, () => Array.from({ length: 128 }, () => rand())));
  var EP_KEYS = Array.from({ length: 8 }, () => rand());
  var CASTLING_KEYS = Array.from({ length: 16 }, () => rand());
  var SIDE_KEY = rand();
  var WHITE = "w";
  var BLACK = "b";
  var PAWN = "p";
  var KNIGHT = "n";
  var BISHOP = "b";
  var ROOK = "r";
  var QUEEN = "q";
  var KING = "k";
  var DEFAULT_POSITION = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";
  var Move = class {
    color;
    from;
    to;
    piece;
    captured;
    promotion;
    /**
     * @deprecated This field is deprecated and will be removed in version 2.0.0.
     * Please use move descriptor functions instead: `isCapture`, `isPromotion`,
     * `isEnPassant`, `isKingsideCastle`, `isQueensideCastle`, `isCastle`, and
     * `isBigPawn`
     */
    flags;
    san;
    lan;
    before;
    after;
    constructor(chess, internal) {
      const { color, piece, from, to, flags, captured, promotion } = internal;
      const fromAlgebraic = algebraic(from);
      const toAlgebraic = algebraic(to);
      this.color = color;
      this.piece = piece;
      this.from = fromAlgebraic;
      this.to = toAlgebraic;
      this.san = chess["_moveToSan"](internal, chess["_moves"]({ legal: true }));
      this.lan = fromAlgebraic + toAlgebraic;
      this.before = chess.fen();
      chess["_makeMove"](internal);
      this.after = chess.fen();
      chess["_undoMove"]();
      this.flags = "";
      for (const flag in BITS) {
        if (BITS[flag] & flags) {
          this.flags += FLAGS[flag];
        }
      }
      if (captured) {
        this.captured = captured;
      }
      if (promotion) {
        this.promotion = promotion;
        this.lan += promotion;
      }
    }
    isCapture() {
      return this.flags.indexOf(FLAGS["CAPTURE"]) > -1;
    }
    isPromotion() {
      return this.flags.indexOf(FLAGS["PROMOTION"]) > -1;
    }
    isEnPassant() {
      return this.flags.indexOf(FLAGS["EP_CAPTURE"]) > -1;
    }
    isKingsideCastle() {
      return this.flags.indexOf(FLAGS["KSIDE_CASTLE"]) > -1;
    }
    isQueensideCastle() {
      return this.flags.indexOf(FLAGS["QSIDE_CASTLE"]) > -1;
    }
    isBigPawn() {
      return this.flags.indexOf(FLAGS["BIG_PAWN"]) > -1;
    }
  };
  var EMPTY = -1;
  var FLAGS = {
    NORMAL: "n",
    CAPTURE: "c",
    BIG_PAWN: "b",
    EP_CAPTURE: "e",
    PROMOTION: "p",
    KSIDE_CASTLE: "k",
    QSIDE_CASTLE: "q",
    NULL_MOVE: "-"
  };
  var BITS = {
    NORMAL: 1,
    CAPTURE: 2,
    BIG_PAWN: 4,
    EP_CAPTURE: 8,
    PROMOTION: 16,
    KSIDE_CASTLE: 32,
    QSIDE_CASTLE: 64,
    NULL_MOVE: 128
  };
  var SEVEN_TAG_ROSTER = {
    Event: "?",
    Site: "?",
    Date: "????.??.??",
    Round: "?",
    White: "?",
    Black: "?",
    Result: "*"
  };
  var SUPLEMENTAL_TAGS = {
    WhiteTitle: null,
    BlackTitle: null,
    WhiteElo: null,
    BlackElo: null,
    WhiteUSCF: null,
    BlackUSCF: null,
    WhiteNA: null,
    BlackNA: null,
    WhiteType: null,
    BlackType: null,
    EventDate: null,
    EventSponsor: null,
    Section: null,
    Stage: null,
    Board: null,
    Opening: null,
    Variation: null,
    SubVariation: null,
    ECO: null,
    NIC: null,
    Time: null,
    UTCTime: null,
    UTCDate: null,
    TimeControl: null,
    SetUp: null,
    FEN: null,
    Termination: null,
    Annotator: null,
    Mode: null,
    PlyCount: null
  };
  var HEADER_TEMPLATE = {
    ...SEVEN_TAG_ROSTER,
    ...SUPLEMENTAL_TAGS
  };
  var Ox88 = {
    a8: 0,
    b8: 1,
    c8: 2,
    d8: 3,
    e8: 4,
    f8: 5,
    g8: 6,
    h8: 7,
    a7: 16,
    b7: 17,
    c7: 18,
    d7: 19,
    e7: 20,
    f7: 21,
    g7: 22,
    h7: 23,
    a6: 32,
    b6: 33,
    c6: 34,
    d6: 35,
    e6: 36,
    f6: 37,
    g6: 38,
    h6: 39,
    a5: 48,
    b5: 49,
    c5: 50,
    d5: 51,
    e5: 52,
    f5: 53,
    g5: 54,
    h5: 55,
    a4: 64,
    b4: 65,
    c4: 66,
    d4: 67,
    e4: 68,
    f4: 69,
    g4: 70,
    h4: 71,
    a3: 80,
    b3: 81,
    c3: 82,
    d3: 83,
    e3: 84,
    f3: 85,
    g3: 86,
    h3: 87,
    a2: 96,
    b2: 97,
    c2: 98,
    d2: 99,
    e2: 100,
    f2: 101,
    g2: 102,
    h2: 103,
    a1: 112,
    b1: 113,
    c1: 114,
    d1: 115,
    e1: 116,
    f1: 117,
    g1: 118,
    h1: 119
  };
  var PAWN_OFFSETS = {
    b: [16, 32, 17, 15],
    w: [-16, -32, -17, -15]
  };
  var PIECE_OFFSETS = {
    n: [-18, -33, -31, -14, 18, 33, 31, 14],
    b: [-17, -15, 17, 15],
    r: [-16, 1, 16, -1],
    q: [-17, -16, -15, 1, 17, 16, 15, -1],
    k: [-17, -16, -15, 1, 17, 16, 15, -1]
  };
  var ATTACKS = [
    20,
    0,
    0,
    0,
    0,
    0,
    0,
    24,
    0,
    0,
    0,
    0,
    0,
    0,
    20,
    0,
    0,
    20,
    0,
    0,
    0,
    0,
    0,
    24,
    0,
    0,
    0,
    0,
    0,
    20,
    0,
    0,
    0,
    0,
    20,
    0,
    0,
    0,
    0,
    24,
    0,
    0,
    0,
    0,
    20,
    0,
    0,
    0,
    0,
    0,
    0,
    20,
    0,
    0,
    0,
    24,
    0,
    0,
    0,
    20,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    20,
    0,
    0,
    24,
    0,
    0,
    20,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    20,
    2,
    24,
    2,
    20,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    2,
    53,
    56,
    53,
    2,
    0,
    0,
    0,
    0,
    0,
    0,
    24,
    24,
    24,
    24,
    24,
    24,
    56,
    0,
    56,
    24,
    24,
    24,
    24,
    24,
    24,
    0,
    0,
    0,
    0,
    0,
    0,
    2,
    53,
    56,
    53,
    2,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    20,
    2,
    24,
    2,
    20,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    20,
    0,
    0,
    24,
    0,
    0,
    20,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    20,
    0,
    0,
    0,
    24,
    0,
    0,
    0,
    20,
    0,
    0,
    0,
    0,
    0,
    0,
    20,
    0,
    0,
    0,
    0,
    24,
    0,
    0,
    0,
    0,
    20,
    0,
    0,
    0,
    0,
    20,
    0,
    0,
    0,
    0,
    0,
    24,
    0,
    0,
    0,
    0,
    0,
    20,
    0,
    0,
    20,
    0,
    0,
    0,
    0,
    0,
    0,
    24,
    0,
    0,
    0,
    0,
    0,
    0,
    20
  ];
  var RAYS = [
    17,
    0,
    0,
    0,
    0,
    0,
    0,
    16,
    0,
    0,
    0,
    0,
    0,
    0,
    15,
    0,
    0,
    17,
    0,
    0,
    0,
    0,
    0,
    16,
    0,
    0,
    0,
    0,
    0,
    15,
    0,
    0,
    0,
    0,
    17,
    0,
    0,
    0,
    0,
    16,
    0,
    0,
    0,
    0,
    15,
    0,
    0,
    0,
    0,
    0,
    0,
    17,
    0,
    0,
    0,
    16,
    0,
    0,
    0,
    15,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    17,
    0,
    0,
    16,
    0,
    0,
    15,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    17,
    0,
    16,
    0,
    15,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    17,
    16,
    15,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    1,
    1,
    1,
    1,
    1,
    1,
    1,
    0,
    -1,
    -1,
    -1,
    -1,
    -1,
    -1,
    -1,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    -15,
    -16,
    -17,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    -15,
    0,
    -16,
    0,
    -17,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    -15,
    0,
    0,
    -16,
    0,
    0,
    -17,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    -15,
    0,
    0,
    0,
    -16,
    0,
    0,
    0,
    -17,
    0,
    0,
    0,
    0,
    0,
    0,
    -15,
    0,
    0,
    0,
    0,
    -16,
    0,
    0,
    0,
    0,
    -17,
    0,
    0,
    0,
    0,
    -15,
    0,
    0,
    0,
    0,
    0,
    -16,
    0,
    0,
    0,
    0,
    0,
    -17,
    0,
    0,
    -15,
    0,
    0,
    0,
    0,
    0,
    0,
    -16,
    0,
    0,
    0,
    0,
    0,
    0,
    -17
  ];
  var PIECE_MASKS = { p: 1, n: 2, b: 4, r: 8, q: 16, k: 32 };
  var SYMBOLS = "pnbrqkPNBRQK";
  var PROMOTIONS = [KNIGHT, BISHOP, ROOK, QUEEN];
  var RANK_1 = 7;
  var RANK_2 = 6;
  var RANK_7 = 1;
  var RANK_8 = 0;
  var SIDES = {
    [KING]: BITS.KSIDE_CASTLE,
    [QUEEN]: BITS.QSIDE_CASTLE
  };
  var ROOKS = {
    w: [
      { square: Ox88.a1, flag: BITS.QSIDE_CASTLE },
      { square: Ox88.h1, flag: BITS.KSIDE_CASTLE }
    ],
    b: [
      { square: Ox88.a8, flag: BITS.QSIDE_CASTLE },
      { square: Ox88.h8, flag: BITS.KSIDE_CASTLE }
    ]
  };
  var SECOND_RANK = { b: RANK_7, w: RANK_2 };
  var SAN_NULLMOVE = "--";
  function rank(square) {
    return square >> 4;
  }
  function file(square) {
    return square & 15;
  }
  function isDigit(c) {
    return "0123456789".indexOf(c) !== -1;
  }
  function algebraic(square) {
    const f = file(square);
    const r = rank(square);
    return "abcdefgh".substring(f, f + 1) + "87654321".substring(r, r + 1);
  }
  function swapColor(color) {
    return color === WHITE ? BLACK : WHITE;
  }
  function validateFen(fen) {
    const tokens = fen.split(/\s+/);
    if (tokens.length !== 6) {
      return {
        ok: false,
        error: "Invalid FEN: must contain six space-delimited fields"
      };
    }
    const moveNumber = parseInt(tokens[5], 10);
    if (isNaN(moveNumber) || moveNumber <= 0) {
      return {
        ok: false,
        error: "Invalid FEN: move number must be a positive integer"
      };
    }
    const halfMoves = parseInt(tokens[4], 10);
    if (isNaN(halfMoves) || halfMoves < 0) {
      return {
        ok: false,
        error: "Invalid FEN: half move counter number must be a non-negative integer"
      };
    }
    if (!/^(-|[abcdefgh][36])$/.test(tokens[3])) {
      return { ok: false, error: "Invalid FEN: en-passant square is invalid" };
    }
    if (/[^kKqQ-]/.test(tokens[2])) {
      return { ok: false, error: "Invalid FEN: castling availability is invalid" };
    }
    if (!/^(w|b)$/.test(tokens[1])) {
      return { ok: false, error: "Invalid FEN: side-to-move is invalid" };
    }
    const rows = tokens[0].split("/");
    if (rows.length !== 8) {
      return {
        ok: false,
        error: "Invalid FEN: piece data does not contain 8 '/'-delimited rows"
      };
    }
    for (let i = 0; i < rows.length; i++) {
      let sumFields = 0;
      let previousWasNumber = false;
      for (let k = 0; k < rows[i].length; k++) {
        if (isDigit(rows[i][k])) {
          if (previousWasNumber) {
            return {
              ok: false,
              error: "Invalid FEN: piece data is invalid (consecutive number)"
            };
          }
          sumFields += parseInt(rows[i][k], 10);
          previousWasNumber = true;
        } else {
          if (!/^[prnbqkPRNBQK]$/.test(rows[i][k])) {
            return {
              ok: false,
              error: "Invalid FEN: piece data is invalid (invalid piece)"
            };
          }
          sumFields += 1;
          previousWasNumber = false;
        }
      }
      if (sumFields !== 8) {
        return {
          ok: false,
          error: "Invalid FEN: piece data is invalid (too many squares in rank)"
        };
      }
    }
    if (tokens[3][1] == "3" && tokens[1] == "w" || tokens[3][1] == "6" && tokens[1] == "b") {
      return { ok: false, error: "Invalid FEN: illegal en-passant square" };
    }
    const kings = [
      { color: "white", regex: /K/g },
      { color: "black", regex: /k/g }
    ];
    for (const { color, regex } of kings) {
      if (!regex.test(tokens[0])) {
        return { ok: false, error: `Invalid FEN: missing ${color} king` };
      }
      if ((tokens[0].match(regex) || []).length > 1) {
        return { ok: false, error: `Invalid FEN: too many ${color} kings` };
      }
    }
    if (Array.from(rows[0] + rows[7]).some((char) => char.toUpperCase() === "P")) {
      return {
        ok: false,
        error: "Invalid FEN: some pawns are on the edge rows"
      };
    }
    return { ok: true };
  }
  function getDisambiguator(move, moves) {
    const from = move.from;
    const to = move.to;
    const piece = move.piece;
    let ambiguities = 0;
    let sameRank = 0;
    let sameFile = 0;
    for (let i = 0, len = moves.length; i < len; i++) {
      const ambigFrom = moves[i].from;
      const ambigTo = moves[i].to;
      const ambigPiece = moves[i].piece;
      if (piece === ambigPiece && from !== ambigFrom && to === ambigTo) {
        ambiguities++;
        if (rank(from) === rank(ambigFrom)) {
          sameRank++;
        }
        if (file(from) === file(ambigFrom)) {
          sameFile++;
        }
      }
    }
    if (ambiguities > 0) {
      if (sameRank > 0 && sameFile > 0) {
        return algebraic(from);
      } else if (sameFile > 0) {
        return algebraic(from).charAt(1);
      } else {
        return algebraic(from).charAt(0);
      }
    }
    return "";
  }
  function addMove(moves, color, from, to, piece, captured = void 0, flags = BITS.NORMAL) {
    const r = rank(to);
    if (piece === PAWN && (r === RANK_1 || r === RANK_8)) {
      for (let i = 0; i < PROMOTIONS.length; i++) {
        const promotion = PROMOTIONS[i];
        moves.push({
          color,
          from,
          to,
          piece,
          captured,
          promotion,
          flags: flags | BITS.PROMOTION
        });
      }
    } else {
      moves.push({
        color,
        from,
        to,
        piece,
        captured,
        flags
      });
    }
  }
  function inferPieceType(san) {
    let pieceType = san.charAt(0);
    if (pieceType >= "a" && pieceType <= "h") {
      const matches = san.match(/[a-h]\d.*[a-h]\d/);
      if (matches) {
        return void 0;
      }
      return PAWN;
    }
    pieceType = pieceType.toLowerCase();
    if (pieceType === "o") {
      return KING;
    }
    return pieceType;
  }
  function strippedSan(move) {
    return move.replace(/=/, "").replace(/[+#]?[?!]*$/, "");
  }
  var Chess = class {
    _board = new Array(128);
    _turn = WHITE;
    _header = {};
    _kings = { w: EMPTY, b: EMPTY };
    _epSquare = -1;
    _halfMoves = 0;
    _moveNumber = 0;
    _history = [];
    _comments = {};
    _castling = { w: 0, b: 0 };
    _hash = 0n;
    // tracks number of times a position has been seen for repetition checking
    _positionCount = /* @__PURE__ */ new Map();
    constructor(fen = DEFAULT_POSITION, { skipValidation = false } = {}) {
      this.load(fen, { skipValidation });
    }
    clear({ preserveHeaders = false } = {}) {
      this._board = new Array(128);
      this._kings = { w: EMPTY, b: EMPTY };
      this._turn = WHITE;
      this._castling = { w: 0, b: 0 };
      this._epSquare = EMPTY;
      this._halfMoves = 0;
      this._moveNumber = 1;
      this._history = [];
      this._comments = {};
      this._header = preserveHeaders ? this._header : { ...HEADER_TEMPLATE };
      this._hash = this._computeHash();
      this._positionCount = /* @__PURE__ */ new Map();
      this._header["SetUp"] = null;
      this._header["FEN"] = null;
    }
    load(fen, { skipValidation = false, preserveHeaders = false } = {}) {
      let tokens = fen.split(/\s+/);
      if (tokens.length >= 2 && tokens.length < 6) {
        const adjustments = ["-", "-", "0", "1"];
        fen = tokens.concat(adjustments.slice(-(6 - tokens.length))).join(" ");
      }
      tokens = fen.split(/\s+/);
      if (!skipValidation) {
        const { ok, error } = validateFen(fen);
        if (!ok) {
          throw new Error(error);
        }
      }
      const position = tokens[0];
      let square = 0;
      this.clear({ preserveHeaders });
      for (let i = 0; i < position.length; i++) {
        const piece = position.charAt(i);
        if (piece === "/") {
          square += 8;
        } else if (isDigit(piece)) {
          square += parseInt(piece, 10);
        } else {
          const color = piece < "a" ? WHITE : BLACK;
          this._put({ type: piece.toLowerCase(), color }, algebraic(square));
          square++;
        }
      }
      this._turn = tokens[1];
      if (tokens[2].indexOf("K") > -1) {
        this._castling.w |= BITS.KSIDE_CASTLE;
      }
      if (tokens[2].indexOf("Q") > -1) {
        this._castling.w |= BITS.QSIDE_CASTLE;
      }
      if (tokens[2].indexOf("k") > -1) {
        this._castling.b |= BITS.KSIDE_CASTLE;
      }
      if (tokens[2].indexOf("q") > -1) {
        this._castling.b |= BITS.QSIDE_CASTLE;
      }
      this._epSquare = tokens[3] === "-" ? EMPTY : Ox88[tokens[3]];
      this._halfMoves = parseInt(tokens[4], 10);
      this._moveNumber = parseInt(tokens[5], 10);
      this._hash = this._computeHash();
      this._updateSetup(fen);
      this._incPositionCount();
    }
    fen({ forceEnpassantSquare = false } = {}) {
      let empty = 0;
      let fen = "";
      for (let i = Ox88.a8; i <= Ox88.h1; i++) {
        if (this._board[i]) {
          if (empty > 0) {
            fen += empty;
            empty = 0;
          }
          const { color, type: piece } = this._board[i];
          fen += color === WHITE ? piece.toUpperCase() : piece.toLowerCase();
        } else {
          empty++;
        }
        if (i + 1 & 136) {
          if (empty > 0) {
            fen += empty;
          }
          if (i !== Ox88.h1) {
            fen += "/";
          }
          empty = 0;
          i += 8;
        }
      }
      let castling = "";
      if (this._castling[WHITE] & BITS.KSIDE_CASTLE) {
        castling += "K";
      }
      if (this._castling[WHITE] & BITS.QSIDE_CASTLE) {
        castling += "Q";
      }
      if (this._castling[BLACK] & BITS.KSIDE_CASTLE) {
        castling += "k";
      }
      if (this._castling[BLACK] & BITS.QSIDE_CASTLE) {
        castling += "q";
      }
      castling = castling || "-";
      let epSquare = "-";
      if (this._epSquare !== EMPTY) {
        if (forceEnpassantSquare) {
          epSquare = algebraic(this._epSquare);
        } else {
          const bigPawnSquare = this._epSquare + (this._turn === WHITE ? 16 : -16);
          const squares = [bigPawnSquare + 1, bigPawnSquare - 1];
          for (const square of squares) {
            if (square & 136) {
              continue;
            }
            const color = this._turn;
            if (this._board[square]?.color === color && this._board[square]?.type === PAWN) {
              this._makeMove({
                color,
                from: square,
                to: this._epSquare,
                piece: PAWN,
                captured: PAWN,
                flags: BITS.EP_CAPTURE
              });
              const isLegal = !this._isKingAttacked(color);
              this._undoMove();
              if (isLegal) {
                epSquare = algebraic(this._epSquare);
                break;
              }
            }
          }
        }
      }
      return [
        fen,
        this._turn,
        castling,
        epSquare,
        this._halfMoves,
        this._moveNumber
      ].join(" ");
    }
    _pieceKey(i) {
      if (!this._board[i]) {
        return 0n;
      }
      const { color, type } = this._board[i];
      const colorIndex = {
        w: 0,
        b: 1
      }[color];
      const typeIndex = {
        p: 0,
        n: 1,
        b: 2,
        r: 3,
        q: 4,
        k: 5
      }[type];
      return PIECE_KEYS[colorIndex][typeIndex][i];
    }
    _epKey() {
      return this._epSquare === EMPTY ? 0n : EP_KEYS[this._epSquare & 7];
    }
    _castlingKey() {
      const index = this._castling.w >> 5 | this._castling.b >> 3;
      return CASTLING_KEYS[index];
    }
    _computeHash() {
      let hash = 0n;
      for (let i = Ox88.a8; i <= Ox88.h1; i++) {
        if (i & 136) {
          i += 7;
          continue;
        }
        if (this._board[i]) {
          hash ^= this._pieceKey(i);
        }
      }
      hash ^= this._epKey();
      hash ^= this._castlingKey();
      if (this._turn === "b") {
        hash ^= SIDE_KEY;
      }
      return hash;
    }
    /*
     * Called when the initial board setup is changed with put() or remove().
     * modifies the SetUp and FEN properties of the header object. If the FEN
     * is equal to the default position, the SetUp and FEN are deleted the setup
     * is only updated if history.length is zero, ie moves haven't been made.
     */
    _updateSetup(fen) {
      if (this._history.length > 0)
        return;
      if (fen !== DEFAULT_POSITION) {
        this._header["SetUp"] = "1";
        this._header["FEN"] = fen;
      } else {
        this._header["SetUp"] = null;
        this._header["FEN"] = null;
      }
    }
    reset() {
      this.load(DEFAULT_POSITION);
    }
    get(square) {
      return this._board[Ox88[square]];
    }
    findPiece(piece) {
      const squares = [];
      for (let i = Ox88.a8; i <= Ox88.h1; i++) {
        if (i & 136) {
          i += 7;
          continue;
        }
        if (!this._board[i] || this._board[i]?.color !== piece.color) {
          continue;
        }
        if (this._board[i].color === piece.color && this._board[i].type === piece.type) {
          squares.push(algebraic(i));
        }
      }
      return squares;
    }
    put({ type, color }, square) {
      if (this._put({ type, color }, square)) {
        this._updateCastlingRights();
        this._updateEnPassantSquare();
        this._updateSetup(this.fen());
        return true;
      }
      return false;
    }
    _set(sq, piece) {
      this._hash ^= this._pieceKey(sq);
      this._board[sq] = piece;
      this._hash ^= this._pieceKey(sq);
    }
    _put({ type, color }, square) {
      if (SYMBOLS.indexOf(type.toLowerCase()) === -1) {
        return false;
      }
      if (!(square in Ox88)) {
        return false;
      }
      const sq = Ox88[square];
      if (type == KING && !(this._kings[color] == EMPTY || this._kings[color] == sq)) {
        return false;
      }
      const currentPieceOnSquare = this._board[sq];
      if (currentPieceOnSquare && currentPieceOnSquare.type === KING) {
        this._kings[currentPieceOnSquare.color] = EMPTY;
      }
      this._set(sq, { type, color });
      if (type === KING) {
        this._kings[color] = sq;
      }
      return true;
    }
    _clear(sq) {
      this._hash ^= this._pieceKey(sq);
      delete this._board[sq];
    }
    remove(square) {
      const piece = this.get(square);
      this._clear(Ox88[square]);
      if (piece && piece.type === KING) {
        this._kings[piece.color] = EMPTY;
      }
      this._updateCastlingRights();
      this._updateEnPassantSquare();
      this._updateSetup(this.fen());
      return piece;
    }
    _updateCastlingRights() {
      this._hash ^= this._castlingKey();
      const whiteKingInPlace = this._board[Ox88.e1]?.type === KING && this._board[Ox88.e1]?.color === WHITE;
      const blackKingInPlace = this._board[Ox88.e8]?.type === KING && this._board[Ox88.e8]?.color === BLACK;
      if (!whiteKingInPlace || this._board[Ox88.a1]?.type !== ROOK || this._board[Ox88.a1]?.color !== WHITE) {
        this._castling.w &= -65;
      }
      if (!whiteKingInPlace || this._board[Ox88.h1]?.type !== ROOK || this._board[Ox88.h1]?.color !== WHITE) {
        this._castling.w &= -33;
      }
      if (!blackKingInPlace || this._board[Ox88.a8]?.type !== ROOK || this._board[Ox88.a8]?.color !== BLACK) {
        this._castling.b &= -65;
      }
      if (!blackKingInPlace || this._board[Ox88.h8]?.type !== ROOK || this._board[Ox88.h8]?.color !== BLACK) {
        this._castling.b &= -33;
      }
      this._hash ^= this._castlingKey();
    }
    _updateEnPassantSquare() {
      if (this._epSquare === EMPTY) {
        return;
      }
      const startSquare = this._epSquare + (this._turn === WHITE ? -16 : 16);
      const currentSquare = this._epSquare + (this._turn === WHITE ? 16 : -16);
      const attackers = [currentSquare + 1, currentSquare - 1];
      if (this._board[startSquare] !== null || this._board[this._epSquare] !== null || this._board[currentSquare]?.color !== swapColor(this._turn) || this._board[currentSquare]?.type !== PAWN) {
        this._hash ^= this._epKey();
        this._epSquare = EMPTY;
        return;
      }
      const canCapture = (square) => !(square & 136) && this._board[square]?.color === this._turn && this._board[square]?.type === PAWN;
      if (!attackers.some(canCapture)) {
        this._hash ^= this._epKey();
        this._epSquare = EMPTY;
      }
    }
    _attacked(color, square, verbose) {
      const attackers = [];
      for (let i = Ox88.a8; i <= Ox88.h1; i++) {
        if (i & 136) {
          i += 7;
          continue;
        }
        if (this._board[i] === void 0 || this._board[i].color !== color) {
          continue;
        }
        const piece = this._board[i];
        const difference = i - square;
        if (difference === 0) {
          continue;
        }
        const index = difference + 119;
        if (ATTACKS[index] & PIECE_MASKS[piece.type]) {
          if (piece.type === PAWN) {
            if (difference > 0 && piece.color === WHITE || difference <= 0 && piece.color === BLACK) {
              if (!verbose) {
                return true;
              } else {
                attackers.push(algebraic(i));
              }
            }
            continue;
          }
          if (piece.type === "n" || piece.type === "k") {
            if (!verbose) {
              return true;
            } else {
              attackers.push(algebraic(i));
              continue;
            }
          }
          const offset = RAYS[index];
          let j = i + offset;
          let blocked = false;
          while (j !== square) {
            if (this._board[j] != null) {
              blocked = true;
              break;
            }
            j += offset;
          }
          if (!blocked) {
            if (!verbose) {
              return true;
            } else {
              attackers.push(algebraic(i));
              continue;
            }
          }
        }
      }
      if (verbose) {
        return attackers;
      } else {
        return false;
      }
    }
    attackers(square, attackedBy) {
      if (!attackedBy) {
        return this._attacked(this._turn, Ox88[square], true);
      } else {
        return this._attacked(attackedBy, Ox88[square], true);
      }
    }
    _isKingAttacked(color) {
      const square = this._kings[color];
      return square === -1 ? false : this._attacked(swapColor(color), square);
    }
    hash() {
      return this._hash.toString(16);
    }
    isAttacked(square, attackedBy) {
      return this._attacked(attackedBy, Ox88[square]);
    }
    isCheck() {
      return this._isKingAttacked(this._turn);
    }
    inCheck() {
      return this.isCheck();
    }
    isCheckmate() {
      return this.isCheck() && this._moves().length === 0;
    }
    isStalemate() {
      return !this.isCheck() && this._moves().length === 0;
    }
    isInsufficientMaterial() {
      const pieces = {
        b: 0,
        n: 0,
        r: 0,
        q: 0,
        k: 0,
        p: 0
      };
      const bishops = [];
      let numPieces = 0;
      let squareColor = 0;
      for (let i = Ox88.a8; i <= Ox88.h1; i++) {
        squareColor = (squareColor + 1) % 2;
        if (i & 136) {
          i += 7;
          continue;
        }
        const piece = this._board[i];
        if (piece) {
          pieces[piece.type] = piece.type in pieces ? pieces[piece.type] + 1 : 1;
          if (piece.type === BISHOP) {
            bishops.push(squareColor);
          }
          numPieces++;
        }
      }
      if (numPieces === 2) {
        return true;
      } else if (
        // k vs. kn .... or .... k vs. kb
        numPieces === 3 && (pieces[BISHOP] === 1 || pieces[KNIGHT] === 1)
      ) {
        return true;
      } else if (numPieces === pieces[BISHOP] + 2) {
        let sum = 0;
        const len = bishops.length;
        for (let i = 0; i < len; i++) {
          sum += bishops[i];
        }
        if (sum === 0 || sum === len) {
          return true;
        }
      }
      return false;
    }
    isThreefoldRepetition() {
      return this._getPositionCount(this._hash) >= 3;
    }
    isDrawByFiftyMoves() {
      return this._halfMoves >= 100;
    }
    isDraw() {
      return this.isDrawByFiftyMoves() || this.isStalemate() || this.isInsufficientMaterial() || this.isThreefoldRepetition();
    }
    isGameOver() {
      return this.isCheckmate() || this.isDraw();
    }
    moves({ verbose = false, square = void 0, piece = void 0 } = {}) {
      const moves = this._moves({ square, piece });
      if (verbose) {
        return moves.map((move) => new Move(this, move));
      } else {
        return moves.map((move) => this._moveToSan(move, moves));
      }
    }
    _moves({ legal = true, piece = void 0, square = void 0 } = {}) {
      const forSquare = square ? square.toLowerCase() : void 0;
      const forPiece = piece?.toLowerCase();
      const moves = [];
      const us = this._turn;
      const them = swapColor(us);
      let firstSquare = Ox88.a8;
      let lastSquare = Ox88.h1;
      let singleSquare = false;
      if (forSquare) {
        if (!(forSquare in Ox88)) {
          return [];
        } else {
          firstSquare = lastSquare = Ox88[forSquare];
          singleSquare = true;
        }
      }
      for (let from = firstSquare; from <= lastSquare; from++) {
        if (from & 136) {
          from += 7;
          continue;
        }
        if (!this._board[from] || this._board[from].color === them) {
          continue;
        }
        const { type } = this._board[from];
        let to;
        if (type === PAWN) {
          if (forPiece && forPiece !== type)
            continue;
          to = from + PAWN_OFFSETS[us][0];
          if (!this._board[to]) {
            addMove(moves, us, from, to, PAWN);
            to = from + PAWN_OFFSETS[us][1];
            if (SECOND_RANK[us] === rank(from) && !this._board[to]) {
              addMove(moves, us, from, to, PAWN, void 0, BITS.BIG_PAWN);
            }
          }
          for (let j = 2; j < 4; j++) {
            to = from + PAWN_OFFSETS[us][j];
            if (to & 136)
              continue;
            if (this._board[to]?.color === them) {
              addMove(moves, us, from, to, PAWN, this._board[to].type, BITS.CAPTURE);
            } else if (to === this._epSquare) {
              addMove(moves, us, from, to, PAWN, PAWN, BITS.EP_CAPTURE);
            }
          }
        } else {
          if (forPiece && forPiece !== type)
            continue;
          for (let j = 0, len = PIECE_OFFSETS[type].length; j < len; j++) {
            const offset = PIECE_OFFSETS[type][j];
            to = from;
            while (true) {
              to += offset;
              if (to & 136)
                break;
              if (!this._board[to]) {
                addMove(moves, us, from, to, type);
              } else {
                if (this._board[to].color === us)
                  break;
                addMove(moves, us, from, to, type, this._board[to].type, BITS.CAPTURE);
                break;
              }
              if (type === KNIGHT || type === KING)
                break;
            }
          }
        }
      }
      if (forPiece === void 0 || forPiece === KING) {
        if (!singleSquare || lastSquare === this._kings[us]) {
          if (this._castling[us] & BITS.KSIDE_CASTLE) {
            const castlingFrom = this._kings[us];
            const castlingTo = castlingFrom + 2;
            if (!this._board[castlingFrom + 1] && !this._board[castlingTo] && !this._attacked(them, this._kings[us]) && !this._attacked(them, castlingFrom + 1) && !this._attacked(them, castlingTo)) {
              addMove(moves, us, this._kings[us], castlingTo, KING, void 0, BITS.KSIDE_CASTLE);
            }
          }
          if (this._castling[us] & BITS.QSIDE_CASTLE) {
            const castlingFrom = this._kings[us];
            const castlingTo = castlingFrom - 2;
            if (!this._board[castlingFrom - 1] && !this._board[castlingFrom - 2] && !this._board[castlingFrom - 3] && !this._attacked(them, this._kings[us]) && !this._attacked(them, castlingFrom - 1) && !this._attacked(them, castlingTo)) {
              addMove(moves, us, this._kings[us], castlingTo, KING, void 0, BITS.QSIDE_CASTLE);
            }
          }
        }
      }
      if (!legal || this._kings[us] === -1) {
        return moves;
      }
      const legalMoves = [];
      for (let i = 0, len = moves.length; i < len; i++) {
        this._makeMove(moves[i]);
        if (!this._isKingAttacked(us)) {
          legalMoves.push(moves[i]);
        }
        this._undoMove();
      }
      return legalMoves;
    }
    move(move, { strict = false } = {}) {
      let moveObj = null;
      if (typeof move === "string") {
        moveObj = this._moveFromSan(move, strict);
      } else if (move === null) {
        moveObj = this._moveFromSan(SAN_NULLMOVE, strict);
      } else if (typeof move === "object") {
        const moves = this._moves();
        for (let i = 0, len = moves.length; i < len; i++) {
          if (move.from === algebraic(moves[i].from) && move.to === algebraic(moves[i].to) && (!("promotion" in moves[i]) || move.promotion === moves[i].promotion)) {
            moveObj = moves[i];
            break;
          }
        }
      }
      if (!moveObj) {
        if (typeof move === "string") {
          throw new Error(`Invalid move: ${move}`);
        } else {
          throw new Error(`Invalid move: ${JSON.stringify(move)}`);
        }
      }
      if (this.isCheck() && moveObj.flags & BITS.NULL_MOVE) {
        throw new Error("Null move not allowed when in check");
      }
      const prettyMove = new Move(this, moveObj);
      this._makeMove(moveObj);
      this._incPositionCount();
      return prettyMove;
    }
    _push(move) {
      this._history.push({
        move,
        kings: { b: this._kings.b, w: this._kings.w },
        turn: this._turn,
        castling: { b: this._castling.b, w: this._castling.w },
        epSquare: this._epSquare,
        halfMoves: this._halfMoves,
        moveNumber: this._moveNumber
      });
    }
    _movePiece(from, to) {
      this._hash ^= this._pieceKey(from);
      this._board[to] = this._board[from];
      delete this._board[from];
      this._hash ^= this._pieceKey(to);
    }
    _makeMove(move) {
      const us = this._turn;
      const them = swapColor(us);
      this._push(move);
      if (move.flags & BITS.NULL_MOVE) {
        if (us === BLACK) {
          this._moveNumber++;
        }
        this._halfMoves++;
        this._turn = them;
        this._epSquare = EMPTY;
        return;
      }
      this._hash ^= this._epKey();
      this._hash ^= this._castlingKey();
      if (move.captured) {
        this._hash ^= this._pieceKey(move.to);
      }
      this._movePiece(move.from, move.to);
      if (move.flags & BITS.EP_CAPTURE) {
        if (this._turn === BLACK) {
          this._clear(move.to - 16);
        } else {
          this._clear(move.to + 16);
        }
      }
      if (move.promotion) {
        this._clear(move.to);
        this._set(move.to, { type: move.promotion, color: us });
      }
      if (this._board[move.to].type === KING) {
        this._kings[us] = move.to;
        if (move.flags & BITS.KSIDE_CASTLE) {
          const castlingTo = move.to - 1;
          const castlingFrom = move.to + 1;
          this._movePiece(castlingFrom, castlingTo);
        } else if (move.flags & BITS.QSIDE_CASTLE) {
          const castlingTo = move.to + 1;
          const castlingFrom = move.to - 2;
          this._movePiece(castlingFrom, castlingTo);
        }
        this._castling[us] = 0;
      }
      if (this._castling[us]) {
        for (let i = 0, len = ROOKS[us].length; i < len; i++) {
          if (move.from === ROOKS[us][i].square && this._castling[us] & ROOKS[us][i].flag) {
            this._castling[us] ^= ROOKS[us][i].flag;
            break;
          }
        }
      }
      if (this._castling[them]) {
        for (let i = 0, len = ROOKS[them].length; i < len; i++) {
          if (move.to === ROOKS[them][i].square && this._castling[them] & ROOKS[them][i].flag) {
            this._castling[them] ^= ROOKS[them][i].flag;
            break;
          }
        }
      }
      this._hash ^= this._castlingKey();
      if (move.flags & BITS.BIG_PAWN) {
        let epSquare;
        if (us === BLACK) {
          epSquare = move.to - 16;
        } else {
          epSquare = move.to + 16;
        }
        if (!(move.to - 1 & 136) && this._board[move.to - 1]?.type === PAWN && this._board[move.to - 1]?.color === them || !(move.to + 1 & 136) && this._board[move.to + 1]?.type === PAWN && this._board[move.to + 1]?.color === them) {
          this._epSquare = epSquare;
          this._hash ^= this._epKey();
        } else {
          this._epSquare = EMPTY;
        }
      } else {
        this._epSquare = EMPTY;
      }
      if (move.piece === PAWN) {
        this._halfMoves = 0;
      } else if (move.flags & (BITS.CAPTURE | BITS.EP_CAPTURE)) {
        this._halfMoves = 0;
      } else {
        this._halfMoves++;
      }
      if (us === BLACK) {
        this._moveNumber++;
      }
      this._turn = them;
      this._hash ^= SIDE_KEY;
    }
    undo() {
      const hash = this._hash;
      const move = this._undoMove();
      if (move) {
        const prettyMove = new Move(this, move);
        this._decPositionCount(hash);
        return prettyMove;
      }
      return null;
    }
    _undoMove() {
      const old = this._history.pop();
      if (old === void 0) {
        return null;
      }
      this._hash ^= this._epKey();
      this._hash ^= this._castlingKey();
      const move = old.move;
      this._kings = old.kings;
      this._turn = old.turn;
      this._castling = old.castling;
      this._epSquare = old.epSquare;
      this._halfMoves = old.halfMoves;
      this._moveNumber = old.moveNumber;
      this._hash ^= this._epKey();
      this._hash ^= this._castlingKey();
      this._hash ^= SIDE_KEY;
      const us = this._turn;
      const them = swapColor(us);
      if (move.flags & BITS.NULL_MOVE) {
        return move;
      }
      this._movePiece(move.to, move.from);
      if (move.piece) {
        this._clear(move.from);
        this._set(move.from, { type: move.piece, color: us });
      }
      if (move.captured) {
        if (move.flags & BITS.EP_CAPTURE) {
          let index;
          if (us === BLACK) {
            index = move.to - 16;
          } else {
            index = move.to + 16;
          }
          this._set(index, { type: PAWN, color: them });
        } else {
          this._set(move.to, { type: move.captured, color: them });
        }
      }
      if (move.flags & (BITS.KSIDE_CASTLE | BITS.QSIDE_CASTLE)) {
        let castlingTo, castlingFrom;
        if (move.flags & BITS.KSIDE_CASTLE) {
          castlingTo = move.to + 1;
          castlingFrom = move.to - 1;
        } else {
          castlingTo = move.to - 2;
          castlingFrom = move.to + 1;
        }
        this._movePiece(castlingFrom, castlingTo);
      }
      return move;
    }
    pgn({ newline = "\n", maxWidth = 0 } = {}) {
      const result = [];
      let headerExists = false;
      for (const i in this._header) {
        const headerTag = this._header[i];
        if (headerTag)
          result.push(`[${i} "${this._header[i]}"]` + newline);
        headerExists = true;
      }
      if (headerExists && this._history.length) {
        result.push(newline);
      }
      const appendComment = (moveString2) => {
        const comment = this._comments[this.fen()];
        if (typeof comment !== "undefined") {
          const delimiter = moveString2.length > 0 ? " " : "";
          moveString2 = `${moveString2}${delimiter}{${comment}}`;
        }
        return moveString2;
      };
      const reversedHistory = [];
      while (this._history.length > 0) {
        reversedHistory.push(this._undoMove());
      }
      const moves = [];
      let moveString = "";
      if (reversedHistory.length === 0) {
        moves.push(appendComment(""));
      }
      while (reversedHistory.length > 0) {
        moveString = appendComment(moveString);
        const move = reversedHistory.pop();
        if (!move) {
          break;
        }
        if (!this._history.length && move.color === "b") {
          const prefix = `${this._moveNumber}. ...`;
          moveString = moveString ? `${moveString} ${prefix}` : prefix;
        } else if (move.color === "w") {
          if (moveString.length) {
            moves.push(moveString);
          }
          moveString = this._moveNumber + ".";
        }
        moveString = moveString + " " + this._moveToSan(move, this._moves({ legal: true }));
        this._makeMove(move);
      }
      if (moveString.length) {
        moves.push(appendComment(moveString));
      }
      moves.push(this._header.Result || "*");
      if (maxWidth === 0) {
        return result.join("") + moves.join(" ");
      }
      const strip = function() {
        if (result.length > 0 && result[result.length - 1] === " ") {
          result.pop();
          return true;
        }
        return false;
      };
      const wrapComment = function(width, move) {
        for (const token of move.split(" ")) {
          if (!token) {
            continue;
          }
          if (width + token.length > maxWidth) {
            while (strip()) {
              width--;
            }
            result.push(newline);
            width = 0;
          }
          result.push(token);
          width += token.length;
          result.push(" ");
          width++;
        }
        if (strip()) {
          width--;
        }
        return width;
      };
      let currentWidth = 0;
      for (let i = 0; i < moves.length; i++) {
        if (currentWidth + moves[i].length > maxWidth) {
          if (moves[i].includes("{")) {
            currentWidth = wrapComment(currentWidth, moves[i]);
            continue;
          }
        }
        if (currentWidth + moves[i].length > maxWidth && i !== 0) {
          if (result[result.length - 1] === " ") {
            result.pop();
          }
          result.push(newline);
          currentWidth = 0;
        } else if (i !== 0) {
          result.push(" ");
          currentWidth++;
        }
        result.push(moves[i]);
        currentWidth += moves[i].length;
      }
      return result.join("");
    }
    /**
     * @deprecated Use `setHeader` and `getHeaders` instead. This method will return null header tags (which is not what you want)
     */
    header(...args) {
      for (let i = 0; i < args.length; i += 2) {
        if (typeof args[i] === "string" && typeof args[i + 1] === "string") {
          this._header[args[i]] = args[i + 1];
        }
      }
      return this._header;
    }
    // TODO: value validation per spec
    setHeader(key, value) {
      this._header[key] = value ?? SEVEN_TAG_ROSTER[key] ?? null;
      return this.getHeaders();
    }
    removeHeader(key) {
      if (key in this._header) {
        this._header[key] = SEVEN_TAG_ROSTER[key] || null;
        return true;
      }
      return false;
    }
    // return only non-null headers (omit placemarker nulls)
    getHeaders() {
      const nonNullHeaders = {};
      for (const [key, value] of Object.entries(this._header)) {
        if (value !== null) {
          nonNullHeaders[key] = value;
        }
      }
      return nonNullHeaders;
    }
    loadPgn(pgn2, { strict = false, newlineChar = "\r?\n" } = {}) {
      if (newlineChar !== "\r?\n") {
        pgn2 = pgn2.replace(new RegExp(newlineChar, "g"), "\n");
      }
      const parsedPgn = peg$parse(pgn2);
      this.reset();
      const headers = parsedPgn.headers;
      let fen = "";
      for (const key in headers) {
        if (key.toLowerCase() === "fen") {
          fen = headers[key];
        }
        this.header(key, headers[key]);
      }
      if (!strict) {
        if (fen) {
          this.load(fen, { preserveHeaders: true });
        }
      } else {
        if (headers["SetUp"] === "1") {
          if (!("FEN" in headers)) {
            throw new Error("Invalid PGN: FEN tag must be supplied with SetUp tag");
          }
          this.load(headers["FEN"], { preserveHeaders: true });
        }
      }
      let node2 = parsedPgn.root;
      while (node2) {
        if (node2.move) {
          const move = this._moveFromSan(node2.move, strict);
          if (move == null) {
            throw new Error(`Invalid move in PGN: ${node2.move}`);
          } else {
            this._makeMove(move);
            this._incPositionCount();
          }
        }
        if (node2.comment !== void 0) {
          this._comments[this.fen()] = node2.comment;
        }
        node2 = node2.variations[0];
      }
      const result = parsedPgn.result;
      if (result && Object.keys(this._header).length && this._header["Result"] !== result) {
        this.setHeader("Result", result);
      }
    }
    /*
     * Convert a move from 0x88 coordinates to Standard Algebraic Notation
     * (SAN)
     *
     * @param {boolean} strict Use the strict SAN parser. It will throw errors
     * on overly disambiguated moves (see below):
     *
     * r1bqkbnr/ppp2ppp/2n5/1B1pP3/4P3/8/PPPP2PP/RNBQK1NR b KQkq - 2 4
     * 4. ... Nge7 is overly disambiguated because the knight on c6 is pinned
     * 4. ... Ne7 is technically the valid SAN
     */
    _moveToSan(move, moves) {
      let output = "";
      if (move.flags & BITS.KSIDE_CASTLE) {
        output = "O-O";
      } else if (move.flags & BITS.QSIDE_CASTLE) {
        output = "O-O-O";
      } else if (move.flags & BITS.NULL_MOVE) {
        return SAN_NULLMOVE;
      } else {
        if (move.piece !== PAWN) {
          const disambiguator = getDisambiguator(move, moves);
          output += move.piece.toUpperCase() + disambiguator;
        }
        if (move.flags & (BITS.CAPTURE | BITS.EP_CAPTURE)) {
          if (move.piece === PAWN) {
            output += algebraic(move.from)[0];
          }
          output += "x";
        }
        output += algebraic(move.to);
        if (move.promotion) {
          output += "=" + move.promotion.toUpperCase();
        }
      }
      this._makeMove(move);
      if (this.isCheck()) {
        if (this.isCheckmate()) {
          output += "#";
        } else {
          output += "+";
        }
      }
      this._undoMove();
      return output;
    }
    // convert a move from Standard Algebraic Notation (SAN) to 0x88 coordinates
    _moveFromSan(move, strict = false) {
      let cleanMove = strippedSan(move);
      if (!strict) {
        if (cleanMove === "0-0") {
          cleanMove = "O-O";
        } else if (cleanMove === "0-0-0") {
          cleanMove = "O-O-O";
        }
      }
      if (cleanMove == SAN_NULLMOVE) {
        const res = {
          color: this._turn,
          from: 0,
          to: 0,
          piece: "k",
          flags: BITS.NULL_MOVE
        };
        return res;
      }
      let pieceType = inferPieceType(cleanMove);
      let moves = this._moves({ legal: true, piece: pieceType });
      for (let i = 0, len = moves.length; i < len; i++) {
        if (cleanMove === strippedSan(this._moveToSan(moves[i], moves))) {
          return moves[i];
        }
      }
      if (strict) {
        return null;
      }
      let piece = void 0;
      let matches = void 0;
      let from = void 0;
      let to = void 0;
      let promotion = void 0;
      let overlyDisambiguated = false;
      matches = cleanMove.match(/([pnbrqkPNBRQK])?([a-h][1-8])x?-?([a-h][1-8])([qrbnQRBN])?/);
      if (matches) {
        piece = matches[1];
        from = matches[2];
        to = matches[3];
        promotion = matches[4];
        if (from.length == 1) {
          overlyDisambiguated = true;
        }
      } else {
        matches = cleanMove.match(/([pnbrqkPNBRQK])?([a-h]?[1-8]?)x?-?([a-h][1-8])([qrbnQRBN])?/);
        if (matches) {
          piece = matches[1];
          from = matches[2];
          to = matches[3];
          promotion = matches[4];
          if (from.length == 1) {
            overlyDisambiguated = true;
          }
        }
      }
      pieceType = inferPieceType(cleanMove);
      moves = this._moves({
        legal: true,
        piece: piece ? piece : pieceType
      });
      if (!to) {
        return null;
      }
      for (let i = 0, len = moves.length; i < len; i++) {
        if (!from) {
          if (cleanMove === strippedSan(this._moveToSan(moves[i], moves)).replace("x", "")) {
            return moves[i];
          }
        } else if ((!piece || piece.toLowerCase() == moves[i].piece) && Ox88[from] == moves[i].from && Ox88[to] == moves[i].to && (!promotion || promotion.toLowerCase() == moves[i].promotion)) {
          return moves[i];
        } else if (overlyDisambiguated) {
          const square = algebraic(moves[i].from);
          if ((!piece || piece.toLowerCase() == moves[i].piece) && Ox88[to] == moves[i].to && (from == square[0] || from == square[1]) && (!promotion || promotion.toLowerCase() == moves[i].promotion)) {
            return moves[i];
          }
        }
      }
      return null;
    }
    ascii() {
      let s = "   +------------------------+\n";
      for (let i = Ox88.a8; i <= Ox88.h1; i++) {
        if (file(i) === 0) {
          s += " " + "87654321"[rank(i)] + " |";
        }
        if (this._board[i]) {
          const piece = this._board[i].type;
          const color = this._board[i].color;
          const symbol = color === WHITE ? piece.toUpperCase() : piece.toLowerCase();
          s += " " + symbol + " ";
        } else {
          s += " . ";
        }
        if (i + 1 & 136) {
          s += "|\n";
          i += 8;
        }
      }
      s += "   +------------------------+\n";
      s += "     a  b  c  d  e  f  g  h";
      return s;
    }
    perft(depth) {
      const moves = this._moves({ legal: false });
      let nodes = 0;
      const color = this._turn;
      for (let i = 0, len = moves.length; i < len; i++) {
        this._makeMove(moves[i]);
        if (!this._isKingAttacked(color)) {
          if (depth - 1 > 0) {
            nodes += this.perft(depth - 1);
          } else {
            nodes++;
          }
        }
        this._undoMove();
      }
      return nodes;
    }
    setTurn(color) {
      if (this._turn == color) {
        return false;
      }
      this.move("--");
      return true;
    }
    turn() {
      return this._turn;
    }
    board() {
      const output = [];
      let row = [];
      for (let i = Ox88.a8; i <= Ox88.h1; i++) {
        if (this._board[i] == null) {
          row.push(null);
        } else {
          row.push({
            square: algebraic(i),
            type: this._board[i].type,
            color: this._board[i].color
          });
        }
        if (i + 1 & 136) {
          output.push(row);
          row = [];
          i += 8;
        }
      }
      return output;
    }
    squareColor(square) {
      if (square in Ox88) {
        const sq = Ox88[square];
        return (rank(sq) + file(sq)) % 2 === 0 ? "light" : "dark";
      }
      return null;
    }
    history({ verbose = false } = {}) {
      const reversedHistory = [];
      const moveHistory = [];
      while (this._history.length > 0) {
        reversedHistory.push(this._undoMove());
      }
      while (true) {
        const move = reversedHistory.pop();
        if (!move) {
          break;
        }
        if (verbose) {
          moveHistory.push(new Move(this, move));
        } else {
          moveHistory.push(this._moveToSan(move, this._moves()));
        }
        this._makeMove(move);
      }
      return moveHistory;
    }
    /*
     * Keeps track of position occurrence counts for the purpose of repetition
     * checking. Old positions are removed from the map if their counts are reduced to 0.
     */
    _getPositionCount(hash) {
      return this._positionCount.get(hash) ?? 0;
    }
    _incPositionCount() {
      this._positionCount.set(this._hash, (this._positionCount.get(this._hash) ?? 0) + 1);
    }
    _decPositionCount(hash) {
      const currentCount = this._positionCount.get(hash) ?? 0;
      if (currentCount === 1) {
        this._positionCount.delete(hash);
      } else {
        this._positionCount.set(hash, currentCount - 1);
      }
    }
    _pruneComments() {
      const reversedHistory = [];
      const currentComments = {};
      const copyComment = (fen) => {
        if (fen in this._comments) {
          currentComments[fen] = this._comments[fen];
        }
      };
      while (this._history.length > 0) {
        reversedHistory.push(this._undoMove());
      }
      copyComment(this.fen());
      while (true) {
        const move = reversedHistory.pop();
        if (!move) {
          break;
        }
        this._makeMove(move);
        copyComment(this.fen());
      }
      this._comments = currentComments;
    }
    getComment() {
      return this._comments[this.fen()];
    }
    setComment(comment) {
      this._comments[this.fen()] = comment.replace("{", "[").replace("}", "]");
    }
    /**
     * @deprecated Renamed to `removeComment` for consistency
     */
    deleteComment() {
      return this.removeComment();
    }
    removeComment() {
      const comment = this._comments[this.fen()];
      delete this._comments[this.fen()];
      return comment;
    }
    getComments() {
      this._pruneComments();
      return Object.keys(this._comments).map((fen) => {
        return { fen, comment: this._comments[fen] };
      });
    }
    /**
     * @deprecated Renamed to `removeComments` for consistency
     */
    deleteComments() {
      return this.removeComments();
    }
    removeComments() {
      this._pruneComments();
      return Object.keys(this._comments).map((fen) => {
        const comment = this._comments[fen];
        delete this._comments[fen];
        return { fen, comment };
      });
    }
    setCastlingRights(color, rights) {
      for (const side of [KING, QUEEN]) {
        if (rights[side] !== void 0) {
          if (rights[side]) {
            this._castling[color] |= SIDES[side];
          } else {
            this._castling[color] &= ~SIDES[side];
          }
        }
      }
      this._updateCastlingRights();
      const result = this.getCastlingRights(color);
      return (rights[KING] === void 0 || rights[KING] === result[KING]) && (rights[QUEEN] === void 0 || rights[QUEEN] === result[QUEEN]);
    }
    getCastlingRights(color) {
      return {
        [KING]: (this._castling[color] & SIDES[KING]) !== 0,
        [QUEEN]: (this._castling[color] & SIDES[QUEEN]) !== 0
      };
    }
    moveNumber() {
      return this._moveNumber;
    }
  };

  // src/pieces.js
  var SHAPES = {
    p: '<circle cx="50" cy="25" r="12"/><path d="M21 83c0-10 6-15 16-19-2-3-3-6-3-9 0-9 7-16 16-16s16 7 16 16c0 3-1 6-3 9 10 4 16 9 16 19v3H21z"/>',
    r: '<path d="M27 26 24 10q0-3 3-3h7l2 9h8l1-9h10l1 9h8l2-9h7q3 0 3 3l-3 16-5 6 4 41H28l4-41z"/><path d="M21 84c0-8 4-11 12-11h34c8 0 12 3 12 11v3H21z"/>',
    n: '<path d="M25 80c1-13 8-19 18-23-2-4-2-8 0-12-6 5-12 6-17 4l-5 3c-3 1-8-3-9-7-1-2 0-4 3-7 10-10 15-18 18-28l5-3 6 8c23 2 38 21 37 46l-2 19z"/><path d="M22 84c0-8 4-11 12-11h35c8 0 12 3 12 11v3H22z"/>',
    b: '<circle cx="50" cy="11" r="7"/><path d="M47 17c-9 7-17 17-17 30 0 9 3 15 9 19h22c6-4 9-10 9-19 0-13-8-23-17-30z"/><path d="M18 69h64l-4 17H58l-8-6-8 6H22z"/><path d="M53 24c-3 7-5 15-5 23" fill="none"/>',
    q: '<path d="M28 70 19 29 31 51 35 23l10 27 5-30 5 30 10-27 4 28 12-22-9 41z"/><circle cx="18" cy="26" r="6"/><circle cx="35" cy="19" r="6"/><circle cx="50" cy="15" r="6"/><circle cx="65" cy="19" r="6"/><circle cx="82" cy="26" r="6"/><path d="M22 84c0-9 4-13 12-13h32c8 0 12 4 12 13v3H22z"/>',
    k: '<path d="M50 20c-3-4-7-9-7-13a7 7 0 0 1 14 0c0 4-4 9-7 13z"/><path d="M29 70c-2-9-8-14-13-21-6-8-6-18 0-23 8-7 19-2 34 11 15-13 26-18 34-11 6 5 6 15 0 23-5 7-11 12-13 21z"/><path d="m27 41 8 8m38-8-8 8" fill="none" stroke-width="6"/><path d="M22 84c0-9 4-13 12-13h32c8 0 12 4 12 13v3H22z"/>'
  };
  function getPieceSvg(color, type) {
    const shape = SHAPES[type];
    if (!shape || color !== "w" && color !== "b") return "";
    const fill = color === "w" ? "#f7f7f7" : "#555758";
    const shade = color === "w" ? "#d4d4d4" : "#393b3c";
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" aria-hidden="true"><defs><clipPath id="piece-shade-${color}-${type}"><path d="M61 0H100V100H55c11-20 18-40 6-100z"/></clipPath></defs><g fill="${fill}" stroke="#171717" stroke-width="2.4" stroke-linejoin="round" stroke-linecap="round">${shape}</g><g fill="${shade}" stroke="none" opacity=".7" clip-path="url(#piece-shade-${color}-${type})">${shape}</g><g fill="none" stroke="#171717" stroke-width="2.4" stroke-linejoin="round" stroke-linecap="round">${shape}</g></svg>`;
  }

  // extension/src/position.js
  var file2 = "abcdefgh";
  var placementOf = (fen) => fen.split(" ")[0];
  var START = new Chess().fen();
  function makePlacement(pieces) {
    const ranks = [];
    for (let rank2 = 8; rank2 >= 1; rank2--) {
      let row = "", empty = 0;
      for (const f of file2) {
        const piece = pieces.get(f + rank2);
        if (!piece) {
          empty++;
          continue;
        }
        if (empty) {
          row += empty;
          empty = 0;
        }
        row += piece[0] === "w" ? piece[1].toUpperCase() : piece[1];
      }
      ranks.push(row + (empty || ""));
    }
    return ranks.join("/");
  }
  function inferCastlingRights(pieces) {
    if (!pieces || pieces.size === 0) return "-";
    let castling = "";
    if (pieces.get("e1") === "wk") {
      if (pieces.get("h1") === "wr") castling += "K";
      if (pieces.get("a1") === "wr") castling += "Q";
    }
    if (pieces.get("e8") === "bk") {
      if (pieces.get("h8") === "br") castling += "k";
      if (pieces.get("a8") === "br") castling += "q";
    }
    return castling || "-";
  }
  function inferTurn(doc, boardElement, type, flipped, pieces, placement, highlights = [], sans = []) {
    if (highlights && highlights.length >= 2 && pieces && pieces.size > 0) {
      const occupied = highlights.filter((sq) => pieces.has(sq));
      const vacated = highlights.filter((sq) => !pieces.has(sq));
      let destSquare = null;
      let fromSquare = vacated[0] || null;
      if (occupied.length === 1) {
        destSquare = occupied[0];
      } else if (occupied.length > 1) {
        const kingSq = occupied.find((sq) => pieces.get(sq)?.[1] === "k");
        destSquare = kingSq || occupied[0];
      }
      if (destSquare) {
        const piece = pieces.get(destSquare);
        if (piece) {
          const moverColor = piece[0];
          const nextTurn = moverColor === "w" ? "b" : "w";
          let enPassant = "-";
          if (fromSquare && piece[1] === "p") {
            const fromRank = Number(fromSquare[1]);
            const toRank = Number(destSquare[1]);
            if (moverColor === "w" && fromRank === 2 && toRank === 4) {
              enPassant = destSquare[0] + "3";
            } else if (moverColor === "b" && fromRank === 7 && toRank === 5) {
              enPassant = destSquare[0] + "6";
            }
          }
          return { turn: nextTurn, enPassant, confidence: "high", reason: "\u0646\u0642\u0644\u0629 \u0623\u062E\u064A\u0631\u0629 \u0645\u0631\u0635\u0648\u062F\u0629" };
        }
      }
    }
    if (doc) {
      const whiteClockActive = doc.querySelector(".clock-white.clock-player-turn, .clock-white.clock-running, .clock-white.has-pulse, .rclock-white.running");
      const blackClockActive = doc.querySelector(".clock-black.clock-player-turn, .clock-black.clock-running, .clock-black.has-pulse, .rclock-black.running");
      if (whiteClockActive && !blackClockActive) return { turn: "w", enPassant: "-", confidence: "high", reason: "\u0633\u0627\u0639\u0629 \u0627\u0644\u0623\u0628\u064A\u0636 \u062A\u0639\u0645\u0644" };
      if (blackClockActive && !whiteClockActive) return { turn: "b", enPassant: "-", confidence: "high", reason: "\u0633\u0627\u0639\u0629 \u0627\u0644\u0623\u0633\u0648\u062F \u062A\u0639\u0645\u0644" };
      const topClockActive = doc.querySelector(".clock-top.clock-player-turn, .clock-top.clock-running, .rclock-top.running");
      const bottomClockActive = doc.querySelector(".clock-bottom.clock-player-turn, .clock-bottom.clock-running, .rclock-bottom.running");
      if (bottomClockActive && !topClockActive) {
        return { turn: flipped ? "b" : "w", enPassant: "-", confidence: "high", reason: "\u0633\u0627\u0639\u0629 \u0627\u0644\u0644\u0627\u0639\u0628 \u0627\u0644\u062D\u0627\u0644\u064A" };
      }
      if (topClockActive && !bottomClockActive) {
        return { turn: flipped ? "w" : "b", enPassant: "-", confidence: "high", reason: "\u0633\u0627\u0639\u0629 \u0627\u0644\u062E\u0635\u0645" };
      }
    }
    if (sans && sans.length > 0) {
      return { turn: sans.length % 2 === 1 ? "b" : "w", enPassant: "-", confidence: "medium", reason: "\u0633\u062C\u0644 \u0627\u0644\u0646\u0642\u0644\u0627\u062A" };
    }
    try {
      const testWhite = new Chess(`${placement} w - - 0 1`);
      const testBlack = new Chess(`${placement} b - - 0 1`);
      if (testWhite.inCheck() && !testBlack.inCheck()) {
        return { turn: "w", enPassant: "-", confidence: "conclusive", reason: "\u0643\u0634 \u0644\u0645\u0644\u0643 \u0627\u0644\u0623\u0628\u064A\u0636" };
      }
      if (testBlack.inCheck() && !testWhite.inCheck()) {
        return { turn: "b", enPassant: "-", confidence: "conclusive", reason: "\u0643\u0634 \u0644\u0645\u0644\u0643 \u0627\u0644\u0623\u0633\u0648\u062F" };
      }
    } catch {
    }
    return { turn: "w", enPassant: "-", confidence: "fallback", reason: "\u0631\u0635\u062F \u0627\u0644\u0631\u0642\u0639\u0629" };
  }
  var PositionTracker = class {
    constructor() {
      this.reset();
    }
    reset() {
      this.board = null;
      this.snapshots = [];
      this.source = "";
    }
    remember(board, source) {
      this.board = board;
      this.source = source;
      const fen = board.fen();
      if (this.snapshots.at(-1) !== fen) this.snapshots.push(fen);
      this.snapshots = this.snapshots.slice(-500);
      return { fen, source, history: board.history(), position: this.command(board) };
    }
    command(board) {
      const moves = board.history({ verbose: true });
      const initial = moves[0]?.before || board.fen();
      return `position fen ${initial}${moves.length ? " moves " + moves.map((m) => m.from + m.to + (m.promotion || "")).join(" ") : ""}`;
    }
    resolve(reading, override = null) {
      const { placement, fullFen, sans = [], initialFen = START, selectedPly = null, element, type, flipped, pieces, highlights = [], doc } = reading;
      if (override) {
        const board = new Chess(override);
        if (placementOf(board.fen()) !== placement) throw new Error("FEN \u0644\u0627 \u064A\u0637\u0627\u0628\u0642 \u0627\u0644\u0642\u0637\u0639 \u0627\u0644\u0638\u0627\u0647\u0631\u0629 \u0639\u0644\u0649 \u0627\u0644\u0631\u0642\u0639\u0629.");
        return this.remember(board, "FEN \u0645\u064F\u062F\u062E\u0644");
      }
      if (fullFen) {
        try {
          const board = new Chess(fullFen);
          if (placementOf(board.fen()) === placement) {
            if (this.board?.fen() === board.fen()) return this.remember(this.board, this.source);
            return this.remember(board, "FEN \u0627\u0644\u0631\u0642\u0639\u0629");
          }
        } catch {
        }
      }
      if (sans.length) {
        try {
          const board = new Chess(initialFen);
          let match = placementOf(board.fen()) === placement ? new Chess(initialFen) : null;
          for (const san of sans.slice(0, selectedPly ?? sans.length)) {
            board.move(san);
            if (placementOf(board.fen()) === placement) {
              match = new Chess(initialFen);
              for (const move of board.history()) match.move(move);
            }
          }
          if (match && (selectedPly == null || match.history().length === selectedPly)) return this.remember(match, "\u0633\u062C\u0644 \u0627\u0644\u0646\u0642\u0644\u0627\u062A");
        } catch {
        }
      }
      if (this.board) {
        if (placementOf(this.board.fen()) === placement) return this.remember(this.board, this.source);
        const matches = this.board.moves({ verbose: true }).filter((m) => placementOf(m.after) === placement);
        if (matches.length === 1) {
          this.board.move(matches[0]);
          return this.remember(this.board, "\u0645\u062A\u0627\u0628\u0639\u0629 \u0627\u0644\u0646\u0642\u0644\u0627\u062A");
        }
        const past = this.snapshots.findLast((fen) => placementOf(fen) === placement);
        if (past) return this.remember(new Chess(past), "\u0648\u0636\u0639\u064A\u0629 \u0633\u0627\u0628\u0642\u0629");
      }
      if (placement === placementOf(START)) return this.remember(new Chess(), "\u0628\u062F\u0627\u064A\u0629 \u0627\u0644\u0645\u0628\u0627\u0631\u0627\u0629");
      if (pieces || element || highlights && highlights.length || reading.inferMidgame) {
        try {
          let pieceMap = pieces;
          if (!pieceMap || pieceMap.size === 0) {
            pieceMap = /* @__PURE__ */ new Map();
            const ranks = placement.split("/");
            for (let r = 0; r < 8; r++) {
              let col = 0;
              for (const ch of ranks[r]) {
                if (/[1-8]/.test(ch)) {
                  col += Number(ch);
                } else {
                  const color = ch === ch.toUpperCase() ? "w" : "b";
                  pieceMap.set(file2[col] + (8 - r), color + ch.toLowerCase());
                  col++;
                }
              }
            }
          }
          const inferred = inferTurn(doc || (typeof document !== "undefined" ? document : null), element, type, flipped, pieceMap, placement, highlights, sans);
          const castling = inferCastlingRights(pieceMap);
          const ep = inferred.enPassant || "-";
          const moveCount = sans && sans.length > 0 ? Math.floor(sans.length / 2) + 1 : 15;
          for (const candidateFen of [
            `${placement} ${inferred.turn} ${castling} ${ep} 0 ${moveCount}`,
            `${placement} ${inferred.turn} ${castling} - 0 ${moveCount}`,
            `${placement} ${inferred.turn} - - 0 ${moveCount}`,
            `${placement} ${inferred.turn === "w" ? "b" : "w"} ${castling} - 0 ${moveCount}`,
            `${placement} ${inferred.turn === "w" ? "b" : "w"} - - 0 ${moveCount}`
          ]) {
            try {
              const b = new Chess(candidateFen);
              if (placementOf(b.fen()) === placement) {
                return this.remember(b, `\u0631\u0635\u062F \u0645\u0628\u0627\u0634\u0631 (${inferred.reason})`);
              }
            } catch {
            }
          }
        } catch (e) {
        }
      }
      return null;
    }
  };
  function scoreLabel(result) {
    if (result.terminal === "mate") return { title: `${result.cpWhite > 0 ? "\u0627\u0644\u0623\u0628\u064A\u0636" : "\u0627\u0644\u0623\u0633\u0648\u062F"} \u0641\u0627\u0632 \u0628\u0627\u0644\u0643\u0634 \u0645\u0627\u062A`, score: "\u0645\u0627\u062A" };
    if (result.terminal === "draw") return { title: "\u0627\u0644\u0645\u0648\u0642\u0641 \u062A\u0639\u0627\u062F\u0644", score: "0.0" };
    if (result.mate != null) return { title: `${result.cpWhite > 0 ? "\u0627\u0644\u0623\u0628\u064A\u0636" : "\u0627\u0644\u0623\u0633\u0648\u062F"} \u0644\u062F\u064A\u0647 \u0645\u0627\u062A \u0625\u062C\u0628\u0627\u0631\u064A`, score: `M${Math.abs(result.mate)}` };
    const cp = result.cpWhite;
    return { title: Math.abs(cp) < 35 ? "\u0627\u0644\u0645\u0648\u0642\u0641 \u0645\u062A\u0648\u0627\u0632\u0646 \u062A\u0642\u0631\u064A\u0628\u064B\u0627" : `${cp > 0 ? "\u0627\u0644\u0623\u0628\u064A\u0636" : "\u0627\u0644\u0623\u0633\u0648\u062F"} \u0645\u062A\u0641\u0648\u0642`, score: `${cp > 0 ? "+" : ""}${(cp / 100).toFixed(1)}` };
  }

  // extension/src/detect.js
  var file3 = "abcdefgh";
  var names = { pawn: "p", knight: "n", bishop: "b", rook: "r", queen: "q", king: "k" };
  function parseSquareClass(classList) {
    for (const c of classList) {
      if (/^square-[1-8][1-8]$/.test(c)) {
        return file3[Number(c[7]) - 1] + c[8];
      }
      if (/^square-0[1-8]0[1-8]$/.test(c)) {
        return file3[Number(c[8]) - 1] + c[10];
      }
      if (/^square-[a-h][1-8]$/.test(c)) {
        return c.slice(7);
      }
    }
    return null;
  }
  function sanText(element) {
    const figurines = { "\u2654": "K", "\u265A": "K", "\u2655": "Q", "\u265B": "Q", "\u2656": "R", "\u265C": "R", "\u2657": "B", "\u265D": "B", "\u2658": "N", "\u265E": "N", "\u2659": "", "\u265F": "" };
    const content = element.cloneNode(true);
    for (const extra of content.querySelectorAll(".timestamp, .move-time, .annotation, [data-nag], .evaluation, draw")) extra.remove();
    let text = (element.dataset.san || element.dataset.uci || content.textContent).trim().replace(/[♔♚♕♛♖♜♗♝♘♞♙♟]/g, (x) => figurines[x]);
    const icon = element.querySelector("[data-figurine], .icon-font-chess");
    const kind = icon?.dataset.figurine?.toLowerCase() || Object.keys(names).find((name) => icon?.classList.contains(name) || icon?.getAttribute("class")?.includes(name));
    const piece = names[kind] || (/^[pnbrqk]$/.test(kind || "") ? kind : null);
    text = text.replace(/[\u200b-\u200f\u202a-\u202e\ufe0e\ufe0f]/g, "").replace(/^\s*\d+\.(?:\.\.)?\s*/, "").replace(/[!?\s]/g, "").replace(/^[.…]+/, "").replace(/e\.?p\.?$/i, "");
    if (piece && piece !== "p" && !/^[KQRBN]/.test(text)) text = piece.toUpperCase() + text;
    return text.replace(/^0-0-0/, "O-O-O").replace(/^0-0/, "O-O");
  }
  function readMoveHistory(doc, type, boardElement) {
    let list = [];
    if (type === "Chess.com") {
      const roots = [...doc.querySelectorAll("wc-move-list, wc-simple-move-list, vertical-move-list, move-list, #live-game-tab-scroll-container, .play-controller-moveList")];
      const owned = roots.filter((root) => boardElement.id && root.getAttribute("board-id") === boardElement.id);
      const sources = owned.length ? owned : roots.length ? roots : [doc];
      for (const root of sources) {
        let nodes = [...root.querySelectorAll(".main-line-ply")].filter((n) => !n.dataset.node || n.dataset.node.startsWith("0-"));
        if (!nodes.length) nodes = [...root.querySelectorAll(".node-highlight-content, .move-text-component, [data-san], [data-uci]")].filter((n) => !n.closest(".variation, .variation-line, .variation-move-list"));
        const leaves = nodes.map((n) => n.querySelector(".node-highlight-content, .move-text-component") || n);
        const unique = [...new Set(leaves)].filter((n) => !leaves.some((other) => other !== n && n.contains(other)));
        if (unique.length > list.length) list = unique;
      }
    } else {
      list = [...doc.querySelectorAll(".tview2 move, .analyse__moves move, .round__app .moves move, rm6 l4x kwdb")];
      const groups = /* @__PURE__ */ new Map();
      const sanPattern = /^(?:O-O(?:-O)?|[KQRBN]?[a-h]?[1-8]?x?[a-h][1-8](?:=[QRBN])?)[+#]?$/;
      for (const node2 of doc.querySelectorAll(".round__app *")) {
        if (!sanPattern.test(sanText(node2)) || [...node2.children].some((child) => child.tagName.toLowerCase() !== "draw")) continue;
        const group = groups.get(node2.parentElement) || [];
        group.push(node2);
        groups.set(node2.parentElement, group);
      }
      for (const group of groups.values()) if (group.length > list.length) list = group;
    }
    const moves = [];
    let selectedPly = null;
    for (const node2 of list) {
      const san = sanText(node2);
      if (!san || /^(1-0|0-1|1\/2-1\/2|½-½|\*)$/.test(san)) continue;
      moves.push(san);
      if (node2.matches(".selected, .active, .a1t") || node2.closest(".main-line-ply")?.matches(".selected, .active")) selectedPly = moves.length;
    }
    return { sans: moves, selectedPly };
  }
  function visible(element) {
    const r = element.getBoundingClientRect();
    return r.width >= 180 && r.height >= 180 && Math.abs(r.width - r.height) < r.width * 0.12 && getComputedStyle(element).visibility !== "hidden";
  }
  function detectBoard(doc = document) {
    const candidates = [...doc.querySelectorAll("wc-chess-board, chess-board, cg-board, [data-fen]")].filter(visible);
    const element = candidates.sort((a, b) => b.getBoundingClientRect().width - a.getBoundingClientRect().width)[0];
    if (!element) return null;
    const rect = element.getBoundingClientRect();
    const flipped = element.classList.contains("flipped") || !!element.closest(".orientation-black, .flipped") || element.dataset.orientation === "black";
    const pieces = /* @__PURE__ */ new Map();
    let placement, fullFen = element.dataset.fen || null, type = "\u0631\u0642\u0639\u0629 \u0645\u062A\u0648\u0627\u0641\u0642\u0629";
    if (fullFen) placement = fullFen.split(" ")[0];
    else if (element.matches("wc-chess-board, chess-board")) {
      type = "Chess.com";
      for (const node2 of element.querySelectorAll(".piece")) {
        if (node2.matches(".ghost, .dragging, .fading")) continue;
        const code = [...node2.classList].find((x) => /^[wb][pnbrqk]$/.test(x)) || (node2.dataset?.piece ? node2.dataset.piece.toLowerCase() : null);
        const name = parseSquareClass(node2.classList);
        if (!code || !name) continue;
        if (pieces.has(name)) return null;
        pieces.set(name, code);
      }
      placement = makePlacement(pieces);
    } else if (element.matches("cg-board")) {
      type = "Lichess";
      for (const node2 of element.querySelectorAll("piece")) {
        if (node2.matches(".ghost, .dragging, .fading")) continue;
        const color = node2.classList.contains("white") ? "w" : node2.classList.contains("black") ? "b" : null;
        const kind = Object.keys(names).find((name) => node2.classList.contains(name));
        if (!color || !kind) continue;
        const r = node2.getBoundingClientRect();
        const x = (r.left + r.width / 2 - rect.left) / rect.width * 8 - 0.5;
        const y = (r.top + r.height / 2 - rect.top) / rect.height * 8 - 0.5;
        if (Math.abs(x - Math.round(x)) > 0.18 || Math.abs(y - Math.round(y)) > 0.18) return null;
        const col = Math.round(x), row = Math.round(y);
        if (col < 0 || col > 7 || row < 0 || row > 7) return null;
        const square = file3[flipped ? 7 - col : col] + (flipped ? row + 1 : 8 - row);
        if (pieces.has(square)) return null;
        pieces.set(square, color + names[kind]);
      }
      placement = makePlacement(pieces);
    } else return null;
    const highlights = [];
    if (type === "Chess.com" || element.matches("wc-chess-board, chess-board")) {
      for (const node2 of element.querySelectorAll('.highlight, [data-test-element="highlight"]')) {
        const sq = parseSquareClass(node2.classList);
        if (sq && !highlights.includes(sq)) highlights.push(sq);
      }
    } else if (type === "Lichess" || element.matches("cg-board")) {
      for (const node2 of element.querySelectorAll("square.last-move, .last-move")) {
        const r = node2.getBoundingClientRect();
        if (r.width > 0) {
          const x = (r.left + r.width / 2 - rect.left) / rect.width * 8 - 0.5;
          const y = (r.top + r.height / 2 - rect.top) / rect.height * 8 - 0.5;
          const col = Math.round(x), row = Math.round(y);
          if (col >= 0 && col <= 7 && row >= 0 && row <= 7) {
            const sq = file3[flipped ? 7 - col : col] + (flipped ? row + 1 : 8 - row);
            if (!highlights.includes(sq)) highlights.push(sq);
          }
        }
      }
    }
    if ((placement.match(/K/g) || []).length !== 1 || (placement.match(/k/g) || []).length !== 1) return null;
    const { sans, selectedPly } = readMoveHistory(doc, type, element);
    if (!fullFen) {
      for (const input of doc.querySelectorAll('input.fen, input[name="fen"], .copyables input, input[aria-label*="FEN"], textarea[name="fen"]')) {
        if (input.value?.split(" ")[0] === placement) {
          fullFen = input.value.trim();
          break;
        }
      }
    }
    return { element, placement, fullFen, sans, selectedPly, flipped, type, rect, pieces, highlights, doc };
  }
  function arrowPoints(move, flipped = false) {
    const point = (square) => {
      const col = file3.indexOf(square[0]), rank2 = Number(square[1]) - 1;
      return { x: ((flipped ? 7 - col : col) + 0.5) * 12.5, y: ((flipped ? rank2 : 7 - rank2) + 0.5) * 12.5 };
    };
    return { from: point(move.slice(0, 2)), to: point(move.slice(2, 4)) };
  }

  // extension/src/coach.js
  var PIECE_NAMES = {
    p: "\u0627\u0644\u0628\u064A\u062F\u0642",
    n: "\u0627\u0644\u062D\u0635\u0627\u0646",
    b: "\u0627\u0644\u0641\u064A\u0644",
    r: "\u0627\u0644\u0631\u062E",
    q: "\u0627\u0644\u0648\u0632\u064A\u0631",
    k: "\u0627\u0644\u0645\u0644\u0643"
  };
  var PIECE_VALUES = {
    p: 100,
    n: 320,
    b: 330,
    r: 500,
    q: 900,
    k: 2e4
  };
  function getExchangeGain(board, square, depth = 0) {
    if (depth >= 8) return 0;
    let best = 0;
    for (const move of board.moves({ verbose: true })) {
      if (move.to !== square || !move.captured) continue;
      const piece = board.get(square);
      const gain = PIECE_VALUES[move.captured] || 0;
      const boardCopy = new Chess(board.fen());
      boardCopy.move({ from: move.from, to: move.to, promotion: move.promotion });
      best = Math.max(best, gain - getExchangeGain(boardCopy, square, depth + 1));
    }
    return best;
  }
  function isAttackedBy(board, square, byColor) {
    for (const move of board.moves({ verbose: true })) {
      if (move.to === square && move.color === byColor) return true;
    }
    return false;
  }
  function findHangingPiece(board, color) {
    for (const row of board.board()) {
      for (const cell of row) {
        if (!cell || cell.color !== color || cell.type === "k") continue;
        const gain = getExchangeGain(board, cell.square);
        if (gain >= 120) {
          return { piece: cell.type, square: cell.square, gain };
        }
      }
    }
    return null;
  }
  function explainBestMove({ fen, bestUci, score, depth }) {
    if (!fen || !bestUci) {
      return {
        text: "\u0628\u0627\u0646\u062A\u0638\u0627\u0631 \u062A\u062D\u0644\u064A\u0644 \u0627\u0644\u0648\u0636\u0639\u064A\u0629 \u0644\u0627\u0642\u062A\u0631\u0627\u062D \u0623\u0641\u0636\u0644 \u0646\u0642\u0644\u0629 \u0648\u0634\u0631\u062D \u0623\u0633\u0628\u0627\u0628\u0647\u0627 \u0627\u0644\u062A\u0643\u062A\u064A\u0643\u064A\u0629.",
        voice: "\u0628\u0627\u0646\u062A\u0638\u0627\u0631 \u062A\u062D\u0644\u064A\u0644 \u0627\u0644\u0648\u0636\u0639\u064A\u0629 \u0644\u0627\u0642\u062A\u0631\u0627\u062D \u0623\u0641\u0636\u0644 \u0646\u0642\u0644\u0629.",
        motif: "wait",
        icon: "\u23F3"
      };
    }
    let board;
    try {
      board = new Chess(fen);
    } catch {
      return fallbackExplain();
    }
    const from = bestUci.slice(0, 2);
    const to = bestUci.slice(2, 4);
    const promotion = bestUci[4];
    const piece = board.get(from);
    if (!piece) return fallbackExplain();
    const moverColor = piece.color;
    const oppColor = moverColor === "w" ? "b" : "w";
    const moverName = PIECE_NAMES[piece.type] || "\u0627\u0644\u0642\u0637\u0639\u0629";
    const wasUnderAttack = isAttackedBy(board, from, oppColor);
    let moveResult;
    try {
      moveResult = board.move({ from, to, promotion });
    } catch {
      return fallbackExplain();
    }
    if (!moveResult) return fallbackExplain();
    if (board.isCheckmate()) {
      return {
        text: "\u{1F3C6} \u0643\u0634 \u0645\u0627\u062A \u062D\u0627\u0633\u0645! \u0647\u0630\u0647 \u0627\u0644\u0646\u0642\u0644\u0629 \u0647\u064A \u0627\u0644\u0623\u0641\u0636\u0644 \u0644\u0623\u0646\u0647\u0627 \u062A\u0646\u0647\u064A \u0627\u0644\u0645\u0628\u0627\u0631\u0627\u0629 \u0641\u0648\u0631\u0627\u064B \u0628\u0641\u0648\u0632 \u0645\u0633\u062A\u062D\u0642!",
        voice: "\u0643\u0634 \u0645\u0627\u062A \u062D\u0627\u0633\u0645! \u0647\u0630\u0647 \u0627\u0644\u0646\u0642\u0644\u0629 \u0647\u064A \u0627\u0644\u0623\u0641\u0636\u0644 \u0644\u0623\u0646\u0647\u0627 \u062A\u0646\u0647\u064A \u0627\u0644\u0645\u0628\u0627\u0631\u0627\u0629 \u0641\u0648\u0631\u0627\u064B \u0628\u0641\u0648\u0632 \u0645\u0633\u062A\u062D\u0642!",
        motif: "mate",
        icon: "\u{1F3C6}"
      };
    }
    if (moveResult.captured === "q") {
      return {
        text: "\u{1F451} \u0623\u0633\u0631 \u0627\u0644\u0648\u0632\u064A\u0631! \u0647\u0630\u0647 \u0627\u0644\u0646\u0642\u0644\u0629 \u0647\u064A \u0627\u0644\u0623\u0641\u0636\u0644 \u0644\u0623\u0646\u0647\u0627 \u062A\u0633\u0642\u0637 \u0623\u0642\u0648\u0649 \u0642\u0637\u0639 \u0627\u0644\u062E\u0635\u0645 \u0648\u062A\u0645\u0646\u062D\u0643 \u062A\u0641\u0648\u0642\u0627\u064B \u062D\u0627\u0633\u0645\u0627\u064B \u0639\u0644\u0649 \u0627\u0644\u0631\u0642\u0639\u0629!",
        voice: "\u0623\u0633\u0631 \u0627\u0644\u0648\u0632\u064A\u0631! \u0647\u0630\u0647 \u0627\u0644\u0646\u0642\u0644\u0629 \u0647\u064A \u0627\u0644\u0623\u0641\u0636\u0644 \u0644\u0623\u0646\u0647\u0627 \u062A\u0633\u0642\u0637 \u0623\u0642\u0648\u0649 \u0642\u0637\u0639 \u0627\u0644\u062E\u0635\u0645 \u0648\u062A\u0645\u0646\u062D\u0643 \u062A\u0641\u0648\u0642\u0627\u064B \u062D\u0627\u0633\u0645\u0627\u064B \u0639\u0644\u0649 \u0627\u0644\u0631\u0642\u0639\u0629!",
        motif: "queen_capture",
        icon: "\u{1F451}"
      };
    }
    if (moveResult.captured) {
      const capName = PIECE_NAMES[moveResult.captured] || "\u0642\u0637\u0639\u0629";
      const capVal = PIECE_VALUES[moveResult.captured] || 0;
      const moverVal = PIECE_VALUES[piece.type] || 0;
      if (capVal > moverVal) {
        return {
          text: `\u{1F48E} \u0645\u0643\u0633\u0628 \u0645\u0627\u062F\u064A \u0643\u0628\u064A\u0631! \u0647\u0630\u0647 \u0627\u0644\u0646\u0642\u0644\u0629 \u0647\u064A \u0627\u0644\u0623\u0641\u0636\u0644 \u0644\u0623\u0646\u0647\u0627 \u062A\u0623\u062E\u0630 ${capName} \u0628\u0640${moverName} \u0648\u062A\u062D\u0642\u0642 \u062A\u0641\u0648\u0642\u0627\u064B \u062A\u0643\u062A\u064A\u0643\u064A\u0627\u064B \u062B\u0645\u064A\u0646\u0627\u064B!`,
          voice: `\u0645\u0643\u0633\u0628 \u0645\u0627\u062F\u064A \u0643\u0628\u064A\u0631! \u0647\u0630\u0647 \u0627\u0644\u0646\u0642\u0644\u0629 \u0647\u064A \u0627\u0644\u0623\u0641\u0636\u0644 \u0644\u0623\u0646\u0647\u0627 \u062A\u0623\u062E\u0630 ${capName} \u0628\u0640${moverName} \u0648\u062A\u062D\u0642\u0642 \u062A\u0641\u0648\u0642\u0627\u064B \u062A\u0643\u062A\u064A\u0643\u064A\u0627\u064B \u062B\u0645\u064A\u0646\u0627\u064B!`,
          motif: "favorable_exchange",
          icon: "\u{1F48E}"
        };
      }
      return {
        text: `\u2694\uFE0F \u0623\u0633\u0631 \u0642\u0637\u0639\u0629! \u0647\u0630\u0647 \u0627\u0644\u0646\u0642\u0644\u0629 \u0647\u064A \u0627\u0644\u0623\u0641\u0636\u0644 \u0644\u0623\u0646\u0647\u0627 \u062A\u0623\u062E\u0630 ${capName} \u0648\u062A\u0632\u064A\u062F \u0645\u0646 \u0627\u0644\u0636\u063A\u0637 \u0627\u0644\u0647\u062C\u0648\u0645\u064A \u0639\u0644\u0649 \u062F\u0641\u0627\u0639\u0627\u062A \u0627\u0644\u062E\u0635\u0645!`,
        voice: `\u0623\u0633\u0631 \u0642\u0637\u0639\u0629! \u0647\u0630\u0647 \u0627\u0644\u0646\u0642\u0644\u0629 \u0647\u064A \u0627\u0644\u0623\u0641\u0636\u0644 \u0644\u0623\u0646\u0647\u0627 \u062A\u0623\u062E\u0630 ${capName} \u0648\u062A\u0632\u064A\u062F \u0645\u0646 \u0627\u0644\u0636\u063A\u0637 \u0627\u0644\u0647\u062C\u0648\u0645\u064A \u0639\u0644\u0649 \u062F\u0641\u0627\u0639\u0627\u062A \u0627\u0644\u062E\u0635\u0645!`,
        motif: "piece_capture",
        icon: "\u2694\uFE0F"
      };
    }
    if (moveResult.san === "O-O" || moveResult.san === "O-O-O") {
      return {
        text: "\u{1F3F0} \u062A\u0623\u0645\u064A\u0646 \u0627\u0644\u0645\u0644\u0643 \u0628\u0627\u0644\u062A\u0628\u064A\u064A\u062A! \u0647\u0630\u0647 \u0627\u0644\u0646\u0642\u0644\u0629 \u0647\u064A \u0627\u0644\u0623\u0641\u0636\u0644 \u0644\u062D\u0645\u0627\u064A\u0629 \u0627\u0644\u0645\u0644\u0643 \u0648\u0631\u0628\u0637 \u0627\u0644\u0631\u062E\u064A\u0646 \u0645\u0639\u0627\u064B \u0644\u0644\u0645\u0634\u0627\u0631\u0643\u0629 \u0641\u064A \u0627\u0644\u0645\u0639\u0631\u0643\u0629!",
        voice: "\u062A\u0623\u0645\u064A\u0646 \u0627\u0644\u0645\u0644\u0643 \u0628\u0627\u0644\u062A\u0628\u064A\u064A\u062A! \u0647\u0630\u0647 \u0627\u0644\u0646\u0642\u0644\u0629 \u0647\u064A \u0627\u0644\u0623\u0641\u0636\u0644 \u0644\u062D\u0645\u0627\u064A\u0629 \u0627\u0644\u0645\u0644\u0643 \u0648\u0631\u0628\u0637 \u0627\u0644\u0631\u062E\u064A\u0646 \u0645\u0639\u0627\u064B \u0644\u0644\u0645\u0634\u0627\u0631\u0643\u0629 \u0641\u064A \u0627\u0644\u0645\u0639\u0631\u0643\u0629!",
        motif: "castling",
        icon: "\u{1F3F0}"
      };
    }
    if (wasUnderAttack) {
      return {
        text: `\u{1F6E1}\uFE0F \u0625\u0646\u0642\u0627\u0630 \u062A\u0643\u062A\u064A\u0643\u064A! \u0647\u0630\u0647 \u0627\u0644\u0646\u0642\u0644\u0629 \u0647\u064A \u0627\u0644\u0623\u0641\u0636\u0644 \u0644\u0623\u0646\u0647\u0627 \u062A\u0647\u0631\u0628 \u0628\u0640${moverName} \u0645\u0646 \u062A\u0647\u062F\u064A\u062F \u0645\u0628\u0627\u0634\u0631 \u0625\u0644\u0649 \u0645\u0631\u0628\u0639 ${to} \u0628\u0623\u0645\u0627\u0646 \u0648\u0642\u0648\u0629!`,
        voice: `\u0625\u0646\u0642\u0627\u0630 \u062A\u0643\u062A\u064A\u0643\u064A! \u0647\u0630\u0647 \u0627\u0644\u0646\u0642\u0644\u0629 \u0647\u064A \u0627\u0644\u0623\u0641\u0636\u0644 \u0644\u0623\u0646\u0647\u0627 \u062A\u0647\u0631\u0628 \u0628\u0640${moverName} \u0645\u0646 \u062A\u0647\u062F\u064A\u062F \u0645\u0628\u0627\u0634\u0631 \u0625\u0644\u0649 \u0645\u0631\u0628\u0639 \u0622\u0645\u0646 \u0628\u0642\u0648\u0629!`,
        motif: "escape",
        icon: "\u{1F6E1}\uFE0F"
      };
    }
    if (board.isCheck()) {
      return {
        text: `\u26A1 \u0643\u0634 \u0647\u062C\u0648\u0645\u064A! \u0647\u0630\u0647 \u0627\u0644\u0646\u0642\u0644\u0629 \u0647\u064A \u0627\u0644\u0623\u0641\u0636\u0644 \u0644\u0623\u0646\u0647\u0627 \u062A\u0628\u0627\u063A\u062A \u0645\u0644\u0643 \u0627\u0644\u062E\u0635\u0645 \u0648\u062A\u062C\u0628\u0631\u0647 \u0639\u0644\u0649 \u0641\u0642\u062F\u0627\u0646 \u0627\u0644\u062A\u0628\u064A\u064A\u062A \u0623\u0648 \u0627\u0644\u062A\u0631\u0627\u062C\u0639 \u0627\u0644\u062F\u0641\u0627\u0639\u064A!`,
        voice: `\u0643\u0634 \u0647\u062C\u0648\u0645\u064A! \u0647\u0630\u0647 \u0627\u0644\u0646\u0642\u0644\u0629 \u0647\u064A \u0627\u0644\u0623\u0641\u0636\u0644 \u0644\u0623\u0646\u0647\u0627 \u062A\u0628\u0627\u063A\u062A \u0645\u0644\u0643 \u0627\u0644\u062E\u0635\u0645 \u0648\u062A\u062C\u0628\u0631\u0647 \u0639\u0644\u0649 \u0641\u0642\u062F\u0627\u0646 \u0627\u0644\u062A\u0628\u064A\u064A\u062A \u0623\u0648 \u0627\u0644\u062A\u0631\u0627\u062C\u0639 \u0627\u0644\u062F\u0641\u0627\u0639\u064A!`,
        motif: "check",
        icon: "\u26A1"
      };
    }
    const attackedPieces = [];
    for (const cand of board.moves({ verbose: true })) {
      if (cand.from === to && cand.captured && ["q", "r", "b", "n"].includes(cand.captured)) {
        attackedPieces.push(cand.captured);
      }
    }
    if (attackedPieces.length >= 2) {
      const p1 = PIECE_NAMES[attackedPieces[0]];
      const p2 = PIECE_NAMES[attackedPieces[1]];
      return {
        text: `\u{1F531} \u0634\u0648\u0643\u0629 \u062A\u0643\u062A\u064A\u0643\u064A\u0629 \u0645\u0632\u062F\u0648\u062C\u0629 (Fork)! \u0647\u0630\u0647 \u0627\u0644\u0646\u0642\u0644\u0629 \u0647\u064A \u0627\u0644\u0623\u0641\u0636\u0644 \u0644\u0623\u0646\u0647\u0627 \u062A\u0647\u0627\u062C\u0645 ${p1} \u0648${p2} \u0645\u0639\u0627\u064B \u0641\u064A \u0646\u0641\u0633 \u0627\u0644\u0648\u0642\u062A!`,
        voice: `\u0634\u0648\u0643\u0629 \u062A\u0643\u062A\u064A\u0643\u064A\u0629 \u0645\u0632\u062F\u0648\u062C\u0629! \u0647\u0630\u0647 \u0627\u0644\u0646\u0642\u0644\u0629 \u0647\u064A \u0627\u0644\u0623\u0641\u0636\u0644 \u0644\u0623\u0646\u0647\u0627 \u062A\u0647\u0627\u062C\u0645 ${p1} \u0648${p2} \u0645\u0639\u0627\u064B \u0641\u064A \u0646\u0641\u0633 \u0627\u0644\u0648\u0642\u062A!`,
        motif: "fork",
        icon: "\u{1F531}"
      };
    }
    if (attackedPieces.length === 1) {
      const targetName = PIECE_NAMES[attackedPieces[0]];
      return {
        text: `\u{1F3AF} \u0647\u062C\u0648\u0645 \u0645\u0628\u0627\u0634\u0631! \u0647\u0630\u0647 \u0627\u0644\u0646\u0642\u0644\u0629 \u0647\u064A \u0627\u0644\u0623\u0641\u0636\u0644 \u0644\u0623\u0646\u0647\u0627 \u062A\u0636\u0639 ${moverName} \u0645\u0647\u062F\u062F\u0627\u064B \u0628\u0623\u0633\u0631 ${targetName} \u0641\u064A \u0627\u0644\u0646\u0642\u0644\u0629 \u0627\u0644\u0642\u0627\u062F\u0645\u0629!`,
        voice: `\u0647\u062C\u0648\u0645 \u0645\u0628\u0627\u0634\u0631! \u0647\u0630\u0647 \u0627\u0644\u0646\u0642\u0644\u0629 \u0647\u064A \u0627\u0644\u0623\u0641\u0636\u0644 \u0644\u0623\u0646\u0647\u0627 \u062A\u0636\u0639 ${moverName} \u0645\u0647\u062F\u062F\u0627\u064B \u0628\u0623\u0633\u0631 ${targetName} \u0641\u064A \u0627\u0644\u0646\u0642\u0644\u0629 \u0627\u0644\u0642\u0627\u062F\u0645\u0629!`,
        motif: "threat",
        icon: "\u{1F3AF}"
      };
    }
    if (["e4", "d4", "e5", "d5", "c4", "f4", "c5", "f5"].includes(to)) {
      return {
        text: `\u2B50 \u0627\u0644\u0633\u064A\u0637\u0631\u0629 \u0639\u0644\u0649 \u0627\u0644\u0648\u0633\u0637! \u0647\u0630\u0647 \u0627\u0644\u0646\u0642\u0644\u0629 \u0647\u064A \u0627\u0644\u0623\u0641\u0636\u0644 \u0644\u0641\u0631\u0636 \u0627\u0644\u0647\u064A\u0645\u0646\u0629 \u0639\u0644\u0649 \u0645\u0631\u0628\u0639\u0627\u062A \u0627\u0644\u0645\u0631\u0643\u0632 \u0648\u062A\u0648\u0633\u064A\u0639 \u0627\u0646\u062A\u0634\u0627\u0631 \u0627\u0644\u0642\u0637\u0639.`,
        voice: `\u0627\u0644\u0633\u064A\u0637\u0631\u0629 \u0639\u0644\u0649 \u0627\u0644\u0648\u0633\u0637! \u0647\u0630\u0647 \u0627\u0644\u0646\u0642\u0644\u0629 \u0647\u064A \u0627\u0644\u0623\u0641\u0636\u0644 \u0644\u0641\u0631\u0636 \u0627\u0644\u0647\u064A\u0645\u0646\u0629 \u0639\u0644\u0649 \u0645\u0631\u0628\u0639\u0627\u062A \u0627\u0644\u0645\u0631\u0643\u0632 \u0648\u062A\u0648\u0633\u064A\u0639 \u0627\u0646\u062A\u0634\u0627\u0631 \u0627\u0644\u0642\u0637\u0639.`,
        motif: "center",
        icon: "\u2B50"
      };
    }
    return {
      text: `\u2728 \u0646\u0642\u0644\u0629 \u062A\u0643\u062A\u064A\u0643\u064A\u0629 \u062F\u0642\u064A\u0642\u0629! \u0647\u0630\u0647 \u0627\u0644\u0646\u0642\u0644\u0629 \u0647\u064A \u0627\u0644\u0623\u0641\u0636\u0644 \u0644\u062A\u062D\u0633\u064A\u0646 \u0645\u0648\u0642\u0639 ${moverName} \u0648\u0628\u0646\u0627\u0621 \u0623\u0641\u0636\u0644\u064A\u0629 \u062A\u0631\u0627\u0643\u0645\u064A\u0629 \u0641\u064A \u0627\u0644\u0648\u0636\u0639\u064A\u0629.`,
      voice: `\u0646\u0642\u0644\u0629 \u062A\u0643\u062A\u064A\u0643\u064A\u0629 \u062F\u0642\u064A\u0642\u0629! \u0647\u0630\u0647 \u0627\u0644\u0646\u0642\u0644\u0629 \u0647\u064A \u0627\u0644\u0623\u0641\u0636\u0644 \u0644\u062A\u062D\u0633\u064A\u0646 \u0645\u0648\u0642\u0639 ${moverName} \u0648\u0628\u0646\u0627\u0621 \u0623\u0641\u0636\u0644\u064A\u0629 \u062A\u0631\u0627\u0643\u0645\u064A\u0629 \u0641\u064A \u0627\u0644\u0648\u0636\u0639\u064A\u0629.`,
      motif: "develop",
      icon: "\u2728"
    };
  }
  function fallbackExplain() {
    return {
      text: "\u0647\u0630\u0647 \u0627\u0644\u0646\u0642\u0644\u0629 \u0647\u064A \u0627\u0644\u0623\u0641\u0636\u0644 \u0648\u0641\u0642\u0627\u064B \u0644\u0645\u062D\u0631\u0643 Stockfish \u0644\u062A\u0639\u0632\u064A\u0632 \u0627\u0644\u0648\u0636\u0639\u064A\u0629 \u0648\u062A\u062D\u0642\u064A\u0642 \u0627\u0644\u062A\u0641\u0648\u0642.",
      voice: "\u0647\u0630\u0647 \u0627\u0644\u0646\u0642\u0644\u0629 \u0647\u064A \u0627\u0644\u0623\u0641\u0636\u0644 \u0648\u0641\u0642\u0627\u064B \u0644\u0645\u062D\u0631\u0643 \u0627\u0644\u0634\u0637\u0631\u0646\u062C \u0644\u062A\u0639\u0632\u064A\u0632 \u0627\u0644\u0648\u0636\u0639\u064A\u0629 \u0648\u062A\u062D\u0642\u064A\u0642 \u0627\u0644\u062A\u0641\u0648\u0642.",
      motif: "engine",
      icon: "\u{1F4A1}"
    };
  }
  function explainMistake({ fenBefore, playedUci, bestUci, dropCp, fenAfter }) {
    let boardBefore, boardAfter;
    try {
      boardBefore = new Chess(fenBefore);
      boardAfter = new Chess(fenAfter);
    } catch {
      return fallbackMistake();
    }
    const from = playedUci.slice(0, 2);
    const to = playedUci.slice(2, 4);
    const moverColor = boardBefore.turn();
    const oppColor = moverColor === "w" ? "b" : "w";
    const movedPiece = boardAfter.get(to);
    if (movedPiece) {
      const gainOnMoved = getExchangeGain(boardAfter, to);
      if (gainOnMoved >= 150) {
        const pName = PIECE_NAMES[movedPiece.type] || "\u0642\u0637\u0639\u062A\u0643";
        return {
          text: `\u26A0\uFE0F \u0647\u0644 \u0623\u0646\u062A \u0645\u062A\u0623\u0643\u062F \u0645\u0646 \u0647\u0630\u0647 \u0627\u0644\u0646\u0642\u0644\u0629\u061F \u0644\u0623\u0646\u0643 \u0646\u0633\u064A\u062A \u0623\u0646 ${pName} \u063A\u064A\u0631 \u0645\u062D\u0645\u064A\u0629 \u0639\u0644\u0649 ${to} \u0648\u064A\u0645\u0643\u0646 \u0644\u0644\u062E\u0635\u0645 \u0623\u062E\u0630\u0647\u0627 \u0645\u062C\u0627\u0646\u0627\u064B!`,
          voice: `\u0647\u0644 \u0623\u0646\u062A \u0645\u062A\u0623\u0643\u062F \u0645\u0646 \u0647\u0630\u0647 \u0627\u0644\u0646\u0642\u0644\u0629\u061F \u0644\u0623\u0646\u0643 \u0646\u0633\u064A\u062A \u0623\u0646 ${pName} \u063A\u064A\u0631 \u0645\u062D\u0645\u064A\u0629 \u0639\u0644\u0649 ${to} \u0648\u064A\u0645\u0643\u0646 \u0644\u0644\u062E\u0635\u0645 \u0623\u062E\u0630\u0647\u0627 \u0645\u062C\u0627\u0646\u0627\u064B!`,
          motif: "hung_moved",
          icon: "\u26A0\uFE0F"
        };
      }
    }
    const hangingOther = findHangingPiece(boardAfter, moverColor);
    if (hangingOther) {
      const pName = PIECE_NAMES[hangingOther.piece] || "\u0642\u0637\u0639\u062A\u0643";
      return {
        text: `\u26A0\uFE0F \u0647\u0644 \u0623\u0646\u062A \u0645\u062A\u0623\u0643\u062F \u0645\u0646 \u0647\u0630\u0647 \u0627\u0644\u0646\u0642\u0644\u0629\u061F \u0644\u0623\u0646\u0643 \u0646\u0633\u064A\u062A \u062D\u0645\u0627\u064A\u0629 ${pName} \u0639\u0644\u0649 ${hangingOther.square} \u0648\u062A\u0631\u0643\u062A\u0647\u0627 \u0641\u0631\u064A\u0633\u0629 \u0633\u0647\u0644\u0629 \u0644\u0644\u062E\u0635\u0645!`,
        voice: `\u0647\u0644 \u0623\u0646\u062A \u0645\u062A\u0623\u0643\u062F \u0645\u0646 \u0647\u0630\u0647 \u0627\u0644\u0646\u0642\u0644\u0629\u061F \u0644\u0623\u0646\u0643 \u0646\u0633\u064A\u062A \u062D\u0645\u0627\u064A\u0629 ${pName} \u0639\u0644\u0649 ${hangingOther.square} \u0648\u062A\u0631\u0643\u062A\u0647\u0627 \u0641\u0631\u064A\u0633\u0629 \u0633\u0647\u0644\u0629 \u0644\u0644\u062E\u0635\u0645!`,
        motif: "hung_other",
        icon: "\u26A0\uFE0F"
      };
    }
    if (boardAfter.isCheckmate() || boardAfter.inCheck() && dropCp >= 400) {
      return {
        text: `\u26A0\uFE0F \u0647\u0644 \u0623\u0646\u062A \u0645\u062A\u0623\u0643\u062F \u0645\u0646 \u0647\u0630\u0647 \u0627\u0644\u0646\u0642\u0644\u0629\u061F \u0644\u0623\u0646\u0643 \u0646\u0633\u064A\u062A \u062A\u0623\u0645\u064A\u0646 \u062F\u0641\u0627\u0639\u0627\u062A \u0645\u0644\u0643\u0643 \u0648\u0633\u0645\u062D\u062A \u0644\u0644\u062E\u0635\u0645 \u0628\u0647\u062C\u0648\u0645 \u0643\u0634 \u0645\u0627\u062A \u062E\u0637\u064A\u0631!`,
        voice: `\u0647\u0644 \u0623\u0646\u062A \u0645\u062A\u0623\u0643\u062F \u0645\u0646 \u0647\u0630\u0647 \u0627\u0644\u0646\u0642\u0644\u0629\u061F \u0644\u0623\u0646\u0643 \u0646\u0633\u064A\u062A \u062A\u0623\u0645\u064A\u0646 \u062F\u0641\u0627\u0639\u0627\u062A \u0645\u0644\u0643\u0643 \u0648\u0633\u0645\u062D\u062A \u0644\u0644\u062E\u0635\u0645 \u0628\u0647\u062C\u0648\u0645 \u0643\u0634 \u0645\u0627\u062A \u062E\u0637\u064A\u0631!`,
        motif: "allowed_mate",
        icon: "\u26A0\uFE0F"
      };
    }
    if (bestUci) {
      const bestFrom = bestUci.slice(0, 2);
      const bestTo = bestUci.slice(2, 4);
      const bestPiece = boardBefore.get(bestFrom);
      const targetPiece = boardBefore.get(bestTo);
      if (targetPiece && PIECE_VALUES[targetPiece.type] >= 300) {
        const tName = PIECE_NAMES[targetPiece.type] || "\u0642\u0637\u0639\u0629 \u0627\u0644\u062E\u0635\u0645";
        return {
          text: `\u26A0\uFE0F \u0647\u0644 \u0623\u0646\u062A \u0645\u062A\u0623\u0643\u062F \u0645\u0646 \u0647\u0630\u0647 \u0627\u0644\u0646\u0642\u0644\u0629\u061F \u0644\u0623\u0646\u0643 \u0646\u0633\u064A\u062A \u0623\u0646 \u062A\u0647\u062F\u062F ${tName} \u0639\u0644\u0649 ${bestTo} \u0648\u062A\u0641\u0648\u062A \u0641\u0631\u0635\u0629 \u0623\u0633\u0631\u0647\u0627 \u0643\u0645\u0627 \u0623\u0648\u0635\u0649 \u0627\u0644\u0645\u062D\u0631\u0643!`,
          voice: `\u0647\u0644 \u0623\u0646\u062A \u0645\u062A\u0623\u0643\u062F \u0645\u0646 \u0647\u0630\u0647 \u0627\u0644\u0646\u0642\u0644\u0629\u061F \u0644\u0623\u0646\u0643 \u0646\u0633\u064A\u062A \u0623\u0646 \u062A\u0647\u062F\u062F ${tName} \u0639\u0644\u0649 ${bestTo} \u0648\u062A\u0641\u0648\u062A \u0641\u0631\u0635\u0629 \u0623\u0633\u0631\u0647\u0627 \u0643\u0645\u0627 \u0623\u0648\u0635\u0649 \u0627\u0644\u0645\u062D\u0631\u0643!`,
          motif: "missed_threat",
          icon: "\u26A0\uFE0F"
        };
      }
    }
    return {
      text: `\u26A0\uFE0F \u0647\u0644 \u0623\u0646\u062A \u0645\u062A\u0623\u0643\u062F \u0645\u0646 \u0647\u0630\u0647 \u0627\u0644\u0646\u0642\u0644\u0629\u061F \u0644\u0623\u0646\u0647\u0627 \u062A\u0641\u0642\u062F\u0643 \u0627\u0644\u0623\u0641\u0636\u0644\u064A\u0629 \u0627\u0644\u062A\u0643\u062A\u064A\u0643\u064A\u0629 \u0648\u062A\u0645\u0646\u062D \u0627\u0644\u062E\u0635\u0645 \u0641\u0631\u0635\u0629 \u0642\u0648\u064A\u0629 \u0644\u0644\u0647\u062C\u0648\u0645 \u0627\u0644\u0645\u0636\u0627\u062F!`,
      voice: `\u0647\u0644 \u0623\u0646\u062A \u0645\u062A\u0623\u0643\u062F \u0645\u0646 \u0647\u0630\u0647 \u0627\u0644\u0646\u0642\u0644\u0629\u061F \u0644\u0623\u0646\u0647\u0627 \u062A\u0641\u0642\u062F\u0643 \u0627\u0644\u0623\u0641\u0636\u0644\u064A\u0629 \u0627\u0644\u062A\u0643\u062A\u064A\u0643\u064A\u0629 \u0648\u062A\u0645\u0646\u062D \u0627\u0644\u062E\u0635\u0645 \u0641\u0631\u0635\u0629 \u0642\u0648\u064A\u0629 \u0644\u0644\u0647\u062C\u0648\u0645 \u0627\u0644\u0645\u0636\u0627\u062F!`,
      motif: "lost_eval",
      icon: "\u26A0\uFE0F"
    };
  }
  function fallbackMistake() {
    return {
      text: "\u26A0\uFE0F \u0647\u0644 \u0623\u0646\u062A \u0645\u062A\u0623\u0643\u062F \u0645\u0646 \u0647\u0630\u0647 \u0627\u0644\u0646\u0642\u0644\u0629\u061F \u0627\u0644\u0645\u062D\u0631\u0643 \u064A\u0639\u062A\u0628\u0631\u0647\u0627 \u0646\u0642\u0644\u0629 \u063A\u064A\u0631 \u062F\u0642\u064A\u0642\u0629 \u062A\u0636\u0639\u0641 \u0648\u0636\u0639\u064A\u062A\u0643.",
      voice: "\u0647\u0644 \u0623\u0646\u062A \u0645\u062A\u0623\u0643\u062F \u0645\u0646 \u0647\u0630\u0647 \u0627\u0644\u0646\u0642\u0644\u0629\u061F \u0627\u0644\u0645\u062D\u0631\u0643 \u064A\u0639\u062A\u0628\u0631\u0647\u0627 \u0646\u0642\u0644\u0629 \u063A\u064A\u0631 \u062F\u0642\u064A\u0642\u0629 \u062A\u0636\u0639\u0641 \u0648\u0636\u0639\u064A\u062A\u0643.",
      motif: "mistake",
      icon: "\u26A0\uFE0F"
    };
  }
  var speechMuted = false;
  function setCoachMuted(muted) {
    speechMuted = Boolean(muted);
    if (speechMuted && typeof window !== "undefined" && "speechSynthesis" in window) {
      window.speechSynthesis.cancel();
    }
  }
  function isCoachMuted() {
    return speechMuted;
  }
  function speakArabic(sentence) {
    if (speechMuted) return;
    if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
    try {
      window.speechSynthesis.cancel();
      const clean = sentence.replace(/[🏆👑💎⚔️🏰🛡️⚡🔱🎯⭐✨⚠️💡]/g, "").replace(/[()]/g, " ").trim();
      const utterance = new SpeechSynthesisUtterance(clean);
      utterance.lang = "ar-SA";
      utterance.rate = 1.05;
      utterance.pitch = 1;
      const voices = window.speechSynthesis.getVoices();
      const arVoice = voices.find((v) => v.lang.startsWith("ar") || v.name.toLowerCase().includes("arabic"));
      if (arVoice) utterance.voice = arVoice;
      window.speechSynthesis.speak(utterance);
    } catch (err) {
      console.warn("Speech synthesis unavailable:", err);
    }
  }

  // extension/src/content.js
  if (!document.getElementById("chess-coach-extension")) start();
  function start() {
    const host = document.createElement("div");
    host.id = "chess-coach-extension";
    host.style.cssText = "all:initial!important;position:fixed!important;inset:0!important;pointer-events:none!important;z-index:2147483646!important;";
    const shadow = host.attachShadow({ mode: "open" });
    shadow.innerHTML = `<style>
    :host{font-family:Arial,Tahoma,sans-serif;color:#f4f6f3;font-size:14px;line-height:1.5}
    *{box-sizing:border-box} [hidden]{display:none!important}
    
    #card{position:fixed;right:16px;bottom:18px;width:310px;max-width:calc(100vw - 24px);background:#1e2320;color:#f4f6f3;font:14px/1.5 Arial,Tahoma,sans-serif;border:1px solid #3d4a40;border-radius:16px;box-shadow:0 12px 48px rgba(0,0,0,0.65);pointer-events:auto;direction:rtl;overflow:hidden;z-index:2147483647}
    header{display:flex;align-items:center;justify-content:space-between;padding:10px 14px;border-bottom:1px solid #2f3a32;background:#181d1a;cursor:move;touch-action:none}
    header strong{font-size:15px;direction:ltr;color:#8ae368;display:flex;align-items:center;gap:6px}
    
    button,select,textarea{font:inherit}
    button{background:#2b362e;color:#f4f6f3;border:1px solid #435447;border-radius:7px;padding:6px 10px;cursor:pointer;transition:all .15s}
    button:hover{background:#38483d}
    button:focus-visible,textarea:focus-visible{outline:2px solid #8ae368;outline-offset:2px}
    #pause{font-size:11px;padding:4px 8px}

    .body{padding:12px 14px}
    #status{color:#9eaea2;font-size:11px;margin:0 0 6px;min-height:16px}
    .result{display:flex;align-items:center;justify-content:space-between;gap:8px}
    #leader{font-size:15px;font-weight:bold}
    #score{font-size:27px;font-weight:bold;color:#8ae368;direction:ltr;font-variant-numeric:tabular-nums}
    #best{margin:6px 0 0;color:#d8e8d9;font-size:13px;font-weight:bold}
    #meta{font-size:11px;color:#85988a;margin-top:4px}

    /* COACH PANEL */
    .coach-panel{margin-top:10px;background:rgba(25, 33, 27, 0.95);border:1px solid #3e5243;border-radius:12px;padding:10px 12px;transition:border-color .2s, background-color .2s}
    .coach-panel.warning{border-color:#eab308;background:rgba(45, 36, 15, 0.95)}
    .coach-panel.best{border-color:#8ae368;background:rgba(20, 36, 23, 0.95)}
    
    .coach-header-row{display:flex;align-items:center;justify-content:space-between;margin-bottom:8px}
    .coach-profile{display:flex;align-items:center;gap:8px}
    .coach-avatar-btn{width:36px;height:36px;border-radius:50%;background:#2e3e32;display:flex;align-items:center;justify-content:center;font-size:20px;cursor:pointer;border:1px solid #4b6352;box-shadow:0 2px 8px rgba(0,0,0,0.3);position:relative;transition:transform .15s}
    .coach-avatar-btn:hover{transform:scale(1.08)}
    .coach-panel.warning .coach-avatar-btn{background:#4d380e;border-color:#eab308}
    .coach-badge{display:flex;flex-direction:column}
    .coach-name{font-size:12px;font-weight:bold;color:#c9e8d0}
    .coach-subtitle{font-size:10px;color:#85998b}
    .coach-panel.warning .coach-name{color:#fde047}

    .coach-controls{display:flex;gap:4px}
    .btn-coach-action{width:28px;height:28px;padding:0;display:flex;align-items:center;justify-content:center;font-size:13px;border-radius:6px;background:#28342b;border:1px solid #3e4f42}
    .btn-coach-action:hover{background:#384a3c}

    .coach-bubble{font-size:12px;line-height:1.55;color:#f0f5ee;background:#151c17;padding:9px 11px;border-radius:8px;border-right:3px solid #8ae368;position:relative}
    .coach-panel.warning .coach-bubble{border-right-color:#eab308;color:#fef08a}

    /* MINI BOARD & TOOLS */
    details{margin-top:10px;border-top:1px solid #2f3a32;padding-top:8px}
    summary{cursor:pointer;font-size:11px;color:#a8baa9}
    #mini{width:184px;height:184px;display:grid;grid-template-columns:repeat(8,1fr);direction:ltr;margin:10px auto;border:1px solid #3f4e43;border-radius:4px;overflow:hidden}
    #mini div{display:flex;align-items:center;justify-content:center;background:#e2e5e1}
    #mini div.dark{background:#9aa39d}
    #mini svg{width:92%;height:92%}
    .actions{display:flex;gap:6px;flex-wrap:wrap;margin-top:8px}
    .actions button{font-size:11px;flex:1}
    textarea{width:100%;min-height:54px;padding:6px;margin-top:6px;background:#151a17;border:1px solid #435447;border-radius:6px;color:white;direction:ltr;font-size:11px;resize:vertical}
    label{display:block;font-size:11px;margin-top:8px;color:#a8baa9}
    #error{font-size:11px;color:#f87171;min-height:15px;margin-top:4px}

    /* ARROW OVERLAY */
    #overlay{position:fixed;pointer-events:none;overflow:visible;filter:drop-shadow(0 2px 4px rgba(0,0,0,0.6));z-index:2147483645}
    #overlay line{pointer-events:stroke;cursor:pointer}
    
    footer{font-size:10px;color:#798c7e;margin-top:8px;text-align:center}
    a{color:#8ae368;text-decoration:none}
  </style>

  <svg id="overlay" hidden viewBox="0 0 100 100" aria-label="\u0633\u0647\u0645 \u0623\u0641\u0636\u0644 \u0646\u0642\u0644\u0629">
    <defs>
      <marker id="coach-tip" markerWidth="3.4" markerHeight="3.4" refX="2.3" refY="1.7" orient="auto" markerUnits="strokeWidth">
        <path d="M0,0 L3.2,1.7 L0,3.4 L.7,1.7 Z" fill="#64cf3c"/>
      </marker>
      <marker id="coach-tip-warn" markerWidth="3.4" markerHeight="3.4" refX="2.3" refY="1.7" orient="auto" markerUnits="strokeWidth">
        <path d="M0,0 L3.2,1.7 L0,3.4 L.7,1.7 Z" fill="#eab308"/>
      </marker>
    </defs>
    <line id="arrow" stroke="#64cf3c" stroke-width="2.5" stroke-linecap="round" opacity=".95" marker-end="url(#coach-tip)"/>
  </svg>

  <section id="card" aria-label="\u062A\u062D\u0644\u064A\u0644 \u0643\u0648\u062A\u0634 \u0627\u0644\u0634\u0637\u0631\u0646\u062C \u0627\u0644\u0639\u0631\u0628\u064A Chess Coach v1">
    <header>
      <strong>\u265F\uFE0F Chess Coach v1</strong>
      <button id="pause" type="button">\u0625\u064A\u0642\u0627\u0641 \u0645\u0624\u0642\u062A</button>
    </header>
    <div class="body">
      <p id="status" role="status">\u062C\u0627\u0631\u064D \u0627\u0644\u0628\u062D\u062B \u0639\u0646 \u0631\u0642\u0639\u0629 \u0627\u0644\u0634\u0637\u0631\u0646\u062C\u2026</p>
      <div class="result">
        <span id="leader">\u0628\u0627\u0646\u062A\u0638\u0627\u0631 \u0627\u0644\u0631\u0642\u0639\u0629</span>
        <span id="score">\u2014</span>
      </div>
      <p id="best">\u0633\u064A\u0638\u0647\u0631 \u0623\u0641\u0636\u0644 \u062A\u062D\u0631\u064A\u0643 \u0628\u0633\u0647\u0645 \u0623\u062E\u0636\u0631 \u0645\u0639 \u0634\u0631\u062D \u0627\u0644\u0643\u0648\u062A\u0634.</p>
      <div id="meta"></div>

      <!-- COACH WIDGET -->
      <div id="coach-panel" class="coach-panel" aria-label="\u0634\u0631\u062D \u0643\u0648\u062A\u0634 \u0627\u0644\u0634\u0637\u0631\u0646\u062C">
        <div class="coach-header-row">
          <div class="coach-profile">
            <div id="coach-avatar" class="coach-avatar-btn" role="button" title="\u0627\u0636\u063A\u0637 \u0644\u0633\u0645\u0627\u0639 \u0627\u0644\u0634\u0631\u062D \u0628\u0627\u0644\u0635\u0648\u062A">\u{1F9D1}\u200D\u{1F3EB}</div>
            <div class="coach-badge">
              <span class="coach-name">\u0643\u0648\u062A\u0634 \u0627\u0644\u0634\u0637\u0631\u0646\u062C \u0627\u0644\u0639\u0631\u0628\u064A</span>
              <span id="coach-badge-tag" class="coach-subtitle">\u062A\u062D\u0644\u064A\u0644 \u062A\u0643\u062A\u064A\u0643\u064A \u0641\u0648\u0631\u064A</span>
            </div>
          </div>
          <div class="coach-controls">
            <button id="coach-voice-btn" type="button" class="btn-coach-action" title="\u062A\u0634\u063A\u064A\u0644/\u0643\u062A\u0645 \u0627\u0644\u0635\u0648\u062A">\u{1F50A}</button>
            <button id="coach-replay-btn" type="button" class="btn-coach-action" title="\u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u0634\u0631\u062D \u0628\u0627\u0644\u0635\u0648\u062A">\u21BA</button>
          </div>
        </div>
        <div class="coach-bubble">
          <span id="coach-text">\u0645\u0631\u062D\u0628\u0627\u064B! \u0623\u0646\u0627 \u0643\u0648\u062A\u0634 \u0627\u0644\u0634\u0637\u0631\u0646\u062C \u0627\u0644\u062E\u0627\u0635 \u0628\u0643. \u0633\u0623\u0634\u0631\u062D \u0644\u0643 \u0628\u0627\u0644\u0635\u0648\u062A \u0623\u0633\u0628\u0627\u0628 \u0643\u0644 \u0646\u0642\u0644\u0629\u060C \u0648\u0633\u0623\u0646\u0628\u0647\u0643 \u0641\u0648\u0631\u0627\u064B \u0625\u0630\u0627 \u0642\u0645\u062A \u0628\u0646\u0642\u0644\u0629 \u062E\u0627\u0637\u0626\u0629.</span>
        </div>
      </div>

      <details>
        <summary>\u0627\u0644\u0631\u0642\u0639\u0629 \u0627\u0644\u0645\u0644\u062A\u0642\u0637\u0629 \u0648\u0623\u062F\u0648\u0627\u062A \u0627\u0644\u0648\u0636\u0639\u064A\u0629</summary>
        <div id="mini" aria-label="\u0646\u0633\u062E\u0629 \u0627\u0644\u0648\u0636\u0639\u064A\u0629 \u0627\u0644\u062D\u0627\u0644\u064A\u0629"></div>
        <div class="actions">
          <button id="copy">\u0646\u0633\u062E FEN</button>
          <button id="open">\u0641\u062A\u062D \u0644\u0644\u062A\u062D\u0644\u064A\u0644 \u0627\u0644\u064A\u062F\u0648\u064A</button>
        </div>
        <label for="fen">FEN \u0643\u0627\u0645\u0644 \u0639\u0646\u062F \u062A\u0639\u0630\u0651\u0631 \u0642\u0631\u0627\u0621\u0629 \u0627\u0644\u062F\u0648\u0631 \u0623\u0648 \u0633\u062C\u0644 \u0627\u0644\u0646\u0642\u0644\u0627\u062A</label>
        <textarea id="fen" spellcheck="false" placeholder="rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"></textarea>
        <div class="actions">
          <button id="apply">\u0627\u0633\u062A\u062E\u062F\u0627\u0645 FEN \u0627\u0644\u0645\u0637\u0627\u0628\u0642 \u0644\u0644\u0631\u0642\u0639\u0629</button>
        </div>
        <div id="error" role="alert"></div>
      </details>

      <footer>Stockfish 19 \u0645\u062D\u0644\u064A \xB7 \u0643\u0648\u062A\u0634 \u0646\u0627\u0637\u0642 \u0628\u0627\u0644\u0644\u063A\u0629 \u0627\u0644\u0639\u0631\u0628\u064A\u0629</footer>
    </div>
  </section>`;
    document.documentElement.appendChild(host);
    const $ = (id) => shadow.getElementById(id);
    const tracker = new PositionTracker(), cache = /* @__PURE__ */ new Map();
    let reading = null;
    let position = null;
    let lastKey = "";
    let version = 0;
    let paused = false;
    let enabled = true;
    let depth = 14;
    let result = null;
    let url = location.href;
    let timer;
    let prevPosition = null;
    let prevResult = null;
    let lastCoachedSpeech = "";
    const text = (id, value) => {
      if ($(id).textContent !== value) $(id).textContent = value;
    };
    function setCoachAdvice(explanation, isWarning = false) {
      if (!explanation) return;
      lastCoachedSpeech = explanation.voice || explanation.text;
      text("coach-text", explanation.text);
      $("coach-avatar").textContent = explanation.icon || (isWarning ? "\u26A0\uFE0F" : "\u{1F9D1}\u200D\u{1F3EB}");
      text("coach-badge-tag", isWarning ? "\u062A\u0646\u0628\u064A\u0647 \u0639\u0644\u0649 \u062E\u0637\u0623 \u062A\u0643\u062A\u064A\u0643\u064A!" : "\u0634\u0631\u062D \u0623\u0633\u0628\u0627\u0628 \u0623\u0641\u0636\u0644 \u0646\u0642\u0644\u0629");
      const panel = $("coach-panel");
      panel.classList.toggle("warning", isWarning);
      panel.classList.toggle("best", !isWarning && explanation.motif !== "wait");
      speakArabic(lastCoachedSpeech);
    }
    function clear(title, status) {
      result = null;
      $("overlay").toggleAttribute("hidden", true);
      text("leader", title);
      text("status", status);
      text("score", "\u2014");
      text("best", "");
      text("meta", "");
    }
    function renderArrow() {
      if (!reading || !result?.best || paused || !enabled) {
        $("overlay").toggleAttribute("hidden", true);
        return;
      }
      const r = reading.element.getBoundingClientRect();
      if (!r.width || !r.height) {
        $("overlay").toggleAttribute("hidden", true);
        return;
      }
      const { from, to } = arrowPoints(result.best, reading.flipped);
      const dx = to.x - from.x, dy = to.y - from.y, length = Math.hypot(dx, dy);
      const end = { x: to.x - dx / length * 3, y: to.y - dy / length * 3 };
      const arrow = $("arrow");
      for (const [key, value] of Object.entries({ x1: from.x, y1: from.y, x2: end.x, y2: end.y })) {
        arrow.setAttribute(key, value);
      }
      $("overlay").style.cssText = `left:${r.left}px;top:${r.top}px;width:${r.width}px;height:${r.height}px`;
      $("overlay").toggleAttribute("hidden", false);
    }
    function miniBoard() {
      if (!position) {
        $("mini").replaceChildren();
        return;
      }
      const board = new Chess(position.fen), frag = document.createDocumentFragment();
      const files = reading.flipped ? "hgfedcba" : "abcdefgh";
      for (let row = 0; row < 8; row++) {
        for (let col = 0; col < 8; col++) {
          const square = files[col] + (reading.flipped ? row + 1 : 8 - row), piece = board.get(square);
          const cell = document.createElement("div");
          if ((row + col) % 2) cell.className = "dark";
          if (piece) cell.innerHTML = getPieceSvg(piece.color, piece.type);
          cell.title = square;
          frag.appendChild(cell);
        }
      }
      $("mini").replaceChildren(frag);
    }
    function show(evaluation) {
      result = evaluation;
      const label = scoreLabel(result);
      text("leader", label.title);
      text("score", label.score);
      text("status", `\u0645\u062A\u0635\u0644 \u0628\u0640 ${reading.type} \xB7 \u062F\u0648\u0631 ${position.fen.split(" ")[1] === "w" ? "\u0627\u0644\u0623\u0628\u064A\u0636" : "\u0627\u0644\u0623\u0633\u0648\u062F"}`);
      text("best", result.bestSan ? `\u0623\u0641\u0636\u0644 \u0646\u0642\u0644\u0629: ${result.bestSan}` : "\u0627\u0646\u062A\u0647\u062A \u0647\u0630\u0647 \u0627\u0644\u0648\u0636\u0639\u064A\u0629");
      text("meta", `${position.source} \xB7 \u0627\u0644\u0639\u0645\u0642 ${result.depth}`);
      renderArrow();
      let warned = false;
      if (prevPosition && prevResult && prevPosition.fen !== position.fen) {
        const prevBoard = new Chess(prevPosition.fen);
        const mover = prevBoard.turn();
        const prevCp = prevResult.cpWhite ?? 0;
        const currentCp = evaluation.cpWhite ?? 0;
        const dropCp = mover === "w" ? prevCp - currentCp : currentCp - prevCp;
        let playedUci = null;
        for (const m of prevBoard.moves({ verbose: true })) {
          const testBoard = new Chess(prevPosition.fen);
          testBoard.move(m);
          if (testBoard.fen().split(" ")[0] === position.fen.split(" ")[0]) {
            playedUci = m.from + m.to + (m.promotion || "");
            break;
          }
        }
        if (playedUci && dropCp >= 120) {
          const mistakeWarning = explainMistake({
            fenBefore: prevPosition.fen,
            playedUci,
            bestUci: prevResult.best,
            dropCp,
            fenAfter: position.fen
          });
          setCoachAdvice(mistakeWarning, true);
          warned = true;
        }
      }
      if (!warned) {
        const explanation = explainBestMove({
          fen: position.fen,
          bestUci: result.best,
          score: result.cpWhite,
          depth: result.depth
        });
        setCoachAdvice(explanation, false);
      }
      prevPosition = position;
      prevResult = evaluation;
    }
    async function analyze(force = false) {
      if (location.href !== url) {
        url = location.href;
        tracker.reset();
        lastKey = "";
        position = null;
        prevPosition = null;
        prevResult = null;
      }
      if (!enabled || paused) return;
      let detected;
      try {
        detected = detectBoard();
      } catch {
        return;
      }
      if (!detected) {
        $("overlay").toggleAttribute("hidden", true);
        if (reading && !reading.element.isConnected) {
          version++;
          reading = position = null;
          lastKey = "";
          clear("\u0628\u0627\u0646\u062A\u0638\u0627\u0631 \u0627\u0644\u0631\u0642\u0639\u0629", "\u0644\u0645 \u0623\u062C\u062F \u0631\u0642\u0639\u0629 \u0645\u062A\u0648\u0627\u0641\u0642\u0629 \u0641\u064A \u0647\u0630\u0647 \u0627\u0644\u0635\u0641\u062D\u0629.");
          miniBoard();
        }
        return;
      }
      const orientationChanged = reading?.flipped !== detected.flipped;
      reading = detected;
      let resolved;
      try {
        resolved = tracker.resolve(reading);
      } catch {
        return;
      }
      if (!resolved) {
        version++;
        lastKey = "";
        position = null;
        clear("\u0623\u062D\u062A\u0627\u062C \u0627\u0644\u062F\u0648\u0631 \u0648\u0633\u062C\u0644 \u0627\u0644\u0646\u0642\u0644\u0627\u062A", "\u062A\u0645 \u0631\u0635\u062F \u0627\u0644\u0642\u0637\u0639\u061B \u0623\u062F\u062E\u0644 FEN \u0643\u0627\u0645\u0644\u064B\u0627 \u0623\u0648 \u0627\u0641\u062A\u062D \u0633\u062C\u0644 \u0627\u0644\u0645\u0628\u0627\u0631\u0627\u0629.");
        miniBoard();
        return;
      }
      position = resolved;
      const key = position.fen + "|" + depth;
      if (!force && key === lastKey) {
        if (orientationChanged) miniBoard();
        if (result) show(result);
        else renderArrow();
        return;
      }
      lastKey = key;
      const current = ++version;
      clear("\u062C\u0627\u0631\u064D \u0627\u0644\u062A\u0642\u064A\u064A\u0645\u2026", `\u062A\u0645 \u0627\u0644\u062A\u0642\u0627\u0637 \u0627\u0644\u0648\u0636\u0639\u064A\u0629 \xB7 ${reading.type}`);
      miniBoard();
      text("error", "");
      $("fen").placeholder = position.fen;
      if (cache.has(key)) {
        show(cache.get(key));
        return;
      }
      try {
        const evaluation = await chrome.runtime.sendMessage({
          type: "CI_ANALYZE",
          fen: position.fen,
          position: position.position,
          requestId: current
        });
        if (current !== version || paused || !enabled) return;
        if (evaluation?.stale) {
          lastKey = "";
          return;
        }
        if (!evaluation || evaluation.error) throw new Error(evaluation?.error || "\u0644\u0645 \u064A\u0635\u0644 \u0631\u062F \u0645\u0646 \u0627\u0644\u0645\u062D\u0631\u0643.");
        if (evaluation.best) {
          new Chess(position.fen).move({
            from: evaluation.best.slice(0, 2),
            to: evaluation.best.slice(2, 4),
            promotion: evaluation.best[4]
          });
        }
        cache.set(key, evaluation);
        if (cache.size > 100) cache.delete(cache.keys().next().value);
        show(evaluation);
      } catch (e) {
        if (current === version) {
          clear("\u062A\u0639\u0630\u0631 \u0627\u0644\u062A\u062D\u0644\u064A\u0644", e.message);
          lastKey = "";
        }
      }
    }
    function schedule() {
      clearTimeout(timer);
      timer = setTimeout(() => analyze(), 220);
    }
    const observer = new MutationObserver((records) => {
      if (records.some((r) => r.target !== host && !host.contains(r.target))) schedule();
    });
    observer.observe(document.documentElement, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ["class", "style", "data-fen", "data-orientation"],
      characterData: true
    });
    setInterval(() => analyze(), 900);
    addEventListener("resize", renderArrow);
    addEventListener("scroll", renderArrow, true);
    $("coach-voice-btn").addEventListener("click", () => {
      const isMuted = isCoachMuted();
      setCoachMuted(!isMuted);
      $("coach-voice-btn").textContent = !isMuted ? "\u{1F507}" : "\u{1F50A}";
      $("coach-voice-btn").title = !isMuted ? "\u0627\u0644\u0635\u0648\u062A \u0645\u0643\u062A\u0648\u0645 (\u0627\u0636\u063A\u0637 \u0644\u0644\u062A\u0634\u063A\u064A\u0644)" : "\u0627\u0644\u0635\u0648\u062A \u0645\u0641\u0639\u0651\u0644 (\u0627\u0636\u063A\u0637 \u0644\u0644\u0643\u062A\u0645)";
    });
    $("coach-replay-btn").addEventListener("click", () => {
      if (lastCoachedSpeech) speakArabic(lastCoachedSpeech);
    });
    $("coach-avatar").addEventListener("click", () => {
      if (lastCoachedSpeech) speakArabic(lastCoachedSpeech);
    });
    $("arrow").addEventListener("mouseenter", () => {
      if (result?.best) {
        const explanation = explainBestMove({
          fen: position.fen,
          bestUci: result.best,
          score: result.cpWhite,
          depth: result.depth
        });
        setCoachAdvice(explanation, false);
      }
    });
    $("pause").addEventListener("click", () => {
      paused = !paused;
      version++;
      lastKey = "";
      text("pause", paused ? "\u0627\u0633\u062A\u0626\u0646\u0627\u0641" : "\u0625\u064A\u0642\u0627\u0641 \u0645\u0624\u0642\u062A");
      if (paused) clear("\u0627\u0644\u062A\u062D\u0644\u064A\u0644 \u0645\u062A\u0648\u0642\u0641", "\u0627\u0636\u063A\u0637 \u0627\u0633\u062A\u0626\u0646\u0627\u0641 \u0644\u0625\u0639\u0627\u062F\u0629 \u0642\u0631\u0627\u0621\u0629 \u0627\u0644\u0631\u0642\u0639\u0629.");
      else analyze(true);
    });
    $("apply").addEventListener("click", () => {
      try {
        if (!reading) throw new Error("\u0644\u0645 \u064A\u062A\u0645 \u0627\u0644\u0639\u062B\u0648\u0631 \u0639\u0644\u0649 \u0631\u0642\u0639\u0629.");
        position = tracker.resolve(reading, $("fen").value.trim());
        lastKey = "";
        text("error", "");
        analyze(true);
      } catch (e) {
        text("error", e.message || "FEN \u063A\u064A\u0631 \u0635\u0627\u0644\u062D.");
      }
    });
    $("copy").addEventListener("click", async () => {
      try {
        if (!position) throw new Error("\u0627\u0646\u062A\u0638\u0631 \u0627\u0644\u062A\u0642\u0627\u0637 \u0648\u0636\u0639\u064A\u0629 \u0643\u0627\u0645\u0644\u0629.");
        await navigator.clipboard.writeText(position.fen);
        text("error", "\u062A\u0645 \u0646\u0633\u062E FEN.");
      } catch (e) {
        text("error", e.message);
      }
    });
    $("open").addEventListener("click", () => {
      if (!position) {
        text("error", "\u0627\u0646\u062A\u0638\u0631 \u0627\u0644\u062A\u0642\u0627\u0637 \u0648\u0636\u0639\u064A\u0629 \u0643\u0627\u0645\u0644\u0629.");
        return;
      }
      window.open("https://nour-hamada.github.io/chess-insight/#fen=" + encodeURIComponent(position.fen), "_blank", "noopener");
    });
    let drag;
    shadow.querySelector("header").addEventListener("pointerdown", (e) => {
      if (e.target.closest("button")) return;
      const r = $("card").getBoundingClientRect();
      drag = { x: e.clientX - r.left, y: e.clientY - r.top };
      e.currentTarget.setPointerCapture(e.pointerId);
    });
    shadow.querySelector("header").addEventListener("pointermove", (e) => {
      if (!drag) return;
      const card = $("card");
      card.style.right = card.style.bottom = "auto";
      card.style.left = Math.max(0, Math.min(innerWidth - card.offsetWidth, e.clientX - drag.x)) + "px";
      card.style.top = Math.max(0, Math.min(innerHeight - 48, e.clientY - drag.y)) + "px";
    });
    shadow.querySelector("header").addEventListener("pointerup", () => {
      drag = null;
    });
    async function settings() {
      const values = await chrome.storage.local.get({ enabled: true, depth: 14, voiceEnabled: true });
      enabled = values.enabled;
      depth = Number(values.depth);
      setCoachMuted(!values.voiceEnabled);
      $("coach-voice-btn").textContent = values.voiceEnabled ? "\u{1F50A}" : "\u{1F507}";
      version++;
      lastKey = "";
      if (enabled) analyze(true);
      else clear("\u0627\u0644\u062A\u062D\u0644\u064A\u0644 \u0645\u062A\u0648\u0642\u0641", "\u0641\u0639\u0651\u0644 \u0627\u0644\u0625\u0636\u0627\u0641\u0629 \u0645\u0646 \u0623\u064A\u0642\u0648\u0646\u062A\u0647\u0627 \u0641\u064A \u0634\u0631\u064A\u0637 \u0643\u0631\u0648\u0645.");
    }
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && (changes.enabled || changes.depth || changes.voiceEnabled)) settings();
    });
    chrome.runtime.onMessage.addListener((message, _sender, respond) => {
      if (message?.type === "CI_STATUS") {
        respond({ found: !!reading, needsPosition: !!reading && !position, fen: position?.fen, paused, enabled });
        return false;
      }
      if (message?.type === "CI_RESUME") {
        paused = false;
        text("pause", "\u0625\u064A\u0642\u0627\u0641 \u0645\u0624\u0642\u062A");
        settings();
        respond({ ok: true });
      }
      return false;
    });
    settings();
  }
})();
/*! Bundled license information:

chess.js/dist/esm/chess.js:
  (**
   * @license
   * Copyright (c) 2025, Jeff Hlywa (jhlywa@gmail.com)
   * All rights reserved.
   *
   * Redistribution and use in source and binary forms, with or without
   * modification, are permitted provided that the following conditions are met:
   *
   * 1. Redistributions of source code must retain the above copyright notice,
   *    this list of conditions and the following disclaimer.
   * 2. Redistributions in binary form must reproduce the above copyright notice,
   *    this list of conditions and the following disclaimer in the documentation
   *    and/or other materials provided with the distribution.
   *
   * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
   * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
   * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
   * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
   * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
   * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
   * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
   * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
   * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
   * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
   * POSSIBILITY OF SUCH DAMAGE.
   *)
*/
