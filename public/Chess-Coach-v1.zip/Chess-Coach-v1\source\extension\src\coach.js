import { Chess } from 'chess.js';

export const PIECE_NAMES = {
  p: 'البيدق',
  n: 'الحصان',
  b: 'الفيل',
  r: 'الرخ',
  q: 'الوزير',
  k: 'الملك'
};

const PIECE_VALUES = {
  p: 100,
  n: 320,
  b: 330,
  r: 500,
  q: 900,
  k: 20000
};

const FILE_AR = {
  a: 'إيه',
  b: 'بي',
  c: 'سي',
  d: 'دي',
  e: 'إي',
  f: 'إف',
  g: 'جي',
  h: 'إتش'
};

const RANK_AR = {
  '1': 'واحد',
  '2': 'اثنين',
  '3': 'ثلاثة',
  '4': 'أربعة',
  '5': 'خمسة',
  '6': 'ستة',
  '7': 'سبعة',
  '8': 'ثمانية'
};

export function squareToSpeech(sq) {
  if (!sq || sq.length < 2) return sq;
  const f = FILE_AR[sq[0].toLowerCase()] || sq[0];
  const r = RANK_AR[sq[1]] || sq[1];
  return f + ' ' + r;
}

// Convert squares, pieces, and notations into natural spoken Arabic words
export function formatSpeechText(text) {
  if (!text) return '';
  return text
    // Replace coordinate pairs like f7, e4, c7, d5 with spoken names
    .replace(/\b([a-hA-H])([1-8])\b/g, (_m, f, r) => squareToSpeech(f + r))
    // Strip markdown formatting and emojis
    .replace(/[*_~`#]/g, '')
    .replace(/[🏆👑💎⚔️🏰🛡️⚡🔱🎯⭐✨⚠️💡♟️]/g, '')
    .replace(/[()]/g, ' ')
    // Replace multiple spaces
    .replace(/\s+/g, ' ')
    .trim();
}

// Check if a piece can be captured for free or profit
function getExchangeGain(board, square, depth = 0) {
  if (depth >= 8) return 0;
  let best = 0;
  for (const move of board.moves({ verbose: true })) {
    if (move.to !== square || !move.captured) continue;
    const gain = PIECE_VALUES[move.captured] || 0;
    const boardCopy = new Chess(board.fen());
    boardCopy.move({ from: move.from, to: move.to, promotion: move.promotion });
    best = Math.max(best, gain - getExchangeGain(boardCopy, square, depth + 1));
  }
  return best;
}

function getDirectAttackers(board, square, byColor) {
  const attackers = [];
  for (const move of board.moves({ verbose: true })) {
    if (move.to === square && move.color === byColor) {
      attackers.push(move);
    }
  }
  return attackers;
}

// Identify active threats by the opponent in the pre-move position
export function detectOpponentThreats(board, ourColor) {
  const oppColor = ourColor === 'w' ? 'b' : 'w';
  const threats = [];

  // Check 1: Does opponent threaten immediate checkmate?
  // We simulate opponent having a move right now
  const oppTurnFen = board.fen().split(' ');
  oppTurnFen[1] = oppColor;
  oppTurnFen[3] = '-';
  try {
    const oppBoard = new Chess(oppTurnFen.join(' '));
    for (const m of oppBoard.moves({ verbose: true })) {
      const sim = new Chess(oppBoard.fen());
      sim.move(m);
      if (sim.isCheckmate()) {
        threats.push({
          type: 'mate',
          square: m.to,
          san: m.san,
          desc: `الخصم يهدد بكش مات مباشر على ${m.to}`
        });
        break;
      }
    }
  } catch {}

  // Check 2: Are any of our pieces under profitable attack right now?
  for (const row of board.board()) {
    for (const cell of row) {
      if (!cell || cell.color !== ourColor || cell.type === 'k') continue;
      const attackers = getDirectAttackers(board, cell.square, oppColor);
      if (attackers.length > 0) {
        const gain = getExchangeGain(board, cell.square);
        if (gain >= 120 || cell.type === 'q') {
          const pieceName = PIECE_NAMES[cell.type] || 'قطعتك';
          const attackerName = PIECE_NAMES[attackers[0].piece] || 'قطعة الخصم';
          threats.push({
            type: 'hanging',
            piece: cell.type,
            square: cell.square,
            attacker: attackers[0].piece,
            desc: `الخصم يهدد بأخذ ${pieceName} على ${cell.square} بـ${attackerName}`
          });
        }
      }
    }
  }

  return threats;
}

// Recognize chess openings in Arabic
export function identifyOpening(board) {
  const p = (sq) => {
    const pc = board.get(sq);
    return pc ? (pc.color === 'w' ? pc.type.toUpperCase() : pc.type.toLowerCase()) : '';
  };

  // 1. Sicilian Defense: e4 c5
  if (p('c5') === 'p' && (p('e4') === 'P' || p('d4') === 'P' || p('f3') === 'N')) {
    return { name: 'الدفاع الصقلي', idea: 'مواجهة سيطرة الأبيض على الوسط بهجوم مضاد ديناميكي من الجناح' };
  }
  // 2. Italian Game: e4 e5, Nf3 Nc6, Bc4
  if (p('c4') === 'B' && p('f3') === 'N' && (p('c6') === 'n' || p('f6') === 'n') && p('e4') === 'P' && p('e5') === 'p') {
    return { name: 'الافتتاح الإيطالي', idea: 'الضغط المباشر على نقطة ضعف الأسود في إف سبعة والانتشار السريع' };
  }
  // 3. Ruy Lopez / Spanish: e4 e5, Nf3 Nc6, Bb5
  if (p('b5') === 'B' && p('f3') === 'N' && p('c6') === 'n' && p('e4') === 'P' && p('e5') === 'p') {
    return { name: 'الافتتاح الإسباني (روي لوبيز)', idea: 'تثبيت الحصان المدافع عن بيدق إي خمسة وبناء ضغط طويل الأمد' };
  }
  // 4. French Defense: e4 e6
  if (p('e6') === 'p' && (p('d5') === 'p' || p('d4') === 'P')) {
    return { name: 'الدفاع الفرنسي', idea: 'بناء سلسلة بيادق دفاعية صلبة تمهيداً لكسر المركز' };
  }
  // 5. Caro-Kann Defense: e4 c6
  if (p('c6') === 'p' && (p('d5') === 'p' || p('d4') === 'P')) {
    return { name: 'دفاع الكاروكان', idea: 'تحصين القاعدة البيدقية ودعم تقدم البيدق إلى دي خمسة بأمان' };
  }
  // 6. Queen's Gambit: d4 d5, c4
  if (p('d4') === 'P' && p('d5') === 'p' && p('c4') === 'P') {
    return { name: 'غامبت الوزير', idea: 'التضحية بجناح الوزير للسيطرة الكاملة على مربعات الوسط' };
  }
  // 7. Slav Defense: d4 d5, c4 c6
  if (p('d4') === 'P' && p('d5') === 'p' && p('c6') === 'p') {
    return { name: 'الدفاع السلافي', idea: 'دعم البيدق المركزي دون إغلاق مسار الفيل الأبيض' };
  }
  // 8. King's Indian Defense: d4 Nf6, c4 g6
  if (p('f6') === 'n' && (p('g6') === 'p' || p('g7') === 'b') && p('d4') === 'P') {
    return { name: 'الدفاع الهندي للملك', idea: 'تطوير الفيل على الوتر الطويل والتحضير لهجوم عنيف على جناح الملك' };
  }
  // 9. Scandinavian Defense: e4 d5
  if (p('d5') === 'p' && p('e4') === 'P' && !p('e5')) {
    return { name: 'الدفاع الإسكندنافي', idea: 'تحدٍ مباشر لمركز الأبيض منذ النقلة الأولى' };
  }
  // 10. Petrov's Defense: e4 e5, Nf3 Nf6
  if (p('f3') === 'N' && p('f6') === 'n' && p('e4') === 'P' && p('e5') === 'p') {
    return { name: 'دفاع بيتروف (الدفاع الروسي)', idea: 'هجوم مضاد مباشر على بيدق إي أربعة وتوازن متكافئ' };
  }
  // 11. Nimzo-Indian Defense: d4 Nf6, c4 e6, Nc3 Bb4
  if (p('b4') === 'b' && p('c3') === 'N' && p('f6') === 'n' && p('d4') === 'P') {
    return { name: 'دفاع نيمزو-هندي', idea: 'ربط حصان الأبيض وشل حركته لمنع سيطرته على مربع إي أربعة' };
  }
  // 12. English Opening: c4
  if (p('c4') === 'P' && !p('e4') && !p('d4')) {
    return { name: 'الافتتاح الإنجليزي', idea: 'السيطرة على مربع دي خمسة من الجناح وبناء هيكل مرن' };
  }

  return null;
}

// Deep, logical, multi-faceted explanation for the best move
export function explainBestMove({ fen, bestUci, score, depth }) {
  if (!fen || !bestUci) {
    return {
      text: 'بانتظار تحليل الوضعية لاقتراح أفضل نقلة وشرح أسبابها التكتيكية.',
      voice: 'بانتظار تحليل الوضعية لاقتراح أفضل نقلة.',
      motif: 'wait',
      icon: '⏳'
    };
  }

  let board;
  try { board = new Chess(fen); } catch { return fallbackExplain(); }
  const from = bestUci.slice(0, 2);
  const to = bestUci.slice(2, 4);
  const promotion = bestUci[4];
  const piece = board.get(from);
  if (!piece) return fallbackExplain();

  const moverColor = piece.color;
  const oppColor = moverColor === 'w' ? 'b' : 'w';
  const moverName = PIECE_NAMES[piece.type] || 'القطعة';

  // 1. Detect any active threats opponent was making BEFORE our move
  const opponentThreats = detectOpponentThreats(board, moverColor);

  let moveResult;
  try {
    moveResult = board.move({ from, to, promotion });
  } catch {
    return fallbackExplain();
  }
  if (!moveResult) return fallbackExplain();

  // 2. CHECKMATE
  if (board.isCheckmate()) {
    const text = '🏆 أحسنت! كش مات حاسم! هذه النقلة تنهي المباراة فوراً بفوز مستحق ولا مفر منها!';
    return {
      text,
      voice: formatSpeechText('أحسنت! كش مات حاسم! هذه النقلة تنهي المباراة فوراً بفوز مستحق ولا مفر منها!'),
      motif: 'mate',
      icon: '🏆'
    };
  }

  // 3. DEFENDING AGAINST CRITICAL OPPONENT THREATS (انتبه!)
  if (opponentThreats.length > 0) {
    const primaryThreat = opponentThreats[0];
    if (primaryThreat.type === 'mate') {
      const text = `🛡️ انتبه! الخصم كان يهدد بكش مات مباشر؛ أحسنت بهذه النقلة لأنها تغلق مسار الهجوم وتؤمن الملك تماماً!`;
      return {
        text,
        voice: formatSpeechText(`انتبه! الخصم كان يهدد بكش مات مباشر؛ أحسنت بهذه النقلة لأنها تغلق مسار الهجوم وتؤمن الملك تماماً!`),
        motif: 'defend_mate',
        icon: '🛡️'
      };
    }
    if (primaryThreat.type === 'hanging') {
      const targetPieceName = PIECE_NAMES[primaryThreat.piece] || 'قطعتك';
      if (from === primaryThreat.square) {
        const text = `🛡️ انتبه! الخصم كان يهدد بأخذ ${targetPieceName} على ${from}؛ أحسنت بالهروب بـ${moverName} إلى مربع آمن على ${to}!`;
        return {
          text,
          voice: formatSpeechText(`انتبه! الخصم كان يهدد بأخذ ${targetPieceName} على ${from}؛ أحسنت بالهروب بـ${moverName} إلى مربع آمن على ${to}!`),
          motif: 'escape',
          icon: '🛡️'
        };
      }
      // Or defending it
      const text = `🛡️ انتبه! الخصم يضغط على ${targetPieceName}؛ أحسنت بهذه النقلة لأنها تدعم حمايتها وتبطل تهديد الخصم!`;
      return {
        text,
        voice: formatSpeechText(`انتبه! الخصم يضغط على ${targetPieceName}؛ أحسنت بهذه النقلة لأنها تدعم حمايتها وتبطل تهديد الخصم!`),
        motif: 'protect',
        icon: '🛡️'
      };
    }
  }

  // 4. CAPTURES & TACTICAL GAINS
  if (moveResult.captured) {
    const capName = PIECE_NAMES[moveResult.captured] || 'قطعة';
    const capVal = PIECE_VALUES[moveResult.captured] || 0;
    const moverVal = PIECE_VALUES[piece.type] || 0;

    if (moveResult.captured === 'q') {
      const text = '👑 أحسنت! أسر الوزير! هذه النقلة تسقط أقوى قطع الخصم وتمنحك تفوقاً حاسماً على الرقعة!';
      return {
        text,
        voice: formatSpeechText('أحسنت! أسر الوزير! هذه النقلة تسقط أقوى قطع الخصم وتمنحك تفوقاً حاسماً على الرقعة!'),
        motif: 'queen_capture',
        icon: '👑'
      };
    }
    if (capVal > moverVal) {
      const text = `💎 أحسنت! مكسب مادي كبير! أخذت ${capName} بـ${moverName} لتحقق فارقاً تكتيكياً ثميناً لصالحك!`;
      return {
        text,
        voice: formatSpeechText(`أحسنت! مكسب مادي كبير! أخذت ${capName} بـ${moverName} لتحقق فارقاً تكتيكياً ثميناً لصالحك!`),
        motif: 'favorable_exchange',
        icon: '💎'
      };
    }
    const text = `⚔️ أحسنت! أخذت ${capName} على ${to}؛ نقلة تكتيكية موفقة تكسب مادة وتزيد من تفوقك!`;
    return {
      text,
      voice: formatSpeechText(`أحسنت! أخذت ${capName} على ${to}؛ نقلة تكتيكية موفقة تكسب مادة وتزيد من تفوقك!`),
      motif: 'piece_capture',
      icon: '⚔️'
    };
  }

  // 5. CASTLING
  if (moveResult.san === 'O-O' || moveResult.san === 'O-O-O') {
    const text = '🏰 أحسنت! تأمين الملك بالتبييت! نقلة أساسية تضع الملك في أمان تام وتصل الرخين ببعضهما لبدء الهجوم المركزي.';
    return {
      text,
      voice: formatSpeechText('أحسنت! تأمين الملك بالتبييت! نقلة أساسية تضع الملك في أمان تام وتصل الرخين ببعضهما لبدء الهجوم المركزي.'),
      motif: 'castling',
      icon: '🏰'
    };
  }

  // 6. CHECK WITH INITIATIVE
  if (board.isCheck()) {
    const text = `⚡ أحسنت! كش هجومي! تباغت ملك الخصم وتجبره على التراجع أو خسارة حق التبييت!`;
    return {
      text,
      voice: formatSpeechText(`أحسنت! كش هجومي! تباغت ملك الخصم وتجبره على التراجع أو خسارة حق التبييت!`),
      motif: 'check',
      icon: '⚡'
    };
  }

  // 7. OPENING STAGE: IDENTIFY OPENING AND SPECIFIC PURPOSE
  const opening = identifyOpening(board);
  const isEarly = board.history().length <= 16;
  if (isEarly && opening) {
    if (piece.type === 'b') {
      if (to === 'c4') {
        const text = `🎯 أحسنت! نحن في **${opening.name}**؛ نشر الفيل إلى سي أربعة يضغط مباشرة على نقطة ضعف الأسود في إف سبعة!`;
        return { text, voice: formatSpeechText(`أحسنت! نحن في ${opening.name}؛ نشر الفيل إلى سي أربعة يضغط مباشرة على نقطة ضعف الأسود في إف سبعة!`), motif: 'opening', icon: '🎯' };
      }
      if (to === 'b5') {
        const text = `🎯 أحسنت! نحن في **${opening.name}**؛ وضع الفيل على بي خمسة يربط حصان الخصم ويقوض سيطرته على مربعات الوسط!`;
        return { text, voice: formatSpeechText(`أحسنت! نحن في ${opening.name}؛ وضع الفيل على بي خمسة يربط حصان الخصم ويقوض سيطرته على مربعات الوسط!`), motif: 'opening', icon: '🎯' };
      }
      if (to === 'g5' || to === 'g4') {
        const text = `🎯 أحسنت! نحن في **${opening.name}**؛ نشر الفيل إلى ${to} يربط الحصان بالوزير ويشل حركة قطعة الخصم الرئيسية!`;
        return { text, voice: formatSpeechText(`أحسنت! نحن في ${opening.name}؛ نشر الفيل إلى ${to} يربط الحصان بالوزير ويشل حركة قطعة الخصم الرئيسية!`), motif: 'opening', icon: '🎯' };
      }
      if (to === 'e7' || to === 'e2' || to === 'd3' || to === 'd2') {
        const text = `🎯 أحسنت! نحن في **${opening.name}**؛ نقلة تطويرية ممتازة للفيل تفك القيود وتمهد للتبييت السريع للملك!`;
        return { text, voice: formatSpeechText(`أحسنت! نحن في ${opening.name}؛ نقلة تطويرية ممتازة للفيل تفك القيود وتمهد للتبييت السريع للملك!`), motif: 'opening', icon: '🎯' };
      }
    }
    if (piece.type === 'n') {
      if (['f3', 'c3', 'f6', 'c6'].includes(to)) {
        const text = `🎯 أحسنت! نحن في **${opening.name}**؛ خروج الحصان إلى ${to} يسيطر على مربعات المركز ويسرع انتشار الجيش.`;
        return { text, voice: formatSpeechText(`أحسنت! نحن في ${opening.name}؛ خروج الحصان إلى ${to} يسيطر على مربعات المركز ويسرع انتشار الجيش.`), motif: 'opening', icon: '🎯' };
      }
    }
    if (piece.type === 'p') {
      const text = `🎯 أحسنت! نحن في **${opening.name}**؛ تقدم البيدق إلى ${to} يخدم خطة: ${opening.idea}.`;
      return { text, voice: formatSpeechText(`أحسنت! نحن في ${opening.name}؛ تقدم البيدق إلى ${to} يخدم خطة ${opening.idea}.`), motif: 'opening', icon: '🎯' };
    }
  }

  // 8. TACTICAL FORK OR DOUBLE ATTACK
  const attacksOnOpp = [];
  for (const cand of board.moves({ verbose: true })) {
    if (cand.from === to && cand.captured && ['q', 'r', 'b', 'n'].includes(cand.captured)) {
      attacksOnOpp.push(cand.captured);
    }
  }
  if (attacksOnOpp.length >= 2) {
    const p1 = PIECE_NAMES[attacksOnOpp[0]];
    const p2 = PIECE_NAMES[attacksOnOpp[1]];
    const text = `🔱 أحسنت! شوكة تكتيكية مزدوجة (Fork)! تهاجم ${p1} و${p2} معاً في نفس النقلة وتجبر الخصم على خسارة أحدهما!`;
    return {
      text,
      voice: formatSpeechText(`أحسنت! شوكة تكتيكية مزدوجة! تهاجم ${p1} و${p2} معاً في نفس النقلة وتجبر الخصم على خسارة أحدهما!`),
      motif: 'fork',
      icon: '🔱'
    };
  }
  if (attacksOnOpp.length === 1) {
    const targetName = PIECE_NAMES[attacksOnOpp[0]];
    const text = `🎯 أحسنت! هجوم مباشر! تضع ${moverName} على ${to} مهدداً بأسر ${targetName} في النقلة التالية!`;
    return {
      text,
      voice: formatSpeechText(`أحسنت! هجوم مباشر! تضع ${moverName} على ${to} مهدداً بأسر ${targetName} في النقلة التالية!`),
      motif: 'threat',
      icon: '🎯'
    };
  }

  // 9. ROOK ON OPEN FILE
  if (piece.type === 'r' && ['d1', 'e1', 'c1', 'f1', 'd8', 'e8', 'c8', 'f8'].includes(to)) {
    const text = `🚀 أحسنت! السيطرة على العمود المفتوح! تضع الرخ في ممر استراتيجي للضغط على معسكر الخصم والتسلل للصفوف الخلفية.`;
    return {
      text,
      voice: formatSpeechText(`أحسنت! السيطرة على العمود المفتوح! تضع الرخ في ممر استراتيجي للضغط على معسكر الخصم والتسلل للصفوف الخلفية.`),
      motif: 'open_file',
      icon: '🚀'
    };
  }

  // 10. CENTRAL CONTROL & OUTPOST
  if (['e4', 'd4', 'e5', 'd5', 'c4', 'f4', 'c5', 'f5'].includes(to)) {
    const text = `⭐ أحسنت! السيطرة على الوسط! هذه النقلة تفرض نفوذ ${moverName} على مربعات المركز وتمنحك أفضلية مساحية واضحة.`;
    return {
      text,
      voice: formatSpeechText(`أحسنت! السيطرة على الوسط! هذه النقلة تفرض نفوذ ${moverName} على مربعات المركز وتمنحك أفضلية مساحية واضحة.`),
      motif: 'center',
      icon: '⭐'
    };
  }

  // 11. POSITIONAL REORGANIZATION / REGROUPING
  const text = `✨ أحسنت! مناورة تكتيكية دقيقة! نقل ${moverName} إلى ${to} ينسق دفاعاتك ويزيد من فعالية قطعك في المعركة.`;
  return {
    text,
    voice: formatSpeechText(`أحسنت! مناورة تكتيكية دقيقة! نقل ${moverName} إلى ${to} ينسق دفاعاتك ويزيد من فعالية قطعك في المعركة.`),
    motif: 'develop',
    icon: '✨'
  };
}

function fallbackExplain() {
  return {
    text: 'أحسنت! هذه النقلة هي الأفضل وفقاً لمحرك Stockfish لتعزيز الوضعية وبناء التفوق.',
    voice: 'أحسنت! هذه النقلة هي الأفضل وفقاً لمحرك الشطرنج لتعزيز الوضعية وبناء التفوق.',
    motif: 'engine',
    icon: '💡'
  };
}

// WHEN A MISTAKE OR BLUNDER IS PLAYED:
// Coach uses: "أوتش! هل أنت متأكد من هذه النقلة؟ لأنك نسيت أن [كذا وكذا]"
export function explainMistake({ fenBefore, playedUci, bestUci, dropCp, fenAfter }) {
  let boardBefore, boardAfter;
  try {
    boardBefore = new Chess(fenBefore);
    boardAfter = new Chess(fenAfter);
  } catch {
    return fallbackMistake();
  }

  const to = playedUci.slice(2, 4);
  const moverColor = boardBefore.turn();

  // Check 1: Did we leave our moved piece hanging for free?
  const movedPiece = boardAfter.get(to);
  if (movedPiece) {
    const gainOnMoved = getExchangeGain(boardAfter, to);
    if (gainOnMoved >= 150) {
      const pName = PIECE_NAMES[movedPiece.type] || 'قطعتك';
      const text = `⚠️ أوتش! هل أنت متأكد من هذه النقلة؟ لأنك نسيت أن ${pName} غير محمية على ${to} ويمكن للخصم أخذها مجاناً!`;
      return {
        text,
        voice: formatSpeechText(`أوتش! هل أنت متأكد من هذه النقلة؟ لأنك نسيت أن ${pName} غير محمية على ${to} ويمكن للخصم أخذها مجاناً!`),
        motif: 'hung_moved',
        icon: '⚠️'
      };
    }
  }

  // Check 2: Did we leave another piece hanging?
  for (const row of boardAfter.board()) {
    for (const cell of row) {
      if (!cell || cell.color !== moverColor || cell.type === 'k' || cell.square === to) continue;
      const gain = getExchangeGain(boardAfter, cell.square);
      if (gain >= 120) {
        const pName = PIECE_NAMES[cell.type] || 'قطعتك';
        const text = `⚠️ أوتش! هل أنت متأكد من هذه النقلة؟ لأنك نسيت حماية ${pName} على ${cell.square} وتركتها فريسة سهلة للخصم!`;
        return {
          text,
          voice: formatSpeechText(`أوتش! هل أنت متأكد من هذه النقلة؟ لأنك نسيت حماية ${pName} على ${cell.square} وتركتها فريسة سهلة للخصم!`),
          motif: 'hung_other',
          icon: '⚠️'
        };
      }
    }
  }

  // Check 3: Did opponent gain checkmate or dangerous mating attack?
  if (boardAfter.isCheckmate() || (boardAfter.inCheck() && dropCp >= 350)) {
    const text = `⚠️ أوتش! هل أنت متأكد من هذه النقلة؟ لأنك نسيت تأمين دفاعات ملكك وسمحت للخصم بهجوم كش مات خطير!`;
    return {
      text,
      voice: formatSpeechText(`أوتش! هل أنت متأكد من هذه النقلة؟ لأنك نسيت تأمين دفاعات ملكك وسمحت للخصم بهجوم كش مات خطير!`),
      motif: 'allowed_mate',
      icon: '⚠️'
    };
  }

  // Check 4: What did the best move threaten that we forgot to do?
  if (bestUci) {
    const bestFrom = bestUci.slice(0, 2);
    const bestTo = bestUci.slice(2, 4);
    const targetPiece = boardBefore.get(bestTo);
    if (targetPiece && PIECE_VALUES[targetPiece.type] >= 300) {
      const tName = PIECE_NAMES[targetPiece.type] || 'قطعة الخصم';
      const text = `⚠️ أوتش! هل أنت متأكد من هذه النقلة؟ لأنك نسيت أن تهدد ${tName} على ${bestTo} وتفوت فرصة أسرها كما كان متاحاً!`;
      return {
        text,
        voice: formatSpeechText(`أوتش! هل أنت متأكد من هذه النقلة؟ لأنك نسيت أن تهدد ${tName} على ${bestTo} وتفوت فرصة أسرها كما كان متاحاً!`),
        motif: 'missed_threat',
        icon: '⚠️'
      };
    }
  }

  // Check 5: General tactical regression
  const text = `⚠️ أوتش! هل أنت متأكد من هذه النقلة؟ لأنها تفقدك الأفضلية التكتيكية وتمنح الخصم فرصة قوية للهجوم المضاد!`;
  return {
    text,
    voice: formatSpeechText(`أوتش! هل أنت متأكد من هذه النقلة؟ لأنها تفقدك الأفضلية التكتيكية وتمنح الخصم فرصة قوية للهجوم المضاد!`),
    motif: 'lost_eval',
    icon: '⚠️'
  };
}

function fallbackMistake() {
  const text = '⚠️ أوتش! انتبه، هذه النقلة غير دقيقة وتضعف وضعيتك التكتيكية على الرقعة!';
  return {
    text,
    voice: formatSpeechText('أوتش! انتبه، هذه النقلة غير دقيقة وتضعف وضعيتك التكتيكية على الرقعة!'),
    motif: 'mistake',
    icon: '⚠️'
  };
}

// SPONKEN ARABIC AUDIO SYSTEM
let speechMuted = false;

export function setCoachMuted(muted) {
  speechMuted = Boolean(muted);
  if (speechMuted && typeof window !== 'undefined' && 'speechSynthesis' in window) {
    window.speechSynthesis.cancel();
  }
}

export function isCoachMuted() {
  return speechMuted;
}

export function speakArabic(sentence) {
  if (speechMuted) return;
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;

  try {
    window.speechSynthesis.cancel();
    const cleanSpeech = formatSpeechText(sentence);
    if (!cleanSpeech) return;

    const utterance = new SpeechSynthesisUtterance(cleanSpeech);
    utterance.lang = 'ar-SA';
    utterance.rate = 0.98; // Natural, articulate pace
    utterance.pitch = 1.0;

    const voices = window.speechSynthesis.getVoices();
    // Prioritize natural Arabic voices
    const arVoice = voices.find(v => {
      const l = (v.lang || '').toLowerCase();
      const n = (v.name || '').toLowerCase();
      return l.startsWith('ar') || n.includes('arabic') || n.includes('maged') || n.includes('tarik') || n.includes('shakir') || n.includes('laila') || n.includes('hamed');
    });
    if (arVoice) utterance.voice = arVoice;

    window.speechSynthesis.speak(utterance);
  } catch (err) {
    console.warn('Speech synthesis unavailable:', err);
  }
}
