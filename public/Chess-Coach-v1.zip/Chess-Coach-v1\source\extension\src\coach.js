import { Chess } from 'chess.js';

export const PIECE_NAMES = {
  p: 'البيدق',
  n: 'الحصان',
  b: 'الفيل',
  r: 'الرخ',
  q: 'الوزير',
  k: 'الملك'
};

const PIECE_VALUES = {
  p: 100,
  n: 320,
  b: 330,
  r: 500,
  q: 900,
  k: 20000
};

// Check if a piece on a square can be captured by opponent with net profit
function getExchangeGain(board, square, depth = 0) {
  if (depth >= 8) return 0;
  let best = 0;
  for (const move of board.moves({ verbose: true })) {
    if (move.to !== square || !move.captured) continue;
    const piece = board.get(square);
    const gain = PIECE_VALUES[move.captured] || 0;
    const boardCopy = new Chess(board.fen());
    boardCopy.move({ from: move.from, to: move.to, promotion: move.promotion });
    best = Math.max(best, gain - getExchangeGain(boardCopy, square, depth + 1));
  }
  return best;
}

function isAttackedBy(board, square, byColor) {
  for (const move of board.moves({ verbose: true })) {
    if (move.to === square && move.color === byColor) return true;
  }
  return false;
}

function findHangingPiece(board, color) {
  for (const row of board.board()) {
    for (const cell of row) {
      if (!cell || cell.color !== color || cell.type === 'k') continue;
      const gain = getExchangeGain(board, cell.square);
      if (gain >= 120) {
        return { piece: cell.type, square: cell.square, gain };
      }
    }
  }
  return null;
}

export function explainBestMove({ fen, bestUci, score, depth }) {
  if (!fen || !bestUci) {
    return {
      text: 'بانتظار تحليل الوضعية لاقتراح أفضل نقلة وشرح أسبابها التكتيكية.',
      voice: 'بانتظار تحليل الوضعية لاقتراح أفضل نقلة.',
      motif: 'wait',
      icon: '⏳'
    };
  }

  let board;
  try { board = new Chess(fen); } catch { return fallbackExplain(); }
  const from = bestUci.slice(0, 2);
  const to = bestUci.slice(2, 4);
  const promotion = bestUci[4];
  const piece = board.get(from);
  if (!piece) return fallbackExplain();

  const moverColor = piece.color;
  const oppColor = moverColor === 'w' ? 'b' : 'w';
  const moverName = PIECE_NAMES[piece.type] || 'القطعة';

  // Check if moving piece was under threat before the move
  const wasUnderAttack = isAttackedBy(board, from, oppColor);

  let moveResult;
  try {
    moveResult = board.move({ from, to, promotion });
  } catch {
    return fallbackExplain();
  }
  if (!moveResult) return fallbackExplain();

  // 1. Checkmate
  if (board.isCheckmate()) {
    return {
      text: '🏆 كش مات حاسم! هذه النقلة هي الأفضل لأنها تنهي المباراة فوراً بفوز مستحق!',
      voice: 'كش مات حاسم! هذه النقلة هي الأفضل لأنها تنهي المباراة فوراً بفوز مستحق!',
      motif: 'mate',
      icon: '🏆'
    };
  }

  // 2. Queen capture
  if (moveResult.captured === 'q') {
    return {
      text: '👑 أسر الوزير! هذه النقلة هي الأفضل لأنها تسقط أقوى قطع الخصم وتمنحك تفوقاً حاسماً على الرقعة!',
      voice: 'أسر الوزير! هذه النقلة هي الأفضل لأنها تسقط أقوى قطع الخصم وتمنحك تفوقاً حاسماً على الرقعة!',
      motif: 'queen_capture',
      icon: '👑'
    };
  }

  // 3. Winning higher piece or favorable capture
  if (moveResult.captured) {
    const capName = PIECE_NAMES[moveResult.captured] || 'قطعة';
    const capVal = PIECE_VALUES[moveResult.captured] || 0;
    const moverVal = PIECE_VALUES[piece.type] || 0;
    if (capVal > moverVal) {
      return {
        text: `💎 مكسب مادي كبير! هذه النقلة هي الأفضل لأنها تأخذ ${capName} بـ${moverName} وتحقق تفوقاً تكتيكياً ثميناً!`,
        voice: `مكسب مادي كبير! هذه النقلة هي الأفضل لأنها تأخذ ${capName} بـ${moverName} وتحقق تفوقاً تكتيكياً ثميناً!`,
        motif: 'favorable_exchange',
        icon: '💎'
      };
    }
    return {
      text: `⚔️ أسر قطعة! هذه النقلة هي الأفضل لأنها تأخذ ${capName} وتزيد من الضغط الهجومي على دفاعات الخصم!`,
      voice: `أسر قطعة! هذه النقلة هي الأفضل لأنها تأخذ ${capName} وتزيد من الضغط الهجومي على دفاعات الخصم!`,
      motif: 'piece_capture',
      icon: '⚔️'
    };
  }

  // 4. Castling
  if (moveResult.san === 'O-O' || moveResult.san === 'O-O-O') {
    return {
      text: '🏰 تأمين الملك بالتبييت! هذه النقلة هي الأفضل لحماية الملك وربط الرخين معاً للمشاركة في المعركة!',
      voice: 'تأمين الملك بالتبييت! هذه النقلة هي الأفضل لحماية الملك وربط الرخين معاً للمشاركة في المعركة!',
      motif: 'castling',
      icon: '🏰'
    };
  }

  // 5. Escaping an attack
  if (wasUnderAttack) {
    return {
      text: `🛡️ إنقاذ تكتيكي! هذه النقلة هي الأفضل لأنها تهرب بـ${moverName} من تهديد مباشر إلى مربع ${to} بأمان وقوة!`,
      voice: `إنقاذ تكتيكي! هذه النقلة هي الأفضل لأنها تهرب بـ${moverName} من تهديد مباشر إلى مربع آمن بقوة!`,
      motif: 'escape',
      icon: '🛡️'
    };
  }

  // 6. Check
  if (board.isCheck()) {
    return {
      text: `⚡ كش هجومي! هذه النقلة هي الأفضل لأنها تباغت ملك الخصم وتجبره على فقدان التبييت أو التراجع الدفاعي!`,
      voice: `كش هجومي! هذه النقلة هي الأفضل لأنها تباغت ملك الخصم وتجبره على فقدان التبييت أو التراجع الدفاعي!`,
      motif: 'check',
      icon: '⚡'
    };
  }

  // 7. Tactical Fork threat
  const attackedPieces = [];
  for (const cand of board.moves({ verbose: true })) {
    if (cand.from === to && cand.captured && ['q', 'r', 'b', 'n'].includes(cand.captured)) {
      attackedPieces.push(cand.captured);
    }
  }
  if (attackedPieces.length >= 2) {
    const p1 = PIECE_NAMES[attackedPieces[0]];
    const p2 = PIECE_NAMES[attackedPieces[1]];
    return {
      text: `🔱 شوكة تكتيكية مزدوجة (Fork)! هذه النقلة هي الأفضل لأنها تهاجم ${p1} و${p2} معاً في نفس الوقت!`,
      voice: `شوكة تكتيكية مزدوجة! هذه النقلة هي الأفضل لأنها تهاجم ${p1} و${p2} معاً في نفس الوقت!`,
      motif: 'fork',
      icon: '🔱'
    };
  }
  if (attackedPieces.length === 1) {
    const targetName = PIECE_NAMES[attackedPieces[0]];
    return {
      text: `🎯 هجوم مباشر! هذه النقلة هي الأفضل لأنها تضع ${moverName} مهدداً بأسر ${targetName} في النقلة القادمة!`,
      voice: `هجوم مباشر! هذه النقلة هي الأفضل لأنها تضع ${moverName} مهدداً بأسر ${targetName} في النقلة القادمة!`,
      motif: 'threat',
      icon: '🎯'
    };
  }

  // 8. Dominating the center
  if (['e4', 'd4', 'e5', 'd5', 'c4', 'f4', 'c5', 'f5'].includes(to)) {
    return {
      text: `⭐ السيطرة على الوسط! هذه النقلة هي الأفضل لفرض الهيمنة على مربعات المركز وتوسيع انتشار القطع.`,
      voice: `السيطرة على الوسط! هذه النقلة هي الأفضل لفرض الهيمنة على مربعات المركز وتوسيع انتشار القطع.`,
      motif: 'center',
      icon: '⭐'
    };
  }

  // 9. Strategic development
  return {
    text: `✨ نقلة تكتيكية دقيقة! هذه النقلة هي الأفضل لتحسين موقع ${moverName} وبناء أفضلية تراكمية في الوضعية.`,
    voice: `نقلة تكتيكية دقيقة! هذه النقلة هي الأفضل لتحسين موقع ${moverName} وبناء أفضلية تراكمية في الوضعية.`,
    motif: 'develop',
    icon: '✨'
  };
}

function fallbackExplain() {
  return {
    text: 'هذه النقلة هي الأفضل وفقاً لمحرك Stockfish لتعزيز الوضعية وتحقيق التفوق.',
    voice: 'هذه النقلة هي الأفضل وفقاً لمحرك الشطرنج لتعزيز الوضعية وتحقيق التفوق.',
    motif: 'engine',
    icon: '💡'
  };
}

// When a bad move is played, explain WHY it's a mistake and what was forgotten/overlooked
export function explainMistake({ fenBefore, playedUci, bestUci, dropCp, fenAfter }) {
  let boardBefore, boardAfter;
  try {
    boardBefore = new Chess(fenBefore);
    boardAfter = new Chess(fenAfter);
  } catch {
    return fallbackMistake();
  }

  const from = playedUci.slice(0, 2);
  const to = playedUci.slice(2, 4);
  const moverColor = boardBefore.turn();
  const oppColor = moverColor === 'w' ? 'b' : 'w';

  // Check 1: Did we leave our moved piece hanging for free?
  const movedPiece = boardAfter.get(to);
  if (movedPiece) {
    const gainOnMoved = getExchangeGain(boardAfter, to);
    if (gainOnMoved >= 150) {
      const pName = PIECE_NAMES[movedPiece.type] || 'قطعتك';
      return {
        text: `⚠️ هل أنت متأكد من هذه النقلة؟ لأنك نسيت أن ${pName} غير محمية على ${to} ويمكن للخصم أخذها مجاناً!`,
        voice: `هل أنت متأكد من هذه النقلة؟ لأنك نسيت أن ${pName} غير محمية على ${to} ويمكن للخصم أخذها مجاناً!`,
        motif: 'hung_moved',
        icon: '⚠️'
      };
    }
  }

  // Check 2: Did we leave another piece hanging?
  const hangingOther = findHangingPiece(boardAfter, moverColor);
  if (hangingOther) {
    const pName = PIECE_NAMES[hangingOther.piece] || 'قطعتك';
    return {
      text: `⚠️ هل أنت متأكد من هذه النقلة؟ لأنك نسيت حماية ${pName} على ${hangingOther.square} وتركتها فريسة سهلة للخصم!`,
      voice: `هل أنت متأكد من هذه النقلة؟ لأنك نسيت حماية ${pName} على ${hangingOther.square} وتركتها فريسة سهلة للخصم!`,
      motif: 'hung_other',
      icon: '⚠️'
    };
  }

  // Check 3: Did opponent gain a forced checkmate?
  if (boardAfter.isCheckmate() || (boardAfter.inCheck() && dropCp >= 400)) {
    return {
      text: `⚠️ هل أنت متأكد من هذه النقلة؟ لأنك نسيت تأمين دفاعات ملكك وسمحت للخصم بهجوم كش مات خطير!`,
      voice: `هل أنت متأكد من هذه النقلة؟ لأنك نسيت تأمين دفاعات ملكك وسمحت للخصم بهجوم كش مات خطير!`,
      motif: 'allowed_mate',
      icon: '⚠️'
    };
  }

  // Check 4: What did the best move threaten that we forgot to do?
  if (bestUci) {
    const bestFrom = bestUci.slice(0, 2);
    const bestTo = bestUci.slice(2, 4);
    const bestPiece = boardBefore.get(bestFrom);
    const targetPiece = boardBefore.get(bestTo);
    if (targetPiece && PIECE_VALUES[targetPiece.type] >= 300) {
      const tName = PIECE_NAMES[targetPiece.type] || 'قطعة الخصم';
      return {
        text: `⚠️ هل أنت متأكد من هذه النقلة؟ لأنك نسيت أن تهدد ${tName} على ${bestTo} وتفوت فرصة أسرها كما أوصى المحرك!`,
        voice: `هل أنت متأكد من هذه النقلة؟ لأنك نسيت أن تهدد ${tName} على ${bestTo} وتفوت فرصة أسرها كما أوصى المحرك!`,
        motif: 'missed_threat',
        icon: '⚠️'
      };
    }
  }

  // Check 5: General tactical regression
  return {
    text: `⚠️ هل أنت متأكد من هذه النقلة؟ لأنها تفقدك الأفضلية التكتيكية وتمنح الخصم فرصة قوية للهجوم المضاد!`,
    voice: `هل أنت متأكد من هذه النقلة؟ لأنها تفقدك الأفضلية التكتيكية وتمنح الخصم فرصة قوية للهجوم المضاد!`,
    motif: 'lost_eval',
    icon: '⚠️'
  };
}

function fallbackMistake() {
  return {
    text: '⚠️ هل أنت متأكد من هذه النقلة؟ المحرك يعتبرها نقلة غير دقيقة تضعف وضعيتك.',
    voice: 'هل أنت متأكد من هذه النقلة؟ المحرك يعتبرها نقلة غير دقيقة تضعف وضعيتك.',
    motif: 'mistake',
    icon: '⚠️'
  };
}

// Spoken Arabic via Web Speech API
let speechMuted = false;

export function setCoachMuted(muted) {
  speechMuted = Boolean(muted);
  if (speechMuted && typeof window !== 'undefined' && 'speechSynthesis' in window) {
    window.speechSynthesis.cancel();
  }
}

export function isCoachMuted() {
  return speechMuted;
}

export function speakArabic(sentence) {
  if (speechMuted) return;
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;

  try {
    window.speechSynthesis.cancel();
    // Strip emojis and punctuation that might confuse TTS
    const clean = sentence
      .replace(/[🏆👑💎⚔️🏰🛡️⚡🔱🎯⭐✨⚠️💡]/g, '')
      .replace(/[()]/g, ' ')
      .trim();

    const utterance = new SpeechSynthesisUtterance(clean);
    utterance.lang = 'ar-SA';
    utterance.rate = 1.05;
    utterance.pitch = 1.0;

    const voices = window.speechSynthesis.getVoices();
    const arVoice = voices.find(v => v.lang.startsWith('ar') || v.name.toLowerCase().includes('arabic'));
    if (arVoice) utterance.voice = arVoice;

    window.speechSynthesis.speak(utterance);
  } catch (err) {
    console.warn('Speech synthesis unavailable:', err);
  }
}
